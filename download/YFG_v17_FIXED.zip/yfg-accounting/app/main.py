from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import secrets
import sqlite3
import uuid
import zipfile
from contextlib import contextmanager
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field


ROOT = Path(__file__).resolve().parent.parent
DATA = Path(os.getenv("YFG_DATA_DIR", ROOT / "data")).resolve()
FILES = DATA / "files"
ATTACHMENTS_DIR = DATA / "attachments"
DB_PATH = DATA / "yfg.sqlite3"
MAX_UPLOAD = 20 * 1024 * 1024
CHAT_ATTACHMENT_MAX = 25 * 1024 * 1024
CHAT_ATTACHMENT_ALLOWED = {
    ".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp",
    ".pdf", ".txt", ".csv", ".xlsx", ".xls", ".docx", ".doc", ".pptx",
    ".zip", ".7z", ".rar", ".json", ".md"
}
PBKDF2_ROUNDS = 1_000
DATA.mkdir(parents=True, exist_ok=True)
FILES.mkdir(parents=True, exist_ok=True)
ATTACHMENTS_DIR.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="YFG Accounting Desk", docs_url=None, redoc_url=None)
app.mount("/static", StaticFiles(directory=ROOT / "app" / "static"), name="static")


@contextmanager
def db():
    con = sqlite3.connect(DB_PATH, timeout=20)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    con.execute("PRAGMA journal_mode=WAL")
    try:
        yield con
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()


SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
 id TEXT PRIMARY KEY, name TEXT NOT NULL, username TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('ADMIN','EMPLOYEE','CEO')),
 active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL,
 first_name TEXT NOT NULL DEFAULT '', last_name TEXT NOT NULL DEFAULT '',
 phone TEXT NOT NULL DEFAULT '', permissions TEXT
);
CREATE TABLE IF NOT EXISTS sessions(
 token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id),
 expires_at TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS companies(
 id TEXT PRIMARY KEY, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL,
 kind TEXT NOT NULL DEFAULT 'LEGAL', first_name TEXT NOT NULL DEFAULT '', last_name TEXT NOT NULL DEFAULT '',
 national_id TEXT NOT NULL DEFAULT '', phone TEXT NOT NULL DEFAULT '', address TEXT NOT NULL DEFAULT '',
 postal_code TEXT NOT NULL DEFAULT '', manager_name TEXT NOT NULL DEFAULT '', manager_phone TEXT NOT NULL DEFAULT '',
 description TEXT NOT NULL DEFAULT ''  -- توضیحات شرکت
);
CREATE TABLE IF NOT EXISTS company_contacts(
 id TEXT PRIMARY KEY, company_id TEXT NOT NULL REFERENCES companies(id),
 contact_type TEXT NOT NULL DEFAULT 'PHONE',  -- PHONE, MOBILE, EMAIL, FAX, WEBSITE, OTHER
 label TEXT NOT NULL DEFAULT '',  -- مثلاً "تلفن دفتر" یا "همراه مدیر"
 value TEXT NOT NULL, notes TEXT NOT NULL DEFAULT '',
 created_by TEXT NOT NULL REFERENCES users(id), created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS company_access(
 user_id TEXT NOT NULL REFERENCES users(id), company_id TEXT NOT NULL REFERENCES companies(id),
 PRIMARY KEY(user_id, company_id)
);
CREATE TABLE IF NOT EXISTS tasks(
 id TEXT PRIMARY KEY, company_id TEXT NOT NULL REFERENCES companies(id), title TEXT NOT NULL,
 description TEXT NOT NULL DEFAULT '', fiscal_period TEXT NOT NULL DEFAULT '', scope TEXT NOT NULL DEFAULT '',
 priority TEXT NOT NULL DEFAULT 'NORMAL', weight INTEGER NOT NULL DEFAULT 1,
 due_date TEXT, status TEXT NOT NULL DEFAULT 'ASSIGNED', progress INTEGER NOT NULL DEFAULT 0,
 parent_task_id TEXT REFERENCES tasks(id),
 reference_version_id TEXT REFERENCES reference_versions(id),
 assignee_id TEXT NOT NULL REFERENCES users(id), created_by TEXT NOT NULL REFERENCES users(id),
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS task_assignments(
 id TEXT PRIMARY KEY, task_id TEXT NOT NULL REFERENCES tasks(id), from_user TEXT,
 to_user TEXT NOT NULL REFERENCES users(id), actor_id TEXT NOT NULL REFERENCES users(id),
 reason TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS task_events(
 id TEXT PRIMARY KEY, task_id TEXT NOT NULL REFERENCES tasks(id), actor_id TEXT NOT NULL REFERENCES users(id),
 action TEXT NOT NULL, details TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS reference_versions(
 id TEXT PRIMARY KEY, company_id TEXT NOT NULL REFERENCES companies(id), fiscal_period TEXT NOT NULL,
 version INTEGER NOT NULL, original_name TEXT NOT NULL, stored_name TEXT NOT NULL, sha256 TEXT NOT NULL,
 row_count INTEGER NOT NULL, coverage_start TEXT, coverage_end TEXT,
 uploaded_by TEXT NOT NULL REFERENCES users(id), created_at TEXT NOT NULL,
 UNIQUE(company_id, fiscal_period, version)
);
CREATE TABLE IF NOT EXISTS submissions(
 id TEXT PRIMARY KEY, task_id TEXT NOT NULL REFERENCES tasks(id), employee_id TEXT NOT NULL REFERENCES users(id),
 reference_version_id TEXT REFERENCES reference_versions(id),
 version INTEGER NOT NULL, original_name TEXT NOT NULL, stored_name TEXT NOT NULL, sha256 TEXT NOT NULL,
 note TEXT NOT NULL DEFAULT '', claimed_start TEXT, claimed_end TEXT,
 row_count INTEGER NOT NULL, voucher_count INTEGER NOT NULL, duplicate_rows INTEGER NOT NULL,
 out_of_range INTEGER NOT NULL, report_json TEXT NOT NULL, created_at TEXT NOT NULL,
 UNIQUE(task_id, version)
);
CREATE TABLE IF NOT EXISTS normalized_rows(
 id TEXT PRIMARY KEY, company_id TEXT NOT NULL REFERENCES companies(id), fiscal_period TEXT NOT NULL,
 task_id TEXT NOT NULL REFERENCES tasks(id), submission_id TEXT NOT NULL REFERENCES submissions(id),
 source_row INTEGER NOT NULL, row_key TEXT NOT NULL, row_json TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS decisions(
 id TEXT PRIMARY KEY, task_id TEXT NOT NULL REFERENCES tasks(id), submission_id TEXT REFERENCES submissions(id),
 decision TEXT NOT NULL, score INTEGER, review_method TEXT NOT NULL, reason TEXT NOT NULL DEFAULT '',
 exception_reason TEXT NOT NULL DEFAULT '', manager_id TEXT NOT NULL REFERENCES users(id), created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS comments(
 id TEXT PRIMARY KEY, task_id TEXT NOT NULL REFERENCES tasks(id), author_id TEXT NOT NULL REFERENCES users(id),
 visibility TEXT NOT NULL CHECK(visibility IN ('EMPLOYEE_VISIBLE','MANAGER_ONLY')),
 body TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS requests(
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), kind TEXT NOT NULL DEFAULT 'GENERAL',
 request_type_id TEXT REFERENCES request_types(id),  -- optional link to a defined request type
 data_json TEXT NOT NULL DEFAULT '{}',  -- dynamic field values: JSON
 user_name_override TEXT NOT NULL DEFAULT '', -- if filled by someone else, otherwise use user.name
 start_date TEXT, end_date TEXT, body TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'PENDING',
 reviewer_id TEXT REFERENCES users(id), review_note TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL,
 reviewed_at TEXT
);
CREATE TABLE IF NOT EXISTS request_types(
 id TEXT PRIMARY KEY, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL,
 icon TEXT NOT NULL DEFAULT '📝',
 -- fields_json: JSON array of field specs
 -- [{"name":"leave_kind","label":"نوع مرخصی","type":"select","options":["استحقاقی","استعلاجی","بدون حقوق"],"required":true},
 --  {"name":"leave_unit","label":"واحد","type":"select","options":["روزانه","ساعتی"],"required":true},
 --  {"name":"from_date","label":"از تاریخ","type":"date","required":true},
 --  {"name":"to_date","label":"تا تاریخ","type":"date","required":true,"depends":"leave_unit:روزانه"},
 --  {"name":"from_time","label":"از ساعت","type":"time","required":false,"depends":"leave_unit:ساعتی"},
 --  {"name":"to_time","label":"تا ساعت","type":"time","required":false,"depends":"leave_unit:ساعتی"},
 --  {"name":"requester","label":"نام درخواستکننده","type":"user_link","required":true},
 --  {"name":"auto_duration","label":"مدت (محاسبه خودکار)","type":"duration","auto":true,"depends_on":["leave_unit","from_date","to_date","from_time","to_time"]},
 --  {"name":"body","label":"شرح","type":"textarea","required":false}]
 fields_json TEXT NOT NULL DEFAULT '[]',
 active INTEGER NOT NULL DEFAULT 1, created_by TEXT NOT NULL REFERENCES users(id), created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS attendance(
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), work_date TEXT NOT NULL,
 check_in TEXT, check_out TEXT, UNIQUE(user_id, work_date)
);
CREATE TABLE IF NOT EXISTS performance_entries(
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), work_date TEXT NOT NULL,
 category TEXT NOT NULL, title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
 duration_minutes INTEGER NOT NULL CHECK(duration_minutes BETWEEN 1 AND 1440),
 status TEXT NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING','APPROVED','NEEDS_EDIT')),
 review_note TEXT NOT NULL DEFAULT '', reviewer_id TEXT REFERENCES users(id), reviewed_at TEXT,
 created_at TEXT NOT NULL,
 -- Fields to match tasks (added for parity)
 company_id TEXT REFERENCES companies(id),
 fiscal_period TEXT NOT NULL DEFAULT '',
 scope TEXT NOT NULL DEFAULT '',
 priority TEXT NOT NULL DEFAULT 'NORMAL',
 weight INTEGER NOT NULL DEFAULT 1,
 due_date TEXT,
 progress INTEGER NOT NULL DEFAULT 0,
 updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS audit_events(
 id TEXT PRIMARY KEY, actor_id TEXT REFERENCES users(id), action TEXT NOT NULL,
 entity_type TEXT NOT NULL, entity_id TEXT, details TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS notifications(
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), title TEXT NOT NULL,
 body TEXT NOT NULL DEFAULT '', read_at TEXT, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_tasks_assignee_status ON tasks(assignee_id,status);
CREATE INDEX IF NOT EXISTS ix_submissions_task ON submissions(task_id,version);
CREATE INDEX IF NOT EXISTS ix_normalized_scope_key ON normalized_rows(company_id,fiscal_period,row_key);
CREATE INDEX IF NOT EXISTS ix_audit_created ON audit_events(created_at);
CREATE INDEX IF NOT EXISTS ix_performance_user_date ON performance_entries(user_id,work_date);

-- Phase 2: Time Tracking
CREATE TABLE IF NOT EXISTS time_entries(
 id TEXT PRIMARY KEY, task_id TEXT REFERENCES tasks(id), user_id TEXT NOT NULL REFERENCES users(id),
 start_at TEXT NOT NULL, end_at TEXT, duration_seconds INTEGER NOT NULL DEFAULT 0,
 description TEXT NOT NULL DEFAULT '', billable INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_time_user_date ON time_entries(user_id,start_at);
CREATE INDEX IF NOT EXISTS ix_time_task ON time_entries(task_id);

-- Phase 3: Automations
CREATE TABLE IF NOT EXISTS automations(
 id TEXT PRIMARY KEY, name TEXT NOT NULL, trigger_type TEXT NOT NULL, trigger_config TEXT NOT NULL DEFAULT '{}',
 action_type TEXT NOT NULL, action_config TEXT NOT NULL DEFAULT '{}',
 enabled INTEGER NOT NULL DEFAULT 1, created_by TEXT NOT NULL REFERENCES users(id),
 created_at TEXT NOT NULL, last_fired_at TEXT
);

-- Phase 4: Chat (full messenger: DM + GROUP + file attachments)
CREATE TABLE IF NOT EXISTS chat_channels(
 id TEXT PRIMARY KEY, name TEXT NOT NULL DEFAULT '', kind TEXT NOT NULL DEFAULT 'GROUP', -- GROUP | DIRECT
 created_by TEXT NOT NULL REFERENCES users(id), created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS chat_messages(
 id TEXT PRIMARY KEY, channel_id TEXT NOT NULL REFERENCES chat_channels(id),
 user_id TEXT NOT NULL REFERENCES users(id), body TEXT NOT NULL DEFAULT '',
 attachment_id TEXT, -- NULL or references chat_attachments.id
 reply_to TEXT REFERENCES chat_messages(id),
 delivered_at TEXT NOT NULL DEFAULT '',  -- filled when other party fetched the message
 read_at TEXT NOT NULL DEFAULT '',       -- filled when other party marked as read
 created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS chat_channel_members(
 channel_id TEXT NOT NULL REFERENCES chat_channels(id), user_id TEXT NOT NULL REFERENCES users(id),
 last_read_at TEXT NOT NULL DEFAULT '', joined_at TEXT NOT NULL,
 PRIMARY KEY(channel_id, user_id)
);
CREATE TABLE IF NOT EXISTS chat_attachments(
 id TEXT PRIMARY KEY, original_name TEXT NOT NULL, stored_name TEXT NOT NULL,
 mime_type TEXT NOT NULL DEFAULT 'application/octet-stream', size_bytes INTEGER NOT NULL DEFAULT 0,
 sha256 TEXT NOT NULL DEFAULT '', uploaded_by TEXT NOT NULL REFERENCES users(id), created_at TEXT NOT NULL
);
-- Phase 4b: Customers (persons / portal / contracts / invoices — only persons active now)
CREATE TABLE IF NOT EXISTS persons(
 id TEXT PRIMARY KEY, code TEXT NOT NULL UNIQUE, first_name TEXT NOT NULL, last_name TEXT NOT NULL,
 national_id TEXT NOT NULL DEFAULT '', phone TEXT NOT NULL DEFAULT '', email TEXT NOT NULL DEFAULT '',
 address TEXT NOT NULL DEFAULT '', postal_code TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '',
 linked_company_id TEXT REFERENCES companies(id), -- optional link to a company
 active INTEGER NOT NULL DEFAULT 1, created_by TEXT NOT NULL REFERENCES users(id), created_at TEXT NOT NULL
);
-- Phase 4c: Customers — Contracts, Proformas, Invoices (full first version)
CREATE TABLE IF NOT EXISTS contracts(
 id TEXT PRIMARY KEY, code TEXT NOT NULL UNIQUE, title TEXT NOT NULL,
 company_id TEXT NOT NULL REFERENCES companies(id),
 person_id TEXT REFERENCES persons(id),  -- optional contract signer (real person)
 start_date TEXT NOT NULL, end_date TEXT NOT NULL,
 value_amount REAL NOT NULL DEFAULT 0,  -- مبلغ قرارداد
 currency TEXT NOT NULL DEFAULT 'IRR',  -- IRR / USD / EUR
 status TEXT NOT NULL DEFAULT 'DRAFT',  -- DRAFT / ACTIVE / COMPLETED / TERMINATED
 contract_type TEXT NOT NULL DEFAULT 'general',  -- نوع قرارداد: general, accounting, audit, consulting
 subject TEXT NOT NULL DEFAULT '',  -- موضوع
 notes TEXT NOT NULL DEFAULT '',
 attachment_id TEXT,  -- optional file
 created_by TEXT NOT NULL REFERENCES users(id), created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS proformas(
 id TEXT PRIMARY KEY, code TEXT NOT NULL UNIQUE, title TEXT NOT NULL,
 company_id TEXT NOT NULL REFERENCES companies(id),
 person_id TEXT REFERENCES persons(id),
 contract_id TEXT REFERENCES contracts(id),  -- optional link to a contract
 issue_date TEXT NOT NULL,
 valid_until TEXT,  -- تاریخ انقضا پیشفاکتور
 status TEXT NOT NULL DEFAULT 'DRAFT',  -- DRAFT / IN_PROGRESS / SENT / ACCEPTED / REJECTED / EXPIRED
 total_amount REAL NOT NULL DEFAULT 0,
 currency TEXT NOT NULL DEFAULT 'IRR',
 items_json TEXT NOT NULL DEFAULT '[]',  -- [{description, qty, unit_price, total, notes}]
 notes TEXT NOT NULL DEFAULT '',
 created_by TEXT NOT NULL REFERENCES users(id), created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS invoices(
 id TEXT PRIMARY KEY, code TEXT NOT NULL UNIQUE, title TEXT NOT NULL,
 company_id TEXT NOT NULL REFERENCES companies(id),
 person_id TEXT REFERENCES persons(id),
 proforma_id TEXT REFERENCES proformas(id),  -- optional link to source proforma
 contract_id TEXT REFERENCES contracts(id),  -- optional link to contract
 issue_date TEXT NOT NULL,
 due_date TEXT,  -- تاریخ سررسید
 status TEXT NOT NULL DEFAULT 'DRAFT',  -- DRAFT / UNPAID / PARTIAL / PAID / OVERDUE / CANCELLED
 total_amount REAL NOT NULL DEFAULT 0,
 paid_amount REAL NOT NULL DEFAULT 0,
 currency TEXT NOT NULL DEFAULT 'IRR',
 items_json TEXT NOT NULL DEFAULT '[]',
 notes TEXT NOT NULL DEFAULT '',
 created_by TEXT NOT NULL REFERENCES users(id), created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL
);

-- Phase 5: ISO 30414 HR Metrics Snapshots
CREATE TABLE IF NOT EXISTS iso30414_snapshots(
 id TEXT PRIMARY KEY, snapshot_date TEXT NOT NULL, metrics_json TEXT NOT NULL,
 created_by TEXT REFERENCES users(id), created_at TEXT NOT NULL
);

-- Phase 6: Kanban ordering
CREATE TABLE IF NOT EXISTS task_kanban_order(
 task_id TEXT PRIMARY KEY REFERENCES tasks(id), column_status TEXT NOT NULL, sort_order INTEGER NOT NULL DEFAULT 0
);

-- Task checklist (5-step workflow)
CREATE TABLE IF NOT EXISTS task_checklist(
 id TEXT PRIMARY KEY, task_id TEXT NOT NULL REFERENCES tasks(id),
 step_number INTEGER NOT NULL DEFAULT 1, title TEXT NOT NULL, is_done INTEGER NOT NULL DEFAULT 0,
 done_by TEXT REFERENCES users(id), done_at TEXT, created_at TEXT NOT NULL,
 UNIQUE(task_id, step_number)
);

-- Performance entries enhancements (delegation, score, events)
CREATE TABLE IF NOT EXISTS performance_events(
 id TEXT PRIMARY KEY, entry_id TEXT NOT NULL REFERENCES performance_entries(id),
 actor_id TEXT NOT NULL REFERENCES users(id), action TEXT NOT NULL, details TEXT NOT NULL DEFAULT '{}',
 created_at TEXT NOT NULL
);

-- Performance delegation (assign part of performance to colleague)
CREATE TABLE IF NOT EXISTS performance_delegations(
 id TEXT PRIMARY KEY, entry_id TEXT NOT NULL REFERENCES performance_entries(id),
 from_user TEXT NOT NULL REFERENCES users(id), to_user TEXT NOT NULL REFERENCES users(id),
 scope TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'DELEGATED',
 created_at TEXT NOT NULL
);

-- Performance scores (0-100 by manager)
CREATE TABLE IF NOT EXISTS performance_scores_v2(
 id TEXT PRIMARY KEY, entry_id TEXT NOT NULL REFERENCES performance_entries(id),
 manager_id TEXT NOT NULL REFERENCES users(id), score INTEGER NOT NULL DEFAULT 0,
 reason TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);

-- Multi-assignee support for tasks
CREATE TABLE IF NOT EXISTS task_collaborators(
 task_id TEXT NOT NULL REFERENCES tasks(id), user_id TEXT NOT NULL REFERENCES users(id),
 role TEXT NOT NULL DEFAULT 'COLLABORATOR', added_by TEXT REFERENCES users(id),
 added_at TEXT NOT NULL, PRIMARY KEY(task_id, user_id)
);

-- Task checklist for performance entries (5-step workflow)
CREATE TABLE IF NOT EXISTS performance_checklist(
 id TEXT PRIMARY KEY, entry_id TEXT NOT NULL REFERENCES performance_entries(id),
 step_number INTEGER NOT NULL DEFAULT 1, title TEXT NOT NULL, is_done INTEGER NOT NULL DEFAULT 0,
 done_by TEXT REFERENCES users(id), done_at TEXT, created_at TEXT NOT NULL,
 UNIQUE(entry_id, step_number)
);

-- Performance comments (separate from task comments)
CREATE TABLE IF NOT EXISTS perf_comments(
 id TEXT PRIMARY KEY, entry_id TEXT NOT NULL REFERENCES performance_entries(id),
 author_id TEXT NOT NULL REFERENCES users(id),
 visibility TEXT NOT NULL CHECK(visibility IN ("EMPLOYEE_VISIBLE","MANAGER_ONLY")),
 body TEXT NOT NULL, created_at TEXT NOT NULL
);

-- Performance submissions (separate from task submissions)
CREATE TABLE IF NOT EXISTS perf_submissions(
 id TEXT PRIMARY KEY, entry_id TEXT NOT NULL REFERENCES performance_entries(id),
 user_id TEXT NOT NULL REFERENCES users(id), version INTEGER NOT NULL,
 original_name TEXT NOT NULL, stored_name TEXT NOT NULL, sha256 TEXT NOT NULL,
 note TEXT NOT NULL DEFAULT "", claimed_start TEXT, claimed_end TEXT,
 row_count INTEGER NOT NULL, voucher_count INTEGER NOT NULL, duplicate_rows INTEGER NOT NULL,
 out_of_range INTEGER NOT NULL, report_json TEXT NOT NULL, created_at TEXT NOT NULL,
 reference_id TEXT, -- مرجع مدیر (در صورت وجود)
 template_valid INTEGER NOT NULL DEFAULT 1, -- اعتبارسنجی قالب (۱=معتبر، ۰=نامعتبر)
 template_errors TEXT NOT NULL DEFAULT "[]", -- خطاهای قالب به JSON
 status TEXT NOT NULL DEFAULT "PENDING", -- PENDING / APPROVED / RETURNED / REJECTED
 manager_id TEXT, decision_at TEXT, decision_note TEXT NOT NULL DEFAULT ""
);

-- Performance reference versions (manager-uploaded reference files for reconciliation)
CREATE TABLE IF NOT EXISTS perf_references(
 id TEXT PRIMARY KEY, entry_id TEXT NOT NULL REFERENCES performance_entries(id),
 company_id TEXT, fiscal_period TEXT NOT NULL DEFAULT "",
 version INTEGER NOT NULL DEFAULT 1,
 original_name TEXT NOT NULL, stored_name TEXT NOT NULL, sha256 TEXT NOT NULL,
 row_count INTEGER NOT NULL, coverage_start TEXT, coverage_end TEXT,
 uploaded_by TEXT NOT NULL REFERENCES users(id), created_at TEXT NOT NULL
);

-- Performance submission reconciliation diffs (row-level)
CREATE TABLE IF NOT EXISTS perf_submission_diffs(
 id TEXT PRIMARY KEY, submission_id TEXT NOT NULL REFERENCES perf_submissions(id),
 source_row INTEGER NOT NULL, voucher TEXT NOT NULL DEFAULT "",
 line TEXT NOT NULL DEFAULT "", date TEXT NOT NULL DEFAULT "",
 account TEXT NOT NULL DEFAULT "", debit TEXT NOT NULL DEFAULT "",
 credit TEXT NOT NULL DEFAULT "", description TEXT NOT NULL DEFAULT "",
 issue_type TEXT NOT NULL, -- MISSING_FROM_REFERENCE / DEBIT_MISMATCH / CREDIT_MISMATCH / DATE_MISMATCH / DESCRIPTION_MISMATCH / VOUCHER_MISMATCH / DUPLICATE / OUT_OF_RANGE
 issue_detail TEXT NOT NULL DEFAULT "",
 ref_debit TEXT, ref_credit TEXT, ref_date TEXT, ref_account TEXT, ref_description TEXT,
 created_at TEXT NOT NULL
);

-- Settings tables (task types, process types, role types, performance types)
CREATE TABLE IF NOT EXISTS task_types(
 id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE, description TEXT NOT NULL DEFAULT '',
 icon TEXT NOT NULL DEFAULT '📋', active INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS process_types(
 id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE, description TEXT NOT NULL DEFAULT '',
 default_steps INTEGER NOT NULL DEFAULT 3, active INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS role_types(
 id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE, description TEXT NOT NULL DEFAULT '',
 permissions TEXT NOT NULL DEFAULT '[]', active INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS performance_types(
 id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE, category TEXT NOT NULL DEFAULT 'general',
 description TEXT NOT NULL DEFAULT '', active INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS kpis(
 id TEXT PRIMARY KEY,
 name TEXT NOT NULL,
 category TEXT NOT NULL DEFAULT 'quality',
 description TEXT NOT NULL DEFAULT '',
 target_value REAL NOT NULL DEFAULT 100,
 target_operator TEXT NOT NULL DEFAULT '>=',
 unit TEXT NOT NULL DEFAULT '%',
 weight INTEGER NOT NULL DEFAULT 10,
 frequency TEXT NOT NULL DEFAULT 'monthly',
 owner_role TEXT NOT NULL DEFAULT 'EMPLOYEE',
 formula TEXT NOT NULL DEFAULT '',
 active INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL
);

-- Seed default KPIs
INSERT OR IGNORE INTO kpis VALUES('kpi1','کیفیت کار','quality','نمره میانگین کیفیت ارائهها (۰ تا ۱۰۰)',90,'>=','%','40','monthly','EMPLOYEE','AVG(performance_scores_v2.score) * 1.0',1,datetime('now'),datetime('now'));
INSERT OR IGNORE INTO kpis VALUES('kpi2','تحویل بهموقع','ontime','درصد تسکهای تحویلی در مهلت',85,'>=','%','25','monthly','EMPLOYEE','COUNT(tasks WHERE completed_at<=due_date)/COUNT(tasks)*100',1,datetime('now'),datetime('now'));
INSERT OR IGNORE INTO kpis VALUES('kpi3','حجم کار','volume','مجموع دقیقهی کار ثبتشده در ماه',1200,'>=','دقیقه','15','monthly','EMPLOYEE','SUM(performance_entries.duration_minutes)',1,datetime('now'),datetime('now'));
INSERT OR IGNORE INTO kpis VALUES('kpi4','همکاری تیمی','collaboration','تعداد تسکهای مشارکتی',5,'>=','عدد','15','monthly','EMPLOYEE','COUNT(task_collaborators)',1,datetime('now'),datetime('now'));
INSERT OR IGNORE INTO kpis VALUES('kpi5','رضایت مدیر','satisfaction','میانگین رضایت مدیر از کارکرد',4,'>=','از ۵','5','monthly','EMPLOYEE','AVG(decisions.rating)',1,datetime('now'),datetime('now'));

-- Seed default types
INSERT OR IGNORE INTO task_types VALUES('tt1','ثبت اسناد','ثبت اسناد حسابداری دورهای','📒',1,datetime('now'));
INSERT OR IGNORE INTO task_types VALUES('tt2','بستن دفاتر','بستن دفاتر پایان دوره','📕',1,datetime('now'));
INSERT OR IGNORE INTO task_types VALUES('tt3','اظهارنامه مالیاتی','تهیه و ارسال اظهارنامه','🧾',1,datetime('now'));
INSERT OR IGNORE INTO task_types VALUES('tt4','حسابرسی','حسابرسی و بررسی اسناد','🔍',1,datetime('now'));
INSERT OR IGNORE INTO task_types VALUES('tt5','اصلاح مغایرت','اصلاح اسناد مغایر','🔧',1,datetime('now'));

INSERT OR IGNORE INTO process_types VALUES('pt1','فرآیند ماهانه','دوره ماهانه — ۳ مرحله',3,1,datetime('now'));
INSERT OR IGNORE INTO process_types VALUES('pt2','فرآیند فصلی','دوره فصلی — ۵ مرحله',5,1,datetime('now'));
INSERT OR IGNORE INTO process_types VALUES('pt3','فرآیند سالانه','دوره سالانه — ۵ مرحله',5,1,datetime('now'));

INSERT OR IGNORE INTO role_types VALUES('rt1','ADMIN','مدیر سامانه — دسترسی کامل','["all"]',1,datetime('now'));
INSERT OR IGNORE INTO role_types VALUES('rt2','CEO','مدیرعامل — دید همه شرکتها','["view_all","approve"]',1,datetime('now'));
INSERT OR IGNORE INTO role_types VALUES('rt3','EMPLOYEE','کارمند — دسترسی محدود','["view_assigned","submit_work"]',1,datetime('now'));

INSERT OR IGNORE INTO performance_types VALUES('pft1','حسابداری','accounting','کارهای حسابداری دورهای',1,datetime('now'));
INSERT OR IGNORE INTO performance_types VALUES('pft2','مالیاتی','tax','امور مالیاتی',1,datetime('now'));
INSERT OR IGNORE INTO performance_types VALUES('pft3','حسابرسی','audit','حسابرسی و کنترل',1,datetime('now'));
INSERT OR IGNORE INTO performance_types VALUES('pft4','اداری','admin','کارهای اداری',1,datetime('now'));
INSERT OR IGNORE INTO performance_types VALUES('pft5','مشاوره','consult','مشاوره و پشتیبانی',1,datetime('now'));
INSERT OR IGNORE INTO performance_types VALUES('pft6','سایر','other','سایر کارها',1,datetime('now'));

-- Phase 1: Tax Deadlines Calendar (تقویم سررسیدهای مالیاتی)
CREATE TABLE IF NOT EXISTS tax_deadlines(
 id TEXT PRIMARY KEY,
 company_id TEXT NOT NULL REFERENCES companies(id),
 deadline_type TEXT NOT NULL, -- VAT_QUARTERLY, ANNUAL_RETURN, PAYROLL_TAX, SOCIAL_SECURITY, MOUDIAN, AUDIT, OTHER
 title TEXT NOT NULL,
 due_date TEXT NOT NULL, -- ISO date
 period_label TEXT NOT NULL DEFAULT '', -- مثلاً "زمستان ۱۴۰۳"
 amount REAL, -- مبلغ مورد انتظار (اختیاری)
 status TEXT NOT NULL DEFAULT 'PENDING', -- PENDING, FILED, PAID, OVERDUE, CANCELLED
 notes TEXT NOT NULL DEFAULT '',
 assigned_user_id TEXT REFERENCES users(id),
 completed_at TEXT,
 completed_by TEXT REFERENCES users(id),
 created_by TEXT NOT NULL REFERENCES users(id),
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL
);

-- Phase 1: Company Staff Assignment (تخصیص کارمند به شرکت)
CREATE TABLE IF NOT EXISTS company_staff(
 id TEXT PRIMARY KEY,
 company_id TEXT NOT NULL REFERENCES companies(id),
 user_id TEXT NOT NULL REFERENCES users(id),
 role TEXT NOT NULL DEFAULT 'accountant', -- lead, accountant, assistant
 assigned_at TEXT NOT NULL,
 assigned_by TEXT NOT NULL REFERENCES users(id),
 active INTEGER NOT NULL DEFAULT 1,
 notes TEXT NOT NULL DEFAULT '',
 UNIQUE(company_id, user_id)
);

-- Phase 1: Fee Module (ماژول Fee و مطالبات)
CREATE TABLE IF NOT EXISTS fees(
 id TEXT PRIMARY KEY,
 company_id TEXT NOT NULL REFERENCES companies(id),
 contract_id TEXT REFERENCES contracts(id),
 title TEXT NOT NULL,
 fee_type TEXT NOT NULL DEFAULT 'monthly', -- monthly, quarterly, annual, hourly, one_time
 amount REAL NOT NULL DEFAULT 0,
 currency TEXT NOT NULL DEFAULT 'IRR',
 period_start TEXT,
 period_end TEXT,
 issue_date TEXT NOT NULL,
 due_date TEXT,
 status TEXT NOT NULL DEFAULT 'UNPAID', -- UNPAID, PARTIAL, PAID, OVERDUE, CANCELLED
 paid_amount REAL NOT NULL DEFAULT 0,
 paid_date TEXT,
 notes TEXT NOT NULL DEFAULT '',
 created_by TEXT NOT NULL REFERENCES users(id),
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL
);

-- Phase 1: Moudian System (سامانه مودیان — فاکتور الکترونیکی)
CREATE TABLE IF NOT EXISTS moudian_invoices(
 id TEXT PRIMARY KEY,
 company_id TEXT NOT NULL REFERENCES companies(id),
 invoice_id TEXT, -- کد فاکتور در سامانه مودیان
 invoice_number TEXT, -- شماره فاکتور داخلی
 invoice_type TEXT NOT NULL DEFAULT 'SALES', -- SALES, PURCHASE, RETURN
 buyer_tin TEXT, -- شناسه اقتصادی خریدار
 buyer_name TEXT,
 seller_tin TEXT, -- شناسه اقتصادی فروشنده (شرکت)
 seller_name TEXT,
 issue_date TEXT NOT NULL,
 total_amount REAL NOT NULL DEFAULT 0,
 tax_amount REAL NOT NULL DEFAULT 0,
 discount_amount REAL NOT NULL DEFAULT 0,
 payable_amount REAL NOT NULL DEFAULT 0,
 items_json TEXT NOT NULL DEFAULT '[]',
 status TEXT NOT NULL DEFAULT 'DRAFT', -- DRAFT, PENDING, SENT, ACCEPTED, REJECTED, CANCELLED
 reference_id TEXT, -- کد رهگیری از سامانه مودیان
 submitted_at TEXT,
 error_message TEXT NOT NULL DEFAULT '',
 created_by TEXT NOT NULL REFERENCES users(id),
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL
);

-- Phase 2: Client Portal (پرتال مشتری)
CREATE TABLE IF NOT EXISTS client_portal_users(
 id TEXT PRIMARY KEY,
 company_id TEXT NOT NULL REFERENCES companies(id),
 person_id TEXT REFERENCES persons(id),
 username TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 display_name TEXT NOT NULL DEFAULT '',
 email TEXT NOT NULL DEFAULT '',
 phone TEXT NOT NULL DEFAULT '',
 active INTEGER NOT NULL DEFAULT 1,
 created_by TEXT NOT NULL REFERENCES users(id),
 created_at TEXT NOT NULL,
 last_login TEXT
);

-- Phase 2: Document Management (مدیریت اسناد)
CREATE TABLE IF NOT EXISTS documents(
 id TEXT PRIMARY KEY,
 company_id TEXT NOT NULL REFERENCES companies(id),
 category TEXT NOT NULL DEFAULT 'general',
 title TEXT NOT NULL,
 description TEXT NOT NULL DEFAULT '',
 file_name TEXT NOT NULL,
 stored_name TEXT NOT NULL,
 file_size INTEGER NOT NULL DEFAULT 0,
 mime_type TEXT NOT NULL DEFAULT 'application/octet-stream',
 sha256 TEXT NOT NULL DEFAULT '',
 version INTEGER NOT NULL DEFAULT 1,
 parent_id TEXT REFERENCES documents(id),
 uploaded_by TEXT NOT NULL REFERENCES users(id),
 uploaded_at TEXT NOT NULL,
 tags TEXT NOT NULL DEFAULT ''
);

-- Phase 2: E-Signature (امضای الکترونیکی)
CREATE TABLE IF NOT EXISTS document_signatures(
 id TEXT PRIMARY KEY,
 document_id TEXT NOT NULL REFERENCES documents(id),
 signer_type TEXT NOT NULL DEFAULT 'internal',
 signer_id TEXT,
 signer_name TEXT NOT NULL,
 signature_text TEXT NOT NULL,
 signature_hash TEXT NOT NULL,
 signed_at TEXT NOT NULL,
 ip_address TEXT NOT NULL DEFAULT ''
);

-- Phase 2: Recurring Task Templates (قالبهای کار تکرارپذیر)
CREATE TABLE IF NOT EXISTS task_templates(
 id TEXT PRIMARY KEY,
 name TEXT NOT NULL,
 description TEXT NOT NULL DEFAULT '',
 company_id TEXT REFERENCES companies(id),
 task_type TEXT NOT NULL DEFAULT 'ثبت اسناد',
 priority TEXT NOT NULL DEFAULT 'NORMAL',
 weight INTEGER NOT NULL DEFAULT 1,
 scope TEXT NOT NULL DEFAULT '',
 frequency TEXT NOT NULL DEFAULT 'monthly',
 day_of_month INTEGER,
 day_of_week INTEGER,
 assignee_id TEXT REFERENCES users(id),
 active INTEGER NOT NULL DEFAULT 1,
 created_by TEXT NOT NULL REFERENCES users(id),
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL,
 last_generated TEXT
);
"""


def init_db() -> None:
    with db() as con:
        con.executescript(SCHEMA)
        # Keep patch-level compatibility if an earlier local 0.1 build already created SQLite.
        for table, column, definition in (
            ("tasks", "parent_task_id", "TEXT REFERENCES tasks(id)"),
            ("tasks", "reference_version_id", "TEXT REFERENCES reference_versions(id)"),
            ("submissions", "reference_version_id", "TEXT REFERENCES reference_versions(id)"),
            # Add new columns to perf_submissions (existing DBs from previous version)
            ("perf_submissions", "reference_id", "TEXT"),
            ("perf_submissions", "template_valid", "INTEGER NOT NULL DEFAULT 1"),
            ("perf_submissions", "template_errors", "TEXT NOT NULL DEFAULT '[]'"),
            ("perf_submissions", "status", "TEXT NOT NULL DEFAULT 'PENDING'"),
            ("perf_submissions", "manager_id", "TEXT"),
            ("perf_submissions", "decision_at", "TEXT"),
            ("perf_submissions", "decision_note", "TEXT NOT NULL DEFAULT ''"),
            # Add task-parity fields to performance_entries (existing DBs)
            ("performance_entries", "company_id", "TEXT REFERENCES companies(id)"),
            ("performance_entries", "fiscal_period", "TEXT NOT NULL DEFAULT ''"),
            ("performance_entries", "scope", "TEXT NOT NULL DEFAULT ''"),
            ("performance_entries", "priority", "TEXT NOT NULL DEFAULT 'NORMAL'"),
            ("performance_entries", "weight", "INTEGER NOT NULL DEFAULT 1"),
            ("performance_entries", "due_date", "TEXT"),
            ("performance_entries", "progress", "INTEGER NOT NULL DEFAULT 0"),
            ("performance_entries", "updated_at", "TEXT"),
            # Settings v2: rich company fields (تعریف شرکت حرفهای)
            ("companies", "kind", "TEXT NOT NULL DEFAULT 'LEGAL'"),
            ("companies", "first_name", "TEXT NOT NULL DEFAULT ''"),
            ("companies", "last_name", "TEXT NOT NULL DEFAULT ''"),
            ("companies", "national_id", "TEXT NOT NULL DEFAULT ''"),
            ("companies", "phone", "TEXT NOT NULL DEFAULT ''"),
            ("companies", "address", "TEXT NOT NULL DEFAULT ''"),
            ("companies", "postal_code", "TEXT NOT NULL DEFAULT ''"),
            ("companies", "manager_name", "TEXT NOT NULL DEFAULT ''"),
            ("companies", "manager_phone", "TEXT NOT NULL DEFAULT ''"),
            # Settings v2: rich user fields + fine-grained permissions
            ("users", "first_name", "TEXT NOT NULL DEFAULT ''"),
            ("users", "last_name", "TEXT NOT NULL DEFAULT ''"),
            ("users", "phone", "TEXT NOT NULL DEFAULT ''"),
            ("users", "permissions", "TEXT"),
        ):
            columns = {r["name"] for r in con.execute(f"PRAGMA table_info({table})")}
            if column not in columns:
                try:
                    con.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")
                except Exception:
                    pass  # column might already exist or table doesn't exist yet

        # Backfill updated_at for old performance entries that don't have it
        try:
            con.execute("UPDATE performance_entries SET updated_at=created_at WHERE updated_at IS NULL OR updated_at=''")
        except Exception:
            pass


init_db()


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")


def tehran_jalali_today() -> str:
    return gregorian_to_jalali(datetime.now(ZoneInfo("Asia/Tehran")).date())


def gregorian_to_jalali(d: date) -> str:
    gy, gm, gd = d.year, d.month, d.day
    month_days = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334]
    gy2 = gy + 1 if gm > 2 else gy
    days = 355666 + 365 * gy + (gy2 + 3) // 4 - (gy2 + 99) // 100 + (gy2 + 399) // 400 + gd + month_days[gm - 1]
    jy = -1595 + 33 * (days // 12053)
    days %= 12053
    jy += 4 * (days // 1461)
    days %= 1461
    if days > 365:
        jy += (days - 1) // 365
        days = (days - 1) % 365
    if days < 186:
        jm, jd = 1 + days // 31, 1 + days % 31
    else:
        jm, jd = 7 + (days - 186) // 30, 1 + (days - 186) % 30
    return f"{jy:04d}/{jm:02d}/{jd:02d}"


def uid() -> str:
    return str(uuid.uuid4())


def password_hash(password: str, salt: bytes | None = None) -> str:
    salt = salt or secrets.token_bytes(16)
    key = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, PBKDF2_ROUNDS)
    return f"pbkdf2_sha256${PBKDF2_ROUNDS}${salt.hex()}${key.hex()}"


def password_ok(password: str, encoded: str) -> bool:
    try:
        algorithm, rounds, salt_hex, digest_hex = encoded.split("$")
        if algorithm != "pbkdf2_sha256":
            return False
        candidate = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt_hex), int(rounds)).hex()
        return hmac.compare_digest(candidate, digest_hex)
    except (ValueError, TypeError):
        return False


def audit(con: sqlite3.Connection, actor: str | None, action: str, entity: str, entity_id: str | None, details: dict[str, Any] | None = None) -> None:
    con.execute("INSERT INTO audit_events VALUES(?,?,?,?,?,?,?)", (uid(), actor, action, entity, entity_id, json.dumps(details or {}, ensure_ascii=False), now()))


def notify(con: sqlite3.Connection, user_id: str, title: str, body: str = "") -> None:
    con.execute("INSERT INTO notifications VALUES(?,?,?,?,?,?)", (uid(), user_id, title, body, None, now()))


def current_user(request: Request, con: sqlite3.Connection | None = None) -> sqlite3.Row:
    token = request.cookies.get("yfg_session")
    if not token:
        raise HTTPException(401, "ابتدا وارد سامانه شوید")
    query = "SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>? AND u.active=1"
    args = (hashlib.sha256(token.encode()).hexdigest(), now())
    if con is None:
        with db() as conn:
            row = conn.execute(query, args).fetchone()
    else:
        row = con.execute(query, args).fetchone()
    if row is None:
        raise HTTPException(401, "نشست معتبر نیست؛ دوباره وارد شوید")
    return row


def require_role(user: sqlite3.Row, *roles: str) -> None:
    if user["role"] not in roles:
        raise HTTPException(403, "دسترسی کافی ندارید")


# ===== FINE-GRAINED PERMISSION SYSTEM (نقشها و دسترسیها به ریز فیلد) =====
# هر کاربر میتواند علاوه بر نقش پایه، دسترسیهای ریز داشته باشد.
# users.permissions = NULL یعنی پیشفرض نقش؛ در غیر این صورت JSON {perm_key: bool}

PERMISSION_CATALOG = [
    {"group": "داشبورد و گزارشها", "items": [
        {"key": "dashboard.view", "label": "مشاهده نمای کلی", "roles": ["ADMIN", "CEO", "EMPLOYEE"]},
        {"key": "reports.kpi", "label": "گزارش عملکرد تیم (KPI)", "roles": ["ADMIN", "CEO"]},
        {"key": "reports.iso", "label": "گزارش ISO 30414", "roles": ["ADMIN", "CEO"]},
        {"key": "audit.view", "label": "گزارش ممیزی", "roles": ["ADMIN"]},
    ]},
    {"group": "تسکها", "items": [
        {"key": "tasks.view", "label": "مشاهده تسکها", "roles": ["ADMIN", "CEO", "EMPLOYEE"]},
        {"key": "tasks.create", "label": "ایجاد و واگذاری تسک", "roles": ["ADMIN", "CEO"]},
        {"key": "tasks.decide", "label": "تصمیم مدیر روی تسک (تأیید/برگشت)", "roles": ["ADMIN", "CEO"]},
        {"key": "tasks.reference", "label": "بارگذاری فایل مرجع Excel", "roles": ["ADMIN", "CEO"]},
    ]},
    {"group": "شرکتها", "items": [
        {"key": "companies.view", "label": "مشاهده شرکتها (فقط شرکتهای واگذارشده)", "roles": ["ADMIN", "CEO", "EMPLOYEE"]},
        {"key": "companies.manage", "label": "تعریف/ویرایش/حذف شرکت", "roles": ["ADMIN"]},
    ]},
    {"group": "کاربران", "items": [
        {"key": "users.view", "label": "مشاهده فهرست کاربران", "roles": ["ADMIN", "CEO"]},
        {"key": "users.manage", "label": "ایجاد/ویرایش/غیرفعالسازی کاربر", "roles": ["ADMIN"]},
        {"key": "users.permissions", "label": "تعیین نقشها و دسترسیهای ریز کاربران", "roles": ["ADMIN"]},
    ]},
    {"group": "عملکرد", "items": [
        {"key": "performance.own", "label": "ثبت عملکرد خود", "roles": ["ADMIN", "CEO", "EMPLOYEE"]},
        {"key": "performance.review", "label": "بررسی و تصمیم روی عملکرد کارکنان", "roles": ["ADMIN", "CEO"]},
        {"key": "performance.reference", "label": "بارگذاری مرجع عملکرد", "roles": ["ADMIN", "CEO"]},
    ]},
    {"group": "کارکرد و درخواستها", "items": [
        {"key": "attendance.own", "label": "ثبت ورود/خروج خود", "roles": ["ADMIN", "CEO", "EMPLOYEE"]},
        {"key": "attendance.all", "label": "مشاهده کارکرد همه کارکنان", "roles": ["ADMIN", "CEO"]},
        {"key": "requests.view", "label": "مشاهده درخواستها", "roles": ["ADMIN", "CEO", "EMPLOYEE"]},
        {"key": "requests.decide", "label": "تأیید/رد درخواستها", "roles": ["ADMIN", "CEO"]},
    ]},
    {"group": "ابزارها", "items": [
        {"key": "kanban.view", "label": "برد کانبان", "roles": ["ADMIN", "CEO", "EMPLOYEE"]},
        {"key": "time.use", "label": "تایم ترکینگ", "roles": ["ADMIN", "CEO", "EMPLOYEE"]},
        {"key": "chat.use", "label": "گفتگو", "roles": ["ADMIN", "CEO", "EMPLOYEE"]},
        {"key": "chat.monitor", "label": "نظارت نامحسوس بر گفتگوها", "roles": ["ADMIN"]},
        {"key": "automations.manage", "label": "مدیریت اتوماسیونها", "roles": ["ADMIN", "CEO"]},
    ]},
    {"group": "تنظیمات", "items": [
        {"key": "settings.view", "label": "ورود به تنظیمات", "roles": ["ADMIN", "CEO"]},
        {"key": "settings.types", "label": "مدیریت انواع تسک/فرآیند/نقش/عملکرد", "roles": ["ADMIN", "CEO"]},
        {"key": "settings.request_types", "label": "مدیریت انواع درخواست", "roles": ["ADMIN", "CEO"]},
        {"key": "settings.kpi", "label": "مدیریت شاخصهای کلیدی (KPI)", "roles": ["ADMIN", "CEO"]},
        {"key": "settings.companies", "label": "زیربخش تعریف شرکت", "roles": ["ADMIN", "CEO"]},
        {"key": "settings.users", "label": "زیربخش کاربران", "roles": ["ADMIN", "CEO"]},
        {"key": "settings.permissions", "label": "زیربخش نقشها و دسترسیها", "roles": ["ADMIN", "CEO"]},
    ]},
    {"group": "مشتریان", "items": [
        {"key": "customers.view", "label": "مشاهده اشخاص و شرکتهای مشتری", "roles": ["ADMIN", "CEO", "EMPLOYEE"]},
        {"key": "customers.manage", "label": "تعریف/ویرایش/حذف اشخاص مشتری", "roles": ["ADMIN", "CEO"]},
        {"key": "customers.contracts", "label": "مدیریت قراردادها", "roles": ["ADMIN", "CEO"]},
        {"key": "customers.proformas", "label": "مدیریت پیش فاکتورها", "roles": ["ADMIN", "CEO"]},
        {"key": "customers.invoices", "label": "مدیریت فاکتورها", "roles": ["ADMIN", "CEO"]},
        {"key": "customers.tax", "label": "مدیریت سررسیدهای مالیاتی", "roles": ["ADMIN", "CEO"]},
        {"key": "customers.fees", "label": "مدیریت مطالبات و Fee", "roles": ["ADMIN", "CEO"]},
        {"key": "customers.moudian", "label": "مدیریت فاکتورهای مودیان", "roles": ["ADMIN", "CEO"]},
    ]},
]


def role_default_permissions(role: str) -> dict[str, bool]:
    return {item["key"]: role in item["roles"] for group in PERMISSION_CATALOG for item in group["items"]}


def effective_permissions(user: sqlite3.Row) -> dict[str, bool]:
    perms = role_default_permissions(user["role"])
    raw = user["permissions"] if "permissions" in user.keys() else None
    if raw:
        try:
            override = json.loads(raw)
            if isinstance(override, dict):
                for key, value in override.items():
                    if key in perms:
                        perms[key] = bool(value)
        except (ValueError, TypeError):
            pass
    # محافظت ضد قفلشدگی: مدیر فعال همیشه میتواند تنظیمات دسترسی را ببیند
    if user["role"] == "ADMIN":
        perms["users.view"] = True
        perms["users.permissions"] = True
        perms["settings.view"] = True
        perms["settings.permissions"] = True
    return perms


def has_perm(user: sqlite3.Row, key: str) -> bool:
    return effective_permissions(user).get(key, False)


def require_perm(user: sqlite3.Row, key: str) -> None:
    if not has_perm(user, key):
        raise HTTPException(403, "دسترسی لازم برای این عملیات را ندارید")


def can_access_company(con: sqlite3.Connection, user: sqlite3.Row, company_id: str) -> bool:
    if user["role"] in ("ADMIN", "CEO"):
        return True
    return con.execute("SELECT 1 FROM company_access WHERE user_id=? AND company_id=?", (user["id"], company_id)).fetchone() is not None


def task_access(con: sqlite3.Connection, user: sqlite3.Row, task_id: str) -> sqlite3.Row:
    task = con.execute("SELECT t.*,c.name AS company_name,c.code AS company_code,u.name AS assignee_name FROM tasks t JOIN companies c ON c.id=t.company_id JOIN users u ON u.id=t.assignee_id WHERE t.id=?", (task_id,)).fetchone()
    if task is None:
        raise HTTPException(404, "تسک پیدا نشد")
    if user["role"] not in ("ADMIN", "CEO") and task["assignee_id"] != user["id"]:
        raise HTTPException(403, "به این تسک دسترسی ندارید")
    return task


def normalize_digits(value: Any) -> str:
    s = str(value if value is not None else "").strip()
    trans = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
    return s.translate(trans)


def normalize_date_input(value: str | None) -> str | None:
    if value is None or not value.strip():
        return None
    return re.sub(r"\s+", "", normalize_digits(value).strip()).replace("-", "/").replace(".", "/")


ALIASES = {
    "row": ["ردیف", "شماره ردیف", "ردیف سند", "row", "row no", "linenumber"],
    "voucher": ["شماره سند", "شمارهسند", "شماره", "شماره سند حسابداری", "document number", "voucher", "docno"],
    "date": ["تاریخ سند", "تاریخ", "تاریخسند", "document date", "date"],
    "account": ["کد حساب", "حساب", "account", "accountcode", "کل/معین/تفصیل"],
    "major": ["کل", "کد کل", "حساب کل", "major account"],
    "middle": ["معین", "کد معین", "حساب معین", "sub account"],
    "detail": ["تفصیل", "کد تفصیل", "حساب تفصیل", "detail account"],
    "debit": ["بده", "بدهکار", "مبلغ بدهکار", "debit", "debit amount"],
    "credit": ["بس", "بستانکار", "مبلغ بستانکار", "credit", "credit amount"],
    "description": ["شرح سند", "شرح", "توضیحات", "description", "memo"],
}


def norm_header(value: Any) -> str:
    return re.sub(r"[\s_\-]+", "", normalize_digits(value).replace("ي", "ی").replace("ك", "ک").lower())


def parse_amount(value: Any) -> str:
    if value is None:
        return "0"
    s = normalize_digits(value).replace(",", "").replace("٬", "").replace("٫", ".").replace("ریال", "").replace("تومان", "").strip()
    if not s:
        return "0"
    try:
        return str(round(float(s), 2))
    except ValueError:
        return s


def parse_date(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (datetime, date)):
        return gregorian_to_jalali(value.date() if isinstance(value, datetime) else value)
    s = normalize_digits(value).strip().replace("-", "/").replace(".", "/")
    s = re.sub(r"\s+", "", s)
    match = re.fullmatch(r"(19\d{2}|20\d{2})/(\d{1,2})/(\d{1,2})", s)
    if match:
        try:
            return gregorian_to_jalali(date(int(match.group(1)), int(match.group(2)), int(match.group(3))))
        except ValueError:
            return s
    return s


def read_excel(upload: UploadFile, content: bytes) -> tuple[list[dict[str, str]], str]:
    if len(content) > MAX_UPLOAD:
        raise HTTPException(413, "حجم فایل بیشتر از ۲۰ مگابایت است")
    if upload.filename and Path(upload.filename).suffix.lower() != ".xlsx":
        raise HTTPException(400, "فقط فایل با پسوند .xlsx پذیرفته میشود")
    if not content.startswith(b"PK\x03\x04"):
        raise HTTPException(400, "فایل باید Excel با فرمت .xlsx باشد؛ فایلهای Macro دار پذیرفته نمیشوند")
    try:
        from openpyxl import load_workbook
        from io import BytesIO
        with zipfile.ZipFile(BytesIO(content)) as archive:
            members = archive.infolist()
            if len(members) > 500 or sum(item.file_size for item in members) > 150 * 1024 * 1024:
                raise HTTPException(413, "ساختار داخلی فایل از سقف پردازش مجاز بیشتر است")
            if any("vbaproject" in item.filename.lower() for item in members):
                raise HTTPException(400, "فایلهای دارای Macro پذیرفته نمیشوند")
        wb = load_workbook(BytesIO(content), read_only=True, data_only=True, keep_links=False)
        ws = wb.active
        if ws.max_row and ws.max_row > 200_001:
            raise HTTPException(413, "تعداد ردیفها از سقف مجاز بیشتر است")
        if len(wb.sheetnames) > 10:
            raise HTTPException(413, "تعداد برگههای فایل از سقف مجاز بیشتر است")
        header_row = None
        mapping: dict[str, int] = {}
        for idx, row in enumerate(ws.iter_rows(min_row=1, max_row=min(ws.max_row or 1, 15), values_only=True), 1):
            labels = [norm_header(v) for v in row]
            found: dict[str, int] = {}
            for field, variants in ALIASES.items():
                wanted = {norm_header(v) for v in variants}
                for col, label in enumerate(labels):
                    if label in wanted:
                        found[field] = col
                        break
            if "voucher" in found and "date" in found and ("debit" in found or "credit" in found):
                header_row, mapping = idx, found
                break
        if header_row is None:
            raise HTTPException(400, "سربرگهای الزامی پیدا نشدند. فایل نمونه را از بخش راهنما دریافت کنید.")
        rows: list[dict[str, str]] = []
        for excel_row, raw in enumerate(ws.iter_rows(min_row=header_row + 1, values_only=True), header_row + 1):
            if not any(v not in (None, "") for v in raw):
                continue
            def val(k: str) -> Any:
                col = mapping.get(k)
                return raw[col] if col is not None and col < len(raw) else ""
            account_parts = [normalize_digits(val(k)) for k in ("major", "middle", "detail") if normalize_digits(val(k))]
            account = "/".join(account_parts) if account_parts else normalize_digits(val("account"))
            row = {
                "source_row": str(excel_row),
                "line": normalize_digits(val("row")) or str(excel_row - header_row),
                "voucher": normalize_digits(val("voucher")),
                "date": parse_date(val("date")),
                "account": account,
                "debit": parse_amount(val("debit")),
                "credit": parse_amount(val("credit")),
                "description": norm_header(val("description")),
            }
            rows.append(row)
            if len(rows) > 200_000:
                raise HTTPException(413, "تعداد ردیفهای معتبر از سقف مجاز بیشتر است")
        if not rows:
            raise HTTPException(400, "فایل هیچ ردیف اطلاعاتی ندارد")
        return rows, wb.sheetnames[0]
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(400, "خواندن فایل Excel ناموفق بود؛ قالب یا سلامت فایل را بررسی کنید") from exc


def duplicate_key(row: dict[str, str]) -> tuple[str, ...]:
    return (row["voucher"], row["line"], row["date"], row["account"], row["debit"], row["credit"], row["description"])


def reconcile(sub_rows: list[dict[str, str]], ref_rows: list[dict[str, str]] | None, start: str | None, end: str | None) -> dict[str, Any]:
    seen: set[tuple[str, ...]] = set()
    duplicates = 0
    for row in sub_rows:
        key = duplicate_key(row)
        if key in seen:
            duplicates += 1
        seen.add(key)
    dates = [r["date"] for r in sub_rows if r["date"]]
    out_range = 0
    for d in dates:
        # Lexical range checks apply only to consistently formatted Gregorian or ISO dates;
        # Shamsi dates remain visible for manager review instead of being guessed.
        if start and end and re.match(r"^\d{4}/\d{2}/\d{2}$", d):
            if d < normalize_digits(start).replace("-", "/") or d > normalize_digits(end).replace("-", "/"):
                out_range += 1
    counts: dict[str, int] = {}
    for row in sub_rows:
        counts[row["voucher"]] = counts.get(row["voucher"], 0) + 1
    result: dict[str, Any] = {
        "algorithm_version": "yfg-reconcile-1.0.0",
        "row_count": len(sub_rows),
        "voucher_count": len({r["voucher"] for r in sub_rows if r["voucher"]}),
        "duplicate_rows": duplicates,
        "out_of_range": out_range,
        "min_date": min(dates) if dates else None,
        "max_date": max(dates) if dates else None,
        "debit_total": round(sum(float(r["debit"]) for r in sub_rows if re.fullmatch(r"-?\d+(?:\.\d+)?", r["debit"])), 2),
        "credit_total": round(sum(float(r["credit"]) for r in sub_rows if re.fullmatch(r"-?\d+(?:\.\d+)?", r["credit"])), 2),
        "claimed_start": start,
        "claimed_end": end,
        "reference_attached": ref_rows is not None,
        "reference_row_count": len(ref_rows) if ref_rows is not None else None,
        "matched_exact": None,
        "reference_only": None,
        "submission_only": None,
        "notes": ["شماره سند تکراری بهتنهایی خطا نیست؛ ردیفهای یک سند میتوانند شماره مشترک داشته باشند."],
    }
    result["balanced"] = result["debit_total"] == result["credit_total"]
    if ref_rows is not None:
        remaining = {}
        for r in ref_rows:
            key = duplicate_key(r)
            remaining[key] = remaining.get(key, 0) + 1
        matched = 0
        for r in sub_rows:
            key = duplicate_key(r)
            if remaining.get(key, 0):
                remaining[key] -= 1
                matched += 1
        ref_left = sum(remaining.values())
        result.update(matched_exact=matched, reference_only=ref_left, submission_only=len(sub_rows) - matched)
        result["notes"].append("تطبیق متنی دقیق انجام شده است؛ تفاوت قالب تاریخ یا شرح میتواند مورد را برای بررسی مدیر باقی بگذارد.")
    else:
        result["notes"].append("برای این تسک مرجع ثبت نشده؛ نتیجه تطبیق با روش NO_REFERENCE بررسی شود.")
    return result


# ============ Template validation (file structure check) ============

# Expected columns matching the /api/template download
TEMPLATE_EXPECTED_HEADERS = ["voucher", "date", "account", "debit", "credit", "description"]


def validate_template(rows: list[dict[str, str]]) -> dict[str, Any]:
    """Validates the structure of uploaded Excel against the system template.
    Returns: {valid: bool, errors: list[str], missing_columns: list[str], warnings: list[str]}
    """
    errors = []
    warnings = []
    if not rows:
        errors.append("فایل خالی است — هیچ ردیف اطلاعاتی پیدا نشد")
        return {"valid": False, "errors": errors, "warnings": warnings}

    # All required fields must be non-empty for at least one row
    missing_fields = []
    for field in TEMPLATE_EXPECTED_HEADERS:
        has_value = any(r.get(field, "") for r in rows)
        if not has_value:
            missing_fields.append(field)
    if missing_fields:
        errors.append(f"ستونهای الزامی خالی یا ناقص است: {', '.join(missing_fields)}")

    # Check at least one numeric value in debit/credit
    has_debit = any(re.fullmatch(r"-?\d+(?:\.\d+)?", r.get("debit", "")) for r in rows)
    has_credit = any(re.fullmatch(r"-?\d+(?:\.\d+)?", r.get("credit", "")) for r in rows)
    if not has_debit and not has_credit:
        errors.append("هیچ مقدار عددی در ستونهای بدهکار/بستانکار پیدا نشد")

    # Check duplicates within the same voucher+line
    seen_keys = set()
    duplicate_count = 0
    for r in rows:
        key = (r.get("voucher", ""), r.get("line", ""), r.get("date", ""))
        if key in seen_keys:
            duplicate_count += 1
        seen_keys.add(key)
    if duplicate_count:
        warnings.append(f"{duplicate_count} ردیف تکراری (شماره سند + خط + تاریخ یکسان) پیدا شد")

    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "warnings": warnings,
        "row_count": len(rows),
    }


# ============ Detailed row-level reconciliation ============

def reconcile_detailed(sub_rows: list[dict[str, str]], ref_rows: list[dict[str, str]] | None,
                       start: str | None, end: str | None) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Performs full reconciliation AND returns row-level diff list.
    Returns: (summary_report, diffs)
    Each diff: {source_row, voucher, line, date, account, debit, credit, description,
                issue_type, issue_detail, ref_debit, ref_credit, ref_date, ref_account, ref_description}
    """
    summary = reconcile(sub_rows, ref_rows, start, end)
    diffs: list[dict[str, Any]] = []

    # 1. Internal duplicate detection
    seen_keys: dict[tuple, int] = {}
    for r in sub_rows:
        key = duplicate_key(r)
        seen_keys[key] = seen_keys.get(key, 0) + 1

    for r in sub_rows:
        key = duplicate_key(r)
        src_row = int(r.get("source_row", 0))
        # 2. Out-of-range check
        if start and end and r.get("date"):
            d = r["date"]
            if re.match(r"^\d{4}/\d{2}/\d{2}$", d):
                if d < normalize_digits(start).replace("-", "/") or d > normalize_digits(end).replace("-", "/"):
                    diffs.append({
                        "source_row": src_row, "voucher": r["voucher"], "line": r["line"],
                        "date": r["date"], "account": r["account"], "debit": r["debit"],
                        "credit": r["credit"], "description": r["description"],
                        "issue_type": "OUT_OF_RANGE",
                        "issue_detail": f"تاریخ {d} خارج از بازه اعلامشده ({start} تا {end}) است",
                        "ref_debit": None, "ref_credit": None, "ref_date": None,
                        "ref_account": None, "ref_description": None,
                    })

    if ref_rows is None:
        # No reference — only internal checks (duplicates, out of range)
        for r in sub_rows:
            key = duplicate_key(r)
            if seen_keys[key] > 1:
                src_row = int(r.get("source_row", 0))
                diffs.append({
                    "source_row": src_row, "voucher": r["voucher"], "line": r["line"],
                    "date": r["date"], "account": r["account"], "debit": r["debit"],
                    "credit": r["credit"], "description": r["description"],
                    "issue_type": "DUPLICATE",
                    "issue_detail": "این ردیف با ردیف دیگری در فایل تکراری است (شماره سند + خط + تاریخ + حساب + مبالغ + شرح)",
                    "ref_debit": None, "ref_credit": None, "ref_date": None,
                    "ref_account": None, "ref_description": None,
                })
                seen_keys[key] -= 1  # only report duplicates once
        return summary, diffs

    # With reference — match by voucher+line (allows description differences)
    ref_index: dict[tuple[str, str], list[dict]] = {}
    for r in ref_rows:
        key = (r["voucher"], r["line"])
        ref_index.setdefault(key, []).append(r)

    consumed: dict[tuple[str, str], int] = {}  # (voucher, line) → consumption count
    matched_sub_rows: set[int] = set()

    for r in sub_rows:
        key = (r["voucher"], r["line"])
        candidates = ref_index.get(key, [])
        src_row = int(r.get("source_row", 0))
        matched = False
        consumed_count = consumed.get(key, 0)
        if consumed_count < len(candidates):
            ref_r = candidates[consumed_count]
            consumed[key] = consumed_count + 1
            matched_sub_rows.add(src_row)
            matched = True
            # Check if exact match
            if (r["date"] == ref_r["date"] and r["account"] == ref_r["account"] and
                r["debit"] == ref_r["debit"] and r["credit"] == ref_r["credit"] and
                r["description"] == ref_r["description"]):
                # Exact match — no diff
                pass
            else:
                # Found by voucher+line but values differ — record mismatch
                diff_details = []
                if r["date"] != ref_r["date"]:
                    diff_details.append(f"تاریخ: {r['date']} ≠ {ref_r['date']}")
                if r["account"] != ref_r["account"]:
                    diff_details.append(f"حساب: {r['account']} ≠ {ref_r['account']}")
                if r["debit"] != ref_r["debit"]:
                    diff_details.append(f"بدهکار: {r['debit']} ≠ {ref_r['debit']}")
                if r["credit"] != ref_r["credit"]:
                    diff_details.append(f"بستانکار: {r['credit']} ≠ {ref_r['credit']}")
                if r["description"] != ref_r["description"]:
                    diff_details.append(f"شرح متفاوت")
                # Determine primary issue type
                if r["debit"] != ref_r["debit"]:
                    issue_type = "DEBIT_MISMATCH"
                elif r["credit"] != ref_r["credit"]:
                    issue_type = "CREDIT_MISMATCH"
                elif r["date"] != ref_r["date"]:
                    issue_type = "DATE_MISMATCH"
                elif r["account"] != ref_r["account"]:
                    issue_type = "ACCOUNT_MISMATCH"
                else:
                    issue_type = "DESCRIPTION_MISMATCH"
                diffs.append({
                    "source_row": src_row, "voucher": r["voucher"], "line": r["line"],
                    "date": r["date"], "account": r["account"], "debit": r["debit"],
                    "credit": r["credit"], "description": r["description"],
                    "issue_type": issue_type,
                    "issue_detail": "، ".join(diff_details),
                    "ref_debit": ref_r["debit"], "ref_credit": ref_r["credit"],
                    "ref_date": ref_r["date"], "ref_account": ref_r["account"],
                    "ref_description": ref_r["description"],
                })
        if not matched:
            # Submission row not found in reference at all
            diffs.append({
                "source_row": src_row, "voucher": r["voucher"], "line": r["line"],
                "date": r["date"], "account": r["account"], "debit": r["debit"],
                "credit": r["credit"], "description": r["description"],
                "issue_type": "MISSING_FROM_REFERENCE",
                "issue_detail": "این ردیف در فایل مرجع پیدا نشد (شماره سند + خط در مرجع وجود ندارد)",
                "ref_debit": None, "ref_credit": None, "ref_date": None,
                "ref_account": None, "ref_description": None,
            })

    # Internal duplicates check (within submission itself)
    for r in sub_rows:
        key = duplicate_key(r)
        if seen_keys[key] > 1:
            src_row = int(r.get("source_row", 0))
            diffs.append({
                "source_row": src_row, "voucher": r["voucher"], "line": r["line"],
                "date": r["date"], "account": r["account"], "debit": r["debit"],
                "credit": r["credit"], "description": r["description"],
                "issue_type": "DUPLICATE",
                "issue_detail": "ردیف تکراری در فایل ارسالی (همه فیلدها یکسان)",
                "ref_debit": None, "ref_credit": None, "ref_date": None,
                "ref_account": None, "ref_description": None,
            })
            seen_keys[key] -= 1

    # Out-of-range rows
    if start and end:
        for r in sub_rows:
            d = r.get("date", "")
            if d and re.match(r"^\d{4}/\d{2}/\d{2}$", d):
                if d < normalize_digits(start).replace("-", "/") or d > normalize_digits(end).replace("-", "/"):
                    src_row = int(r.get("source_row", 0))
                    diffs.append({
                        "source_row": src_row, "voucher": r["voucher"], "line": r["line"],
                        "date": r["date"], "account": r["account"], "debit": r["debit"],
                        "credit": r["credit"], "description": r["description"],
                        "issue_type": "OUT_OF_RANGE",
                        "issue_detail": f"تاریخ {d} خارج از بازه ({start} تا {end})",
                        "ref_debit": None, "ref_credit": None, "ref_date": None,
                        "ref_account": None, "ref_description": None,
                    })

    summary["diff_count"] = len(diffs)
    summary["diffs"] = diffs
    return summary, diffs


class SetupModel(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    username: str = Field(min_length=3, max_length=50)
    password: str = Field(min_length=4, max_length=200)


class LoginModel(BaseModel):
    username: str
    password: str


class UserCreate(BaseModel):
    name: str | None = Field(default=None, min_length=2, max_length=100)
    first_name: str = Field(default="", max_length=80)
    last_name: str = Field(default="", max_length=80)
    phone: str = Field(default="", max_length=30)
    username: str = Field(min_length=3, max_length=50)
    password: str = Field(min_length=4, max_length=200)
    password2: str | None = Field(default=None, max_length=200)
    role: str = "EMPLOYEE"
    company_ids: list[str] = []


class UserUpdate(BaseModel):
    name: str | None = None
    first_name: str | None = None
    last_name: str | None = None
    phone: str | None = None
    role: str | None = None
    active: bool | None = None
    password: str | None = None
    password2: str | None = None
    company_ids: list[str] | None = None


class CompanyCreate(BaseModel):
    code: str = Field(min_length=1, max_length=40)
    name: str | None = Field(default=None, min_length=2, max_length=120)
    kind: str = Field(default="LEGAL", pattern="^(LEGAL|REAL)$")
    first_name: str = Field(default="", max_length=80)
    last_name: str = Field(default="", max_length=80)
    national_id: str = Field(default="", max_length=20)
    phone: str = Field(default="", max_length=30)
    address: str = Field(default="", max_length=300)
    postal_code: str = Field(default="", max_length=20)
    manager_name: str = Field(default="", max_length=120)
    manager_phone: str = Field(default="", max_length=30)
    description: str = Field(default="", max_length=4000)


class CompanyUpdate(BaseModel):
    name: str | None = None
    code: str | None = None
    kind: str | None = Field(default=None, pattern="^(LEGAL|REAL)$")
    first_name: str | None = None
    last_name: str | None = None
    national_id: str | None = None
    phone: str | None = None
    address: str | None = None
    postal_code: str | None = None
    manager_name: str | None = None
    manager_phone: str | None = None
    description: str | None = None
    active: bool | None = None


class TaskCreate(BaseModel):
    company_id: str
    title: str = Field(min_length=3, max_length=160)
    description: str = Field(default="", max_length=4000)
    fiscal_period: str = Field(default="", max_length=40)
    scope: str = Field(default="", max_length=500)
    priority: str = "NORMAL"
    weight: int = Field(default=1, ge=1, le=3)
    due_date: str | None = None
    assignee_id: str
    collaborator_ids: list[str] = []  # Multi-assignee support
    checklist_steps: list[str] = []  # 5-step workflow


class TaskUpdate(BaseModel):
    progress: int | None = Field(default=None, ge=0, le=100)
    status: str | None = None
    assignee_id: str | None = None
    reference_version_id: str | None = None
    reason: str = ""


class ChecklistModel(BaseModel):
    steps: list[str] = []  # Up to 5 step titles


class ChecklistToggleModel(BaseModel):
    step_number: int
    is_done: bool


class PerformanceCreateModel(BaseModel):
    work_date: str = Field(min_length=8, max_length=12)
    category: str = Field(min_length=2, max_length=32)
    title: str = Field(min_length=2, max_length=120)
    description: str = Field(default="", max_length=2000)
    duration_minutes: int = Field(ge=1, le=1440)
    checklist_steps: list[str] = []
    delegate_to: str | None = None
    delegate_scope: str = ""


class PerformanceScoreModel(BaseModel):
    score: int = Field(ge=0, le=100)
    reason: str = Field(default="", max_length=500)


class PerformanceDelegateModel(BaseModel):
    to_user: str
    scope: str = Field(default="", max_length=500)


class DelegateModel(BaseModel):
    assignee_id: str
    title: str = Field(min_length=3, max_length=160)
    scope: str = Field(min_length=3, max_length=500)
    description: str = Field(default="", max_length=4000)
    due_date: str | None = None


class DecisionModel(BaseModel):
    decision: str
    score: int | None = Field(default=None, ge=0, le=100)
    review_method: str
    reason: str = ""
    exception_reason: str = ""


class CommentModel(BaseModel):
    body: str = Field(min_length=1, max_length=4000)
    visibility: str = "EMPLOYEE_VISIBLE"


class RequestModel(BaseModel):
    kind: str = "GENERAL"
    request_type_id: str | None = None  # if a request_type is selected
    data: dict = {}  # dynamic field values: name -> value
    user_name_override: str = ""  # when filled by someone else on behalf
    # legacy fields still supported
    start_date: str | None = None
    end_date: str | None = None
    body: str = ""

class ReviewRequestModel(BaseModel):
    status: str
    review_note: str = ""

class RequestTypeCreateModel(BaseModel):
    code: str
    name: str
    icon: str = "📝"
    fields: list[dict] = []  # array of field specs
    active: int = 1

class RequestTypeUpdateModel(BaseModel):
    name: str | None = None
    icon: str | None = None
    fields: list[dict] | None = None
    active: int | None = None


class PerformanceEntryModel(BaseModel):
    work_date: str = Field(min_length=8, max_length=12)
    category: str = Field(min_length=2, max_length=32)
    title: str = Field(min_length=2, max_length=120)
    description: str = Field(default="", max_length=2000)
    duration_minutes: int = Field(ge=1, le=1440)
    # Task-parity fields
    company_id: str = Field(default="", max_length=64)
    fiscal_period: str = Field(default="", max_length=40)
    scope: str = Field(default="", max_length=500)
    priority: str = Field(default="NORMAL", max_length=20)
    weight: int = Field(default=1, ge=1, le=3)
    due_date: str = Field(default="", max_length=12)
    progress: int = Field(default=0, ge=0, le=100)


class PerformanceReviewModel(BaseModel):
    status: str
    review_note: str = Field(default="", max_length=1000)


@app.get("/", response_class=HTMLResponse)
def home():
    return FileResponse(ROOT / "app" / "static" / "index.html")


@app.get("/manifest.webmanifest")
def manifest():
    return FileResponse(ROOT / "app" / "static" / "manifest.webmanifest", media_type="application/manifest+json")


@app.get("/sw.js")
def service_worker():
    return FileResponse(ROOT / "app" / "static" / "sw.js", media_type="application/javascript", headers={"Service-Worker-Allowed": "/"})


@app.get("/api/status")
def status():
    with db() as con:
        return {"setup_needed": con.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0, "product": "YFG Accounting Desk", "version": "0.3.0.17"}


@app.post("/api/setup")
def setup(payload: SetupModel, request: Request):
    with db() as con:
        if con.execute("SELECT COUNT(*) FROM users").fetchone()[0]:
            raise HTTPException(409, "راهاندازی اولیه قبلاً انجام شده است")
        if not re.fullmatch(r"[A-Za-z0-9_.-]+", payload.username):
            raise HTTPException(400, "نام کاربری فقط میتواند شامل حروف انگلیسی، عدد و . _ - باشد")
        user_id = uid()
        con.execute("INSERT INTO users (id,name,username,password_hash,role,active,created_at,first_name,last_name,phone,permissions) VALUES(?,?,?,?,?,?,?,?,?,?,?)", (user_id, payload.name, payload.username.lower(), password_hash(payload.password), "ADMIN", 1, now(), "", "", "", None))
        audit(con, user_id, "INITIAL_SETUP", "user", user_id)
        issue_session(con, user_id, request)
        return {"ok": True, "user": {"id": user_id, "name": payload.name, "username": payload.username, "role": "ADMIN"}}


def issue_session(con: sqlite3.Connection, user_id: str, request: Request) -> None:
    token = secrets.token_urlsafe(32)
    con.execute("INSERT INTO sessions VALUES(?,?,?,?)", (hashlib.sha256(token.encode()).hexdigest(), user_id, datetime.now(timezone.utc).replace(year=datetime.now(timezone.utc).year + 1).isoformat(timespec="seconds"), now()))
    request.state.session_token = token


@app.middleware("http")
async def session_cookie_middleware(request: Request, call_next):
    if request.method in ("POST", "PUT", "PATCH", "DELETE"):
        origin = request.headers.get("origin")
        if origin:
            host = request.headers.get("host", "")
            # Allow requests from same origin OR from localhost variants (for proxy setups)
            allowed_origins = {
                f"http://{host}", f"https://{host}",
                "http://localhost:3000", "http://127.0.0.1:3000",
                "http://localhost:8000", "http://127.0.0.1:8000",
            }
            if False:  # disabled for now
                return HTMLResponse("درخواست مبدأ نامعتبر است", status_code=403)
    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "no-referrer")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    response.headers.setdefault("Content-Security-Policy", "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'")
    if request.url.path.startswith("/api/"):
        response.headers.setdefault("Cache-Control", "no-store")
    token = getattr(request.state, "session_token", None)
    if token:
        response.set_cookie("yfg_session", token, httponly=True, secure=request.url.scheme == "https", samesite="lax", max_age=31_536_000, path="/")
    return response


@app.post("/api/auth/login")
def login(payload: LoginModel, request: Request):
    with db() as con:
        user = con.execute("SELECT * FROM users WHERE username=? AND active=1", (payload.username.lower(),)).fetchone()
        if user is None or not password_ok(payload.password, user["password_hash"]):
            raise HTTPException(401, "نام کاربری یا گذرواژه نادرست است")
        issue_session(con, user["id"], request)
        audit(con, user["id"], "LOGIN", "user", user["id"])
        return {"ok": True}


@app.post("/api/auth/logout")
def logout(request: Request):
    token = request.cookies.get("yfg_session")
    if token:
        with db() as con:
            con.execute("DELETE FROM sessions WHERE token_hash=?", (hashlib.sha256(token.encode()).hexdigest(),))
    from fastapi.responses import JSONResponse
    response = JSONResponse({"ok": True})
    response.delete_cookie("yfg_session", path="/")
    return response


@app.get("/api/me")
def me(request: Request):
    user = current_user(request)
    return {"id": user["id"], "name": user["name"], "username": user["username"], "role": user["role"],
            "first_name": user["first_name"], "last_name": user["last_name"], "phone": user["phone"],
            "permissions": effective_permissions(user)}


# ===== PERMISSION MANAGEMENT ENDPOINTS (نقشها و دسترسیها) =====

@app.get("/api/permissions/catalog")
def permissions_catalog(request: Request):
    user = current_user(request)
    require_perm(user, "users.view")
    return {
        "catalog": PERMISSION_CATALOG,
        "role_defaults": {role: role_default_permissions(role) for role in ("ADMIN", "CEO", "EMPLOYEE")},
    }


@app.get("/api/users/{user_id}/permissions")
def get_user_permissions(user_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "users.view")
    with db() as con:
        target = con.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
        if not target:
            raise HTTPException(404, "کاربر یافت نشد")
        override = None
        if target["permissions"]:
            try:
                override = json.loads(target["permissions"])
            except (ValueError, TypeError):
                override = None
        companies = con.execute("""SELECT c.id, c.code, c.name, c.kind FROM company_access a
                                   JOIN companies c ON c.id=a.company_id WHERE a.user_id=? ORDER BY c.name""",
                                (user_id,)).fetchall()
        return {
            "user": {"id": target["id"], "name": target["name"], "username": target["username"],
                     "role": target["role"], "active": target["active"]},
            "effective": effective_permissions(target),
            "override": override,
            "role_defaults": role_default_permissions(target["role"]),
            "companies": [dict(c) for c in companies],
        }


class PermissionsModel(BaseModel):
    permissions: dict[str, bool] | None = None  # None = بازگشت به پیشفرض نقش


@app.put("/api/users/{user_id}/permissions")
def set_user_permissions(user_id: str, payload: PermissionsModel, request: Request):
    user = current_user(request)
    require_perm(user, "users.permissions")
    if payload.permissions is not None and user_id == user["id"]:
        # جلوگیری از قفلشدن مدیر روی خودش
        raise HTTPException(400, "برای حساب خودتان نمیتوانید دسترسیها را محدود کنید")
    with db() as con:
        target = con.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
        if not target:
            raise HTTPException(404, "کاربر یافت نشد")
        if payload.permissions is None:
            con.execute("UPDATE users SET permissions=NULL WHERE id=?", (user_id,))
            audit(con, user["id"], "PERMISSIONS_RESET", "user", user_id, {"role": target["role"]})
        else:
            valid_keys = {item["key"] for group in PERMISSION_CATALOG for item in group["items"]}
            clean = {k: bool(v) for k, v in payload.permissions.items() if k in valid_keys}
            con.execute("UPDATE users SET permissions=? WHERE id=?", (json.dumps(clean, ensure_ascii=False), user_id))
            audit(con, user["id"], "PERMISSIONS_SET", "user", user_id, {"count": len(clean)})
        updated = con.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
        con.execute("DELETE FROM sessions WHERE user_id=?", (user_id,))  # اعمال فوری دسترسیها
        return {"ok": True, "effective": effective_permissions(updated)}


@app.get("/api/dashboard")
def dashboard(request: Request):
    user = current_user(request)
    with db() as con:
        where, args = ("", []) if user["role"] in ("ADMIN", "CEO") else ("WHERE assignee_id=?", [user["id"]])
        tasks = con.execute(f"SELECT status,COUNT(*) n FROM tasks {where} GROUP BY status", args).fetchall()
        task_counts = {r["status"]: r["n"] for r in tasks}
        pending_reviews = con.execute("SELECT COUNT(*) FROM tasks WHERE status='SUBMITTED'").fetchone()[0] if user["role"] in ("ADMIN", "CEO") else 0
        open_requests = con.execute("SELECT COUNT(*) FROM requests WHERE status='PENDING'").fetchone()[0] if user["role"] in ("ADMIN", "CEO") else con.execute("SELECT COUNT(*) FROM requests WHERE user_id=? AND status='PENDING'", (user["id"],)).fetchone()[0]
        latest = con.execute(f"SELECT t.id,t.title,t.status,t.progress,t.due_date,c.name company_name,u.name assignee_name FROM tasks t JOIN companies c ON c.id=t.company_id JOIN users u ON u.id=t.assignee_id {where} ORDER BY t.updated_at DESC LIMIT 8", args).fetchall()
        notifs = con.execute("SELECT id,title,body,created_at FROM notifications WHERE user_id=? AND read_at IS NULL ORDER BY created_at DESC LIMIT 8", (user["id"],)).fetchall()
        return {"counts": task_counts, "pending_reviews": pending_reviews, "open_requests": open_requests, "tasks": [dict(r) for r in latest], "notifications": [dict(r) for r in notifs]}


@app.get("/api/companies")
def companies(request: Request):
    user = current_user(request)
    require_perm(user, "companies.view")
    with db() as con:
        if user["role"] in ("ADMIN", "CEO"):
            rows = con.execute("SELECT * FROM companies ORDER BY name").fetchall()
        else:
            rows = con.execute("SELECT c.* FROM companies c JOIN company_access a ON a.company_id=c.id WHERE a.user_id=? AND c.active=1 ORDER BY c.name", (user["id"],)).fetchall()
        return [dict(r) for r in rows]


@app.get("/api/companies/{company_id}/references")
def list_references(company_id: str, request: Request):
    user = current_user(request)
    with db() as con:
        if not can_access_company(con, user, company_id):
            raise HTTPException(403, "به این شرکت دسترسی ندارید")
        return [dict(r) for r in con.execute("SELECT id,fiscal_period,version,original_name,stored_name,sha256,row_count,coverage_start,coverage_end,created_at FROM reference_versions WHERE company_id=? ORDER BY fiscal_period DESC,version DESC", (company_id,))]


@app.post("/api/companies")
def add_company(payload: CompanyCreate, request: Request):
    user = current_user(request)
    require_perm(user, "companies.manage")
    # نام: برای حقیقی از نام + نام خانوادگی ساخته میشود اگر خالی باشد
    name = (payload.name or "").strip()
    if payload.kind == "REAL" and not name:
        name = f"{payload.first_name.strip()} {payload.last_name.strip()}".strip()
    if not name or len(name) < 2:
        raise HTTPException(400, "نام شرکت یا نام و نام خانوادگی شخص الزامی است")
    with db() as con:
        company_id = uid()
        try:
            con.execute(
                "INSERT INTO companies(id,code,name,active,created_at,kind,first_name,last_name,national_id,phone,address,postal_code,manager_name,manager_phone,description) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (company_id, payload.code.strip(), name, 1, now(), payload.kind,
                 payload.first_name.strip(), payload.last_name.strip(), payload.national_id.strip(),
                 payload.phone.strip(), payload.address.strip(), payload.postal_code.strip(),
                 payload.manager_name.strip(), payload.manager_phone.strip(), payload.description.strip() if payload.description else "")
            )
        except sqlite3.IntegrityError:
            raise HTTPException(409, "کد شرکت تکراری است")
        audit(con, user["id"], "COMPANY_CREATE", "company", company_id, {"code": payload.code, "kind": payload.kind})
        return {"id": company_id, "code": payload.code, "name": name, "kind": payload.kind}


@app.get("/api/users")
def users(request: Request):
    user = current_user(request)
    require_perm(user, "users.view")
    with db() as con:
        rows = con.execute("SELECT id,name,username,role,active,created_at,first_name,last_name,phone,permissions FROM users ORDER BY name").fetchall()
        result = []
        for r in rows:
            d = dict(r)
            d.pop("permissions", None)  # خروجی خام دسترسیها را لو نده
            n_access = con.execute("SELECT COUNT(*) FROM company_access WHERE user_id=?", (r["id"],)).fetchone()[0]
            d["company_count"] = n_access
            result.append(d)
        return result


@app.post("/api/users")
def add_user(payload: UserCreate, request: Request):
    user = current_user(request)
    require_perm(user, "users.manage")
    if payload.role not in ("EMPLOYEE", "CEO", "ADMIN"):
        raise HTTPException(400, "نقش نامعتبر است")
    if not re.fullmatch(r"[A-Za-z0-9_.-]+", payload.username):
        raise HTTPException(400, "نام کاربری فقط میتواند شامل حروف انگلیسی، عدد و . _ - باشد")
    if payload.password2 is not None and payload.password != payload.password2:
        raise HTTPException(400, "رمز عبور و تکرار آن یکسان نیستند")
    full_name = (payload.name or "").strip()
    if not full_name:
        full_name = f"{payload.first_name.strip()} {payload.last_name.strip()}".strip()
    if len(full_name) < 2:
        raise HTTPException(400, "نام و نام خانوادگی الزامی است")
    with db() as con:
        new_id = uid()
        try:
            con.execute(
                "INSERT INTO users(id,name,username,password_hash,role,active,created_at,first_name,last_name,phone,permissions) VALUES(?,?,?,?,?,1,?,?,?,?,NULL)",
                (new_id, full_name, payload.username.lower(), password_hash(payload.password), payload.role, now(),
                 payload.first_name.strip(), payload.last_name.strip(), payload.phone.strip())
            )
            for company_id in set(payload.company_ids):
                if not con.execute("SELECT 1 FROM companies WHERE id=?", (company_id,)).fetchone():
                    raise HTTPException(400, "شرکت انتخابشده معتبر نیست")
                con.execute("INSERT INTO company_access VALUES(?,?)", (new_id, company_id))
        except sqlite3.IntegrityError:
            raise HTTPException(409, "نام کاربری تکراری است")
        audit(con, user["id"], "USER_CREATE", "user", new_id, {"role": payload.role, "company_count": len(set(payload.company_ids))})
        return {"id": new_id, "name": full_name, "username": payload.username, "role": payload.role}


# ===== USER MANAGEMENT (edit, deactivate, access control) =====

@app.get("/api/users/{user_id}")
def get_user_detail(user_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "users.view")
    with db() as con:
        u = con.execute("SELECT id,name,username,role,active,created_at,first_name,last_name,phone FROM users WHERE id=?", (user_id,)).fetchone()
        if not u:
            raise HTTPException(404, "کاربر یافت نشد")
        access = con.execute("""SELECT c.id, c.code, c.name FROM company_access a
                                JOIN companies c ON c.id=a.company_id WHERE a.user_id=?""", (user_id,)).fetchall()
        task_count = con.execute("SELECT COUNT(*) FROM tasks WHERE assignee_id=?", (user_id,)).fetchone()[0]
        return {**dict(u), "companies": [dict(r) for r in access], "task_count": task_count}

@app.patch("/api/users/{user_id}")
def update_user(user_id: str, payload: UserUpdate, request: Request):
    user = current_user(request)
    require_perm(user, "users.manage")
    with db() as con:
        existing = con.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
        if not existing:
            raise HTTPException(404, "کاربر یافت نشد")
        updates = {}
        if payload.first_name is not None:
            updates["first_name"] = payload.first_name.strip()
        if payload.last_name is not None:
            updates["last_name"] = payload.last_name.strip()
        if payload.phone is not None:
            updates["phone"] = payload.phone.strip()
        if payload.name is not None and payload.name.strip():
            updates["name"] = payload.name.strip()
        elif payload.first_name is not None or payload.last_name is not None:
            fn = updates.get("first_name", existing["first_name"])
            ln = updates.get("last_name", existing["last_name"])
            composed = f"{fn} {ln}".strip()
            if len(composed) >= 2:
                updates["name"] = composed
        if payload.role is not None:
            if payload.role not in ("EMPLOYEE", "CEO", "ADMIN"):
                raise HTTPException(400, "نقش نامعتبر")
            updates["role"] = payload.role
        if payload.active is not None:
            updates["active"] = 1 if payload.active else 0
        if payload.password is not None:
            if payload.password2 is not None and payload.password != payload.password2:
                raise HTTPException(400, "رمز عبور و تکرار آن یکسان نیستند")
            if len(payload.password) < 4:
                raise HTTPException(400, "رمز عبور باید حداقل ۴ نویسه باشد")
            updates["password_hash"] = password_hash(payload.password)
        if updates:
            set_clause = ", ".join(f"{k}=?" for k in updates)
            con.execute(f"UPDATE users SET {set_clause} WHERE id=?", (*updates.values(), user_id))
            audit(con, user["id"], "USER_UPDATE", "user", user_id, {k: str(v)[:50] for k, v in updates.items()})
        # جایگزینی کامل شرکتهای واگذارشده در صورت ارسال
        if payload.company_ids is not None:
            for company_id in set(payload.company_ids):
                if not con.execute("SELECT 1 FROM companies WHERE id=?", (company_id,)).fetchone():
                    raise HTTPException(400, "شرکت انتخابشده معتبر نیست")
            con.execute("DELETE FROM company_access WHERE user_id=?", (user_id,))
            for company_id in set(payload.company_ids):
                con.execute("INSERT INTO company_access VALUES(?,?)", (user_id, company_id))
            audit(con, user["id"], "ACCESS_REPLACE", "user", user_id, {"company_count": len(set(payload.company_ids))})
        return {"ok": True, "id": user_id}

@app.delete("/api/users/{user_id}")
def deactivate_user(user_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "users.manage")
    if user_id == user["id"]:
        raise HTTPException(400, "نمیتوانید حساب خودتان را غیرفعال کنید")
    with db() as con:
        existing = con.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
        if not existing:
            raise HTTPException(404, "کاربر یافت نشد")
        con.execute("UPDATE users SET active=0 WHERE id=?", (user_id,))
        # Also invalidate all sessions
        con.execute("DELETE FROM sessions WHERE user_id=?", (user_id,))
        audit(con, user["id"], "USER_DEACTIVATE", "user", user_id, {})
        return {"ok": True}

class GrantAccessModel(BaseModel):
    company_ids: list[str] = []

@app.post("/api/users/{user_id}/company-access")
def grant_company_access(user_id: str, payload: GrantAccessModel, request: Request):
    user = current_user(request)
    require_perm(user, "users.manage")
    with db() as con:
        u = con.execute("SELECT 1 FROM users WHERE id=? AND active=1", (user_id,)).fetchone()
        if not u:
            raise HTTPException(404, "کاربر یافت نشد")
        added = 0
        for cid in payload.company_ids:
            if con.execute("SELECT 1 FROM companies WHERE id=? AND active=1", (cid,)).fetchone():
                try:
                    con.execute("INSERT INTO company_access VALUES(?,?)", (user_id, cid))
                    added += 1
                except sqlite3.IntegrityError:
                    pass  # Already exists
        audit(con, user["id"], "ACCESS_GRANT", "user", user_id, {"companies_added": added})
        return {"ok": True, "added": added}

@app.delete("/api/users/{user_id}/company-access/{company_id}")
def revoke_company_access(user_id: str, company_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "users.manage")
    with db() as con:
        con.execute("DELETE FROM company_access WHERE user_id=? AND company_id=?", (user_id, company_id))
        audit(con, user["id"], "ACCESS_REVOKE", "user", user_id, {"company_id": company_id})
        return {"ok": True}


# ===== COMPANY MANAGEMENT (edit, deactivate) =====

@app.patch("/api/companies/{company_id}")
def update_company(company_id: str, payload: CompanyUpdate, request: Request):
    user = current_user(request)
    require_perm(user, "companies.manage")
    with db() as con:
        existing = con.execute("SELECT * FROM companies WHERE id=?", (company_id,)).fetchone()
        if not existing:
            raise HTTPException(404, "شرکت یافت نشد")
        updates = {}
        if payload.name is not None and payload.name.strip():
            updates["name"] = payload.name.strip()
        if payload.code is not None:
            # Check uniqueness
            dup = con.execute("SELECT 1 FROM companies WHERE code=? AND id!=?", (payload.code.strip(), company_id)).fetchone()
            if dup:
                raise HTTPException(409, "کد شرکت تکراری است")
            updates["code"] = payload.code.strip()
        if payload.kind is not None:
            updates["kind"] = payload.kind
        for field in ("first_name", "last_name", "national_id", "phone", "address", "postal_code", "manager_name", "manager_phone"):
            value = getattr(payload, field)
            if value is not None:
                updates[field] = value.strip()
        if payload.description is not None:
            updates["description"] = payload.description.strip()
        if payload.active is not None:
            updates["active"] = 1 if payload.active else 0
        if updates:
            set_clause = ", ".join(f"{k}=?" for k in updates)
            con.execute(f"UPDATE companies SET {set_clause} WHERE id=?", (*updates.values(), company_id))
            audit(con, user["id"], "COMPANY_UPDATE", "company", company_id, {k: str(v)[:50] for k, v in updates.items()})
        return {"ok": True, "id": company_id}

@app.delete("/api/companies/{company_id}")
def deactivate_company(company_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "companies.manage")
    with db() as con:
        existing = con.execute("SELECT * FROM companies WHERE id=?", (company_id,)).fetchone()
        if not existing:
            raise HTTPException(404, "شرکت یافت نشد")
        # Check for active tasks
        active_tasks = con.execute("SELECT COUNT(*) FROM tasks WHERE company_id=? AND status NOT IN ('APPROVED','APPROVED_WITH_EXCEPTION','CANCELLED')", (company_id,)).fetchone()[0]
        if active_tasks > 0:
            raise HTTPException(400, f"این شرکت {active_tasks} تسک فعال دارد؛ ابتدا تسکها را ببندید")
        con.execute("UPDATE companies SET active=0 WHERE id=?", (company_id,))
        audit(con, user["id"], "COMPANY_DEACTIVATE", "company", company_id, {})
        return {"ok": True}

@app.get("/api/companies/{company_id}/employees")
def company_employees(company_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "users.view")
    with db() as con:
        if not can_access_company(con, user, company_id):
            raise HTTPException(403, "دسترسی ندارید")
        rows = con.execute("""SELECT u.id,u.name,u.username,u.role,u.active FROM users u
                              JOIN company_access a ON a.user_id=u.id WHERE a.company_id=? ORDER BY u.name""", (company_id,)).fetchall()
        return [dict(r) for r in rows]


# ===== PASSWORD CHANGE =====

class PasswordChange(BaseModel):
    old_password: str
    new_password: str

@app.post("/api/auth/change-password")
def change_password(payload: PasswordChange, request: Request):
    user = current_user(request)
    if len(payload.new_password) < 4:
        raise HTTPException(400, "رمز جدید باید حداقل ۴ نویسه باشد")
    with db() as con:
        stored = con.execute("SELECT password_hash FROM users WHERE id=?", (user["id"],)).fetchone()
        if not stored or not password_ok(payload.old_password, stored["password_hash"]):
            raise HTTPException(400, "رمز فعلی نادرست است")
        con.execute("UPDATE users SET password_hash=? WHERE id=?", (password_hash(payload.new_password), user["id"]))
        # Invalidate all other sessions
        con.execute("DELETE FROM sessions WHERE user_id!=? OR user_id=?", (user["id"], user["id"]))
        # Actually delete all sessions except we'll create a new one
        con.execute("DELETE FROM sessions WHERE user_id=?", (user["id"],))
        audit(con, user["id"], "PASSWORD_CHANGE", "user", user["id"], {})
        return {"ok": True, "message": "رمز تغییر یافت؛ لطفاً دوباره وارد شوید"}


# ===== ENHANCED DASHBOARD =====

@app.get("/api/dashboard/v2")
def dashboard_v2(request: Request):
    user = current_user(request)
    require_perm(user, "reports.kpi")
    with db() as con:
        total_companies = con.execute("SELECT COUNT(*) FROM companies WHERE active=1").fetchone()[0]
        total_users = con.execute("SELECT COUNT(*) FROM users WHERE active=1").fetchone()[0]
        total_tasks = con.execute("SELECT COUNT(*) FROM tasks").fetchone()[0]
        open_tasks = con.execute("SELECT COUNT(*) FROM tasks WHERE status NOT IN ('APPROVED','APPROVED_WITH_EXCEPTION','CANCELLED')").fetchone()[0]
        overdue = con.execute("SELECT COUNT(*) FROM tasks WHERE due_date < ? AND status NOT IN ('APPROVED','APPROVED_WITH_EXCEPTION','CANCELLED')", (now(),)).fetchone()[0]
        submitted = con.execute("SELECT COUNT(*) FROM tasks WHERE status='SUBMITTED'").fetchone()[0]
        returned = con.execute("SELECT COUNT(*) FROM tasks WHERE status='RETURNED'").fetchone()[0]
        approved = con.execute("SELECT COUNT(*) FROM tasks WHERE status IN ('APPROVED','APPROVED_WITH_EXCEPTION')").fetchone()[0]
        pending_reviews = con.execute("SELECT COUNT(*) FROM tasks WHERE status IN ('SUBMITTED','RECONCILING','NEEDS_REVIEW')").fetchone()[0]
        total_submissions = con.execute("SELECT COUNT(*) FROM submissions").fetchone()[0]
        pending_leaves = con.execute("SELECT COUNT(*) FROM requests WHERE status='PENDING'").fetchone()[0]
        total_time = con.execute("SELECT COALESCE(SUM(duration_seconds),0) FROM time_entries WHERE end_at IS NOT NULL").fetchone()[0]
        avg_score = con.execute("SELECT COALESCE(AVG(score),0) FROM decisions WHERE score IS NOT NULL").fetchone()[0]

        # Recent activity
        recent_tasks = con.execute("""SELECT t.id,t.title,t.status,t.priority,t.weight,t.due_date,
                                       c.name AS company_name,c.code AS company_code,
                                       u.name AS assignee_name,t.updated_at
                                       FROM tasks t JOIN companies c ON c.id=t.company_id
                                       JOIN users u ON u.id=t.assignee_id
                                       ORDER BY t.updated_at DESC LIMIT 10""").fetchall()
        recent_decisions = con.execute("""SELECT d.id,d.decision,d.score,d.created_at,
                                          t.title AS task_title,u.name AS reviewer_name
                                          FROM decisions d JOIN tasks t ON t.id=d.task_id
                                          JOIN users u ON u.id=d.manager_id
                                          ORDER BY d.created_at DESC LIMIT 10""").fetchall()
        recent_audit = con.execute("""SELECT a.*,u.name AS actor_name FROM audit_events a
                                     LEFT JOIN users u ON u.id=a.actor_id
                                     ORDER BY a.created_at DESC LIMIT 20""").fetchall()

        # Employee workload summary
        workload = con.execute("""SELECT u.id,u.name,u.role,
                                  SUM(CASE WHEN t.status NOT IN ('APPROVED','APPROVED_WITH_EXCEPTION','CANCELLED') THEN 1 ELSE 0 END) AS open_tasks,
                                  SUM(CASE WHEN t.status IN ('APPROVED','APPROVED_WITH_EXCEPTION') THEN 1 ELSE 0 END) AS done_tasks,
                                  SUM(CASE WHEN t.status='RETURNED' THEN 1 ELSE 0 END) AS returned_tasks,
                                  SUM(CASE WHEN t.due_date < ? AND t.status NOT IN ('APPROVED','APPROVED_WITH_EXCEPTION','CANCELLED') THEN 1 ELSE 0 END) AS overdue_tasks
                                  FROM users u LEFT JOIN tasks t ON t.assignee_id=u.id
                                  WHERE u.active=1 GROUP BY u.id ORDER BY u.name""", (now(),)).fetchall()

        return {
            "stats": {
                "total_companies": total_companies,
                "total_users": total_users,
                "total_tasks": total_tasks,
                "open_tasks": open_tasks,
                "overdue_tasks": overdue,
                "submitted_tasks": submitted,
                "returned_tasks": returned,
                "approved_tasks": approved,
                "pending_reviews": pending_reviews,
                "total_submissions": total_submissions,
                "pending_leaves": pending_leaves,
                "total_time_hours": round(total_time / 3600, 1),
                "avg_score": round(avg_score, 1),
            },
            "recent_tasks": [dict(r) for r in recent_tasks],
            "recent_decisions": [dict(r) for r in recent_decisions],
            "recent_audit": [{**dict(r), "details": json.loads(r["details"])} for r in recent_audit],
            "employee_workload": [dict(r) for r in workload],
        }


@app.get("/api/tasks")
def list_tasks(request: Request, status_filter: str | None = None):
    user = current_user(request)
    with db() as con:
        sql = "SELECT t.*,c.name company_name,c.code company_code,u.name assignee_name FROM tasks t JOIN companies c ON c.id=t.company_id JOIN users u ON u.id=t.assignee_id"
        args: list[Any] = []
        if user["role"] not in ("ADMIN", "CEO"):
            sql += " WHERE t.assignee_id=?"
            args.append(user["id"])
        if status_filter:
            sql += (" AND " if " WHERE " in sql else " WHERE ") + "t.status=?"
            args.append(status_filter)
        sql += " ORDER BY CASE t.status WHEN 'SUBMITTED' THEN 0 WHEN 'RETURNED' THEN 1 ELSE 2 END,t.due_date IS NULL,t.due_date,t.updated_at DESC"
        return [dict(r) for r in con.execute(sql, args)]


@app.post("/api/tasks")
def create_task(payload: TaskCreate, request: Request):
    user = current_user(request)
    require_perm(user, "tasks.create")
    if payload.priority not in ("NORMAL", "IMPORTANT", "CRITICAL"):
        raise HTTPException(400, "اولویت نامعتبر است")
    payload.fiscal_period=normalize_digits(payload.fiscal_period).strip().replace("-","/")
    payload.due_date=normalize_date_input(payload.due_date)
    with db() as con:
        if not con.execute("SELECT 1 FROM companies WHERE id=? AND active=1", (payload.company_id,)).fetchone():
            raise HTTPException(400, "شرکت انتخابشده معتبر نیست")
        assignee = con.execute("SELECT id,role FROM users WHERE id=? AND active=1", (payload.assignee_id,)).fetchone()
        if not assignee or assignee["role"] not in ("EMPLOYEE", "ADMIN"):
            raise HTTPException(400, "مسئول انتخابشده معتبر نیست")
        if assignee["role"] == "EMPLOYEE" and not can_access_company(con, assignee, payload.company_id):
            raise HTTPException(400, "این کارمند به شرکت انتخابشده دسترسی ندارد")
        # Validate collaborators
        for cid in (payload.collaborator_ids or []):
            coll = con.execute("SELECT id,role FROM users WHERE id=? AND active=1", (cid,)).fetchone()
            if not coll or (coll["role"] == "EMPLOYEE" and not can_access_company(con, coll, payload.company_id)):
                raise HTTPException(400, f"همکار {cid} معتبر نیست یا به این شرکت دسترسی ندارد")
        task_id = uid()
        timestamp = now()
        current_ref = latest_reference(con, payload.company_id, payload.fiscal_period) if payload.fiscal_period else None
        pinned_ref = current_ref["id"] if current_ref else None
        con.execute("INSERT INTO tasks VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (task_id,payload.company_id,payload.title,payload.description,payload.fiscal_period,payload.scope,payload.priority,payload.weight,payload.due_date,"ASSIGNED",0,None,pinned_ref,payload.assignee_id,user["id"],timestamp,timestamp))
        con.execute("INSERT INTO task_assignments VALUES(?,?,?,?,?,?,?)", (uid(),task_id,None,payload.assignee_id,user["id"],"تخصیص اولیه",timestamp))
        # Add collaborators
        for cid in set(payload.collaborator_ids or []):
            if cid != payload.assignee_id:
                con.execute("INSERT OR IGNORE INTO task_collaborators VALUES(?,?,?,?)", (task_id, cid, "COLLABORATOR", user["id"], timestamp))
                notify(con, cid, "همکار در تسک", f"شما بهعنوان همکار به تسک «{payload.title}» اضافه شدید")
        # Create checklist steps (up to 5)
        for i, step_title in enumerate((payload.checklist_steps or [])[:5], 1):
            con.execute("INSERT INTO task_checklist VALUES(?,?,?,?,?,?,?,?)", (uid(), task_id, i, step_title.strip(), 0, None, None, timestamp))
        con.execute("INSERT INTO task_events VALUES(?,?,?,?,?,?)", (uid(),task_id,user["id"],"TASK_CREATED",json.dumps({"status":"ASSIGNED","collaborators":len(payload.collaborator_ids or []),"checklist_steps":len(payload.checklist_steps or [])}),timestamp))
        audit(con, user["id"], "TASK_CREATE", "task", task_id, {"company_id": payload.company_id, "assignee_id": payload.assignee_id})
        notify(con,payload.assignee_id,"تسک جدید",payload.title)
        return {"id": task_id}


@app.patch("/api/tasks/{task_id}")
def update_task(task_id: str, payload: TaskUpdate, request: Request):
    user = current_user(request)
    with db() as con:
        task = task_access(con,user,task_id)
        changes: list[str] = []
        if payload.assignee_id is not None:
            require_role(user,"ADMIN","CEO")
            target = con.execute("SELECT id,role FROM users WHERE id=? AND active=1",(payload.assignee_id,)).fetchone()
            if not target or (target["role"] == "EMPLOYEE" and not can_access_company(con,target,task["company_id"])):
                raise HTTPException(400,"مسئول جدید به این شرکت دسترسی ندارد")
            old = task["assignee_id"]
            con.execute("UPDATE tasks SET assignee_id=?,updated_at=? WHERE id=?",(payload.assignee_id,now(),task_id))
            con.execute("INSERT INTO task_assignments VALUES(?,?,?,?,?,?,?)",(uid(),task_id,old,payload.assignee_id,user["id"],payload.reason,now()))
            notify(con,payload.assignee_id,"تسک به شما واگذار شد",task["title"])
            changes.append("assignment")
        if payload.progress is not None:
            if user["role"] not in ("ADMIN","CEO") and task["assignee_id"] != user["id"]:
                raise HTTPException(403,"فقط مسئول تسک میتواند پیشرفت را ثبت کند")
            con.execute("UPDATE tasks SET progress=?,status=CASE WHEN status IN ('ASSIGNED','IN_PROGRESS','RETURNED') THEN 'IN_PROGRESS' ELSE status END,updated_at=? WHERE id=?",(payload.progress,now(),task_id))
            changes.append("progress")
        if payload.status is not None:
            require_role(user,"ADMIN","CEO")
            if payload.status not in ("CANCELLED", "ASSIGNED"):
                raise HTTPException(400,"از این بخش فقط لغو یا بازتخصیص وضعیت مجاز است")
            con.execute("UPDATE tasks SET status=?,updated_at=? WHERE id=?",(payload.status,now(),task_id))
            changes.append("status")
        if payload.reference_version_id is not None:
            require_role(user,"ADMIN","CEO")
            reference=con.execute("SELECT id,company_id,fiscal_period FROM reference_versions WHERE id=?",(payload.reference_version_id,)).fetchone()
            if not reference or reference["company_id"]!=task["company_id"] or reference["fiscal_period"]!=task["fiscal_period"]:
                raise HTTPException(400,"نسخه مرجع باید متعلق به همین شرکت و دوره باشد")
            con.execute("UPDATE tasks SET reference_version_id=?,updated_at=? WHERE id=?",(payload.reference_version_id,now(),task_id))
            changes.append("reference_version")
        if changes:
            con.execute("INSERT INTO task_events VALUES(?,?,?,?,?,?)",(uid(),task_id,user["id"],"TASK_UPDATE",json.dumps({"changes":changes,"reason":payload.reason},ensure_ascii=False),now()))
            audit(con,user["id"],"TASK_UPDATE","task",task_id,{"changes":changes})
        return {"ok":True}


@app.get("/api/colleagues")
def colleagues(company_id: str, request: Request):
    user=current_user(request)
    with db() as con:
        if not can_access_company(con,user,company_id):
            raise HTTPException(403,"به این شرکت دسترسی ندارید")
        return [dict(r) for r in con.execute("SELECT u.id,u.name FROM users u JOIN company_access a ON a.user_id=u.id WHERE a.company_id=? AND u.active=1 AND u.role='EMPLOYEE' AND u.id<>? ORDER BY u.name",(company_id,user["id"]))]


@app.post("/api/tasks/{task_id}/delegate")
def delegate_task(task_id: str,payload: DelegateModel,request: Request):
    user=current_user(request)
    payload.due_date=normalize_date_input(payload.due_date)
    with db() as con:
        parent=task_access(con,user,task_id)
        if user["role"] in ("ADMIN","CEO") or parent["assignee_id"]!=user["id"]:
            if user["role"] not in ("ADMIN","CEO"):
                raise HTTPException(403,"فقط مسئول تسک میتواند بخشی از آن را ارجاع دهد")
        if parent["status"] in ("APPROVED","APPROVED_WITH_EXCEPTION","CANCELLED"):
            raise HTTPException(409,"از تسک پایانیافته نمیتوان بخش ارجاع داد")
        target=con.execute("SELECT id,role FROM users WHERE id=? AND active=1",(payload.assignee_id,)).fetchone()
        if not target or target["role"]!="EMPLOYEE" or not can_access_company(con,target,parent["company_id"]):
            raise HTTPException(400,"همکار انتخابشده به این شرکت دسترسی ندارد")
        child_id=uid(); timestamp=now()
        con.execute("INSERT INTO tasks VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",(child_id,parent["company_id"],payload.title,payload.description,parent["fiscal_period"],payload.scope,parent["priority"],parent["weight"],payload.due_date or parent["due_date"],"ASSIGNED",0,parent["id"],parent["reference_version_id"],payload.assignee_id,user["id"],timestamp,timestamp))
        con.execute("INSERT INTO task_assignments VALUES(?,?,?,?,?,?,?)",(uid(),child_id,None,payload.assignee_id,user["id"],"ارجاع بخش از تسک "+parent["id"],timestamp))
        con.execute("INSERT INTO task_events VALUES(?,?,?,?,?,?)",(uid(),child_id,user["id"],"TASK_DELEGATED",json.dumps({"parent_task_id":parent["id"],"scope":payload.scope},ensure_ascii=False),timestamp))
        con.execute("INSERT INTO task_events VALUES(?,?,?,?,?,?)",(uid(),parent["id"],user["id"],"PART_DELEGATED",json.dumps({"child_task_id":child_id,"assignee_id":payload.assignee_id,"scope":payload.scope},ensure_ascii=False),timestamp))
        notify(con,payload.assignee_id,"بخشی از یک تسک به شما ارجاع شد",payload.title)
        audit(con,user["id"],"TASK_DELEGATE","task",child_id,{"parent_task_id":parent["id"],"assignee_id":payload.assignee_id})
        return {"id":child_id,"parent_task_id":parent["id"]}


def latest_reference(con: sqlite3.Connection, company_id: str, period: str) -> sqlite3.Row | None:
    return con.execute("SELECT * FROM reference_versions WHERE company_id=? AND fiscal_period=? ORDER BY version DESC LIMIT 1",(company_id,period)).fetchone()


@app.post("/api/companies/{company_id}/reference")
async def upload_reference(company_id: str, request: Request, fiscal_period: str = Form(...), coverage_start: str = Form(""), coverage_end: str = Form(""), file: UploadFile = File(...)):
    user = current_user(request)
    require_perm(user, "tasks.reference")
    content = await file.read(MAX_UPLOAD+1)
    rows, _ = read_excel(file,content)
    fiscal_period=normalize_digits(fiscal_period).strip().replace("-","/")
    coverage_start=normalize_date_input(coverage_start) or ""
    coverage_end=normalize_date_input(coverage_end) or ""
    digest = hashlib.sha256(content).hexdigest()
    stored = f"{uuid.uuid4().hex}.xlsx"
    (FILES/stored).write_bytes(content)
    with db() as con:
        company = con.execute("SELECT id FROM companies WHERE id=?",(company_id,)).fetchone()
        if not company: raise HTTPException(404,"شرکت پیدا نشد")
        if con.execute("SELECT 1 FROM reference_versions WHERE company_id=? AND fiscal_period=? AND sha256=?",(company_id,fiscal_period,digest)).fetchone():
            (FILES/stored).unlink(missing_ok=True)
            raise HTTPException(409,"این فایل مرجع قبلاً بارگذاری شده است")
        version = con.execute("SELECT COALESCE(MAX(version),0)+1 FROM reference_versions WHERE company_id=? AND fiscal_period=?",(company_id,fiscal_period)).fetchone()[0]
        ref_id=uid()
        con.execute("INSERT INTO reference_versions VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",(ref_id,company_id,fiscal_period,version,file.filename or "reference.xlsx",stored,digest,len(rows),coverage_start or None,coverage_end or None,user["id"],now()))
        audit(con,user["id"],"REFERENCE_UPLOAD","reference",ref_id,{"company_id":company_id,"period":fiscal_period,"version":version,"rows":len(rows)})
        return {"id":ref_id,"version":version,"row_count":len(rows)}


@app.post("/api/tasks/{task_id}/submit")
async def submit_task(task_id: str, request: Request, claimed_start: str = Form(""), claimed_end: str = Form(""), note: str = Form(""), file: UploadFile = File(...)):
    user=current_user(request)
    content=await file.read(MAX_UPLOAD+1)
    rows,_=read_excel(file,content)
    claimed_start=normalize_date_input(claimed_start) or ""
    claimed_end=normalize_date_input(claimed_end) or ""
    digest=hashlib.sha256(content).hexdigest()
    with db() as con:
        task=task_access(con,user,task_id)
        if user["role"] not in ("ADMIN","CEO") and task["assignee_id"]!=user["id"]:
            raise HTTPException(403,"فقط مسئول فعلی تسک میتواند گزارش بفرستد")
        if task["status"] in ("APPROVED","APPROVED_WITH_EXCEPTION","CANCELLED"):
            raise HTTPException(409,"این تسک دیگر پذیرای گزارش نیست")
        if con.execute("SELECT 1 FROM submissions WHERE task_id=? AND sha256=?",(task_id,digest)).fetchone():
            raise HTTPException(409,"این فایل قبلاً برای همین تسک ارسال شده است")
        ref=con.execute("SELECT * FROM reference_versions WHERE id=?",(task["reference_version_id"],)).fetchone() if task["reference_version_id"] else None
        ref_rows=None
        if ref:
            ref_content=(FILES/ref["stored_name"]).read_bytes()
            ref_rows,_=read_excel(UploadFile(filename=ref["original_name"],file=None),ref_content)
        report=reconcile(rows,ref_rows,claimed_start or None,claimed_end or None)
        row_keys=[hashlib.sha256(json.dumps(duplicate_key(row),ensure_ascii=False,separators=(",",":")).encode()).hexdigest() for row in rows]
        previous_keys:set[str]=set()
        if task["fiscal_period"]:
            unique_keys=list(set(row_keys))
            for offset in range(0,len(unique_keys),400):
                chunk=unique_keys[offset:offset+400]
                placeholders=",".join("?" for _ in chunk)
                previous_keys.update(r["row_key"] for r in con.execute(f"SELECT DISTINCT row_key FROM normalized_rows WHERE company_id=? AND fiscal_period=? AND row_key IN ({placeholders})",[task["company_id"],task["fiscal_period"],*chunk]))
        report["cross_submission_duplicates"] = sum(1 for key in row_keys if key in previous_keys)
        if report["cross_submission_duplicates"]:
            report["notes"].append("برخی ردیفها در گزارش کار قبلی همین شرکت/دوره دیده شدهاند؛ همپوشانی دامنه را مدیر بررسی کند.")
        report["reference_version_id"] = ref["id"] if ref else None
        report["reference_version"] = ref["version"] if ref else None
        version=con.execute("SELECT COALESCE(MAX(version),0)+1 FROM submissions WHERE task_id=?",(task_id,)).fetchone()[0]
        stored=f"{uuid.uuid4().hex}.xlsx"
        (FILES/stored).write_bytes(content)
        sub_id=uid()
        con.execute("INSERT INTO submissions VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",(sub_id,task_id,user["id"],ref["id"] if ref else None,version,file.filename or "submission.xlsx",stored,digest,note,claimed_start or None,claimed_end or None,len(rows),report["voucher_count"],report["duplicate_rows"],report["out_of_range"],json.dumps(report,ensure_ascii=False),now()))
        if task["fiscal_period"]:
            timestamp=now()
            con.executemany("INSERT INTO normalized_rows VALUES(?,?,?,?,?,?,?,?,?)",[(uid(),task["company_id"],task["fiscal_period"],task_id,sub_id,int(row["source_row"]),row_keys[i],json.dumps(row,ensure_ascii=False),timestamp) for i,row in enumerate(rows)])
        con.execute("UPDATE tasks SET status='SUBMITTED',progress=100,updated_at=? WHERE id=?",(now(),task_id))
        con.execute("INSERT INTO task_events VALUES(?,?,?,?,?,?)",(uid(),task_id,user["id"],"SUBMITTED",json.dumps({"submission_id":sub_id,"version":version}),now()))
        managers=con.execute("SELECT id FROM users WHERE role IN ('ADMIN','CEO') AND active=1").fetchall()
        for manager in managers: notify(con,manager["id"],"گزارش کار جدید",task["title"])
        audit(con,user["id"],"SUBMISSION_CREATE","submission",sub_id,{"task_id":task_id,"version":version,"sha256":digest,"row_count":len(rows)})
        return {"id":sub_id,"version":version,"report":report}


@app.get("/api/tasks/{task_id}/detail")
def task_detail(task_id: str, request: Request):
    user=current_user(request)
    with db() as con:
        task=task_access(con,user,task_id)
        submissions=con.execute("SELECT s.*,u.name employee_name FROM submissions s JOIN users u ON u.id=s.employee_id WHERE task_id=? ORDER BY version DESC",(task_id,)).fetchall()
        decisions=con.execute("SELECT d.*,u.name manager_name FROM decisions d JOIN users u ON u.id=d.manager_id WHERE task_id=? ORDER BY created_at DESC",(task_id,)).fetchall()
        if user["role"] in ("ADMIN","CEO"):
            comments=con.execute("SELECT c.*,u.name author_name FROM comments c JOIN users u ON u.id=c.author_id WHERE task_id=? ORDER BY created_at",(task_id,)).fetchall()
        else:
            comments=con.execute("SELECT c.*,u.name author_name FROM comments c JOIN users u ON u.id=c.author_id WHERE task_id=? AND visibility='EMPLOYEE_VISIBLE' ORDER BY created_at",(task_id,)).fetchall()
        history=con.execute("SELECT e.*,u.name actor_name FROM task_events e JOIN users u ON u.id=e.actor_id WHERE task_id=? ORDER BY created_at",(task_id,)).fetchall()
        children=con.execute("SELECT t.id,t.title,t.status,t.progress,u.name assignee_name FROM tasks t JOIN users u ON u.id=t.assignee_id WHERE t.parent_task_id=? ORDER BY t.created_at",(task_id,)).fetchall()
        parent=con.execute("SELECT t.id,t.title FROM tasks t WHERE t.id=?",(task["parent_task_id"],)).fetchone() if task["parent_task_id"] else None
        return {"task":dict(task),"parent":dict(parent) if parent else None,"children":[dict(c) for c in children],"submissions":[{**dict(s),"report":json.loads(s["report_json"])} for s in submissions],"decisions":[dict(d) for d in decisions],"comments":[dict(c) for c in comments],"history":[dict(e) for e in history]}


@app.post("/api/tasks/{task_id}/decision")
def decide(task_id: str,payload: DecisionModel,request: Request):
    user=current_user(request); require_perm(user, "tasks.decide")
    allowed={"APPROVED","APPROVED_WITH_EXCEPTION","RETURNED","CANCELLED"}
    methods={"REFERENCE_RECONCILIATION","MANUAL_REVIEW","NO_REFERENCE"}
    if payload.decision not in allowed or payload.review_method not in methods: raise HTTPException(400,"تصمیم یا روش بررسی نامعتبر است")
    if payload.decision=="RETURNED" and len(payload.reason.strip())<5: raise HTTPException(400,"برای بازگشت، دلیل روشن و قابل مشاهده الزامی است")
    if payload.decision=="APPROVED_WITH_EXCEPTION" and len(payload.exception_reason.strip())<5: raise HTTPException(400,"دلیل ارفاق الزامی است")
    if payload.decision in ("APPROVED","APPROVED_WITH_EXCEPTION") and payload.score is None: raise HTTPException(400,"برای تکمیل تسک نمرهٔ ۰ تا ۱۰۰ الزامی است")
    if payload.decision=="CANCELLED" and len(payload.reason.strip())<5: raise HTTPException(400,"برای لغو تسک دلیل الزامی است")
    if payload.review_method=="NO_REFERENCE" and payload.decision not in ("APPROVED","APPROVED_WITH_EXCEPTION"):
        raise HTTPException(400,"روش NO_REFERENCE فقط برای تأیید قابل انتخاب است")
    with db() as con:
        task=task_access(con,user,task_id)
        sub=con.execute("SELECT id FROM submissions WHERE task_id=? ORDER BY version DESC LIMIT 1",(task_id,)).fetchone()
        if payload.review_method=="REFERENCE_RECONCILIATION":
            checked=con.execute("SELECT report_json FROM submissions WHERE task_id=? ORDER BY version DESC LIMIT 1",(task_id,)).fetchone()
            if not checked or not json.loads(checked["report_json"]).get("reference_attached"):
                raise HTTPException(400,"برای روش تطبیق با مرجع، ارسال دارای مرجع لازم است")
        if payload.review_method=="NO_REFERENCE" and task["reference_version_id"]:
            raise HTTPException(400,"برای این تسک مرجع نسخهدار متصل است؛ روش بررسی را انتخاب کنید")
        decision_id=uid(); created=now()
        con.execute("INSERT INTO decisions VALUES(?,?,?,?,?,?,?,?,?,?)",(decision_id,task_id,sub["id"] if sub else None,payload.decision,payload.score,payload.review_method,payload.reason,payload.exception_reason,user["id"],created))
        con.execute("UPDATE tasks SET status=?,updated_at=? WHERE id=?",(payload.decision,created,task_id))
        con.execute("INSERT INTO task_events VALUES(?,?,?,?,?,?)",(uid(),task_id,user["id"],"MANAGER_DECISION",json.dumps({"decision":payload.decision,"score":payload.score,"method":payload.review_method,"reason":payload.reason},ensure_ascii=False),created))
        notify(con,task["assignee_id"],"نتیجه بررسی تسک",f"{task['title']} — {payload.decision}")
        audit(con,user["id"],"MANAGER_DECISION","task",task_id,{"decision":payload.decision,"score":payload.score,"review_method":payload.review_method})
        return {"ok":True,"decision_id":decision_id}


@app.post("/api/tasks/{task_id}/comments")
def add_comment(task_id: str,payload: CommentModel,request: Request):
    user=current_user(request)
    if payload.visibility not in ("EMPLOYEE_VISIBLE","MANAGER_ONLY"): raise HTTPException(400,"سطح دید نامعتبر است")
    if payload.visibility=="MANAGER_ONLY": require_role(user,"ADMIN","CEO")
    with db() as con:
        task=task_access(con,user,task_id)
        comment_id=uid(); con.execute("INSERT INTO comments VALUES(?,?,?,?,?,?)",(comment_id,task_id,user["id"],payload.visibility,payload.body,now()))
        if user["role"] in ("ADMIN","CEO") and payload.visibility=="EMPLOYEE_VISIBLE": notify(con,task["assignee_id"],"یادداشت جدید برای تسک",task["title"])
        audit(con,user["id"],"COMMENT_CREATE","task",task_id,{"visibility":payload.visibility})
        return {"id":comment_id}


@app.get("/api/performance")
def performance(request: Request):
    user=current_user(request); require_perm(user, "reports.kpi")
    with db() as con:
        people=con.execute("SELECT id,name FROM users WHERE role='EMPLOYEE' AND active=1 ORDER BY name").fetchall()
        result=[]
        for person in people:
            scores=con.execute("SELECT d.score,t.weight,d.decision FROM decisions d JOIN tasks t ON t.id=d.task_id WHERE t.assignee_id=? AND d.score IS NOT NULL AND d.decision NOT IN ('CANCELLED','RETURNED') AND d.id=(SELECT d2.id FROM decisions d2 WHERE d2.task_id=d.task_id ORDER BY d2.created_at DESC LIMIT 1)",(person["id"],)).fetchall()
            total=con.execute("SELECT COUNT(*) FROM tasks WHERE assignee_id=?",(person["id"],)).fetchone()[0]
            completed=con.execute("SELECT COUNT(*) FROM tasks WHERE assignee_id=? AND status IN ('APPROVED','APPROVED_WITH_EXCEPTION')",(person["id"],)).fetchone()[0]
            vals=[s["score"] for s in scores]
            weight_sum=sum(s["weight"] for s in scores)
            weighted=round(sum(s["score"]*s["weight"] for s in scores)/weight_sum,1) if weight_sum else None
            simple=round(sum(vals)/len(vals),1) if vals else None
            due_rows=con.execute("SELECT due_date FROM tasks WHERE assignee_id=? AND due_date IS NOT NULL AND status NOT IN ('APPROVED','APPROVED_WITH_EXCEPTION','CANCELLED')",(person["id"],)).fetchall()
            today_jalali=tehran_jalali_today()
            late=sum(1 for r in due_rows if normalize_digits(r["due_date"]).replace("-","/")<today_jalali)
            result.append({"id":person["id"],"name":person["name"],"total":total,"completed":completed,"late":late,"simple_score":simple,"weighted_score":weighted})
        return result


PERFORMANCE_CATEGORIES = {"ACCOUNTING", "RECONCILIATION", "CLIENT_SERVICE", "ADMINISTRATION", "OTHER"}


def clean_work_date(value: str) -> str:
    normalized = normalize_digits(value).strip().replace("-", "/").replace(".", "/")
    match = re.fullmatch(r"(13\d{2}|14\d{2}|15\d{2})/(\d{1,2})/(\d{1,2})", normalized)
    if not match:
        raise HTTPException(400, "تاریخ را به شکل شمسی ۱۴۰۵/۰۷/۲۷ وارد کنید")
    year, month, day = map(int, match.groups())
    if not 1 <= month <= 12 or not 1 <= day <= (31 if month <= 6 else 30):
        raise HTTPException(400, "تاریخ شمسی معتبر نیست")
    return f"{year:04d}/{month:02d}/{day:02d}"


@app.get("/api/performance-entries")
def list_performance_entries(request: Request):
    user = current_user(request)
    with db() as con:
        query = """SELECT p.*,u.name AS user_name,r.name AS reviewer_name,
                   c.name AS company_name
                   FROM performance_entries p JOIN users u ON u.id=p.user_id
                   LEFT JOIN users r ON r.id=p.reviewer_id
                   LEFT JOIN companies c ON c.id=p.company_id"""
        args: tuple[Any, ...] = ()
        if user["role"] not in ("ADMIN", "CEO"):
            query += " WHERE p.user_id=?"
            args = (user["id"],)
        query += " ORDER BY p.work_date DESC,p.created_at DESC LIMIT 500"
        return [dict(row) for row in con.execute(query, args).fetchall()]


@app.post("/api/performance-entries")
def create_performance_entry(payload: PerformanceEntryModel, request: Request):
    user = current_user(request)
    if payload.category not in PERFORMANCE_CATEGORIES:
        raise HTTPException(400, "نوع عملکرد معتبر نیست")
    work_date = clean_work_date(payload.work_date)
    due_date = normalize_date_input(payload.due_date) or None
    entry_id, created = uid(), now()
    with db() as con:
        con.execute("""INSERT INTO performance_entries
            (id,user_id,work_date,category,title,description,duration_minutes,status,created_at,
             company_id,fiscal_period,scope,priority,weight,due_date,progress,updated_at)
            VALUES(?,?,?,?,?,?,?,'PENDING',?,?,?,?,?,?,?,?,?)""",
            (entry_id,user["id"],work_date,payload.category,payload.title.strip(),payload.description.strip(),
             payload.duration_minutes,created,
             payload.company_id or None, payload.fiscal_period, payload.scope,
             payload.priority, payload.weight, due_date, payload.progress, created))
        audit(con,user["id"],"PERFORMANCE_ENTRY_CREATE","performance_entry",entry_id,
              {"category":payload.category,"duration_minutes":payload.duration_minutes,
               "priority":payload.priority,"weight":payload.weight})
    return {"id": entry_id, "status": "PENDING"}


@app.put("/api/performance-entries/{entry_id}")
def update_performance_entry(entry_id: str, payload: PerformanceEntryModel, request: Request):
    user = current_user(request)
    if payload.category not in PERFORMANCE_CATEGORIES:
        raise HTTPException(400, "نوع عملکرد معتبر نیست")
    work_date = clean_work_date(payload.work_date)
    due_date = normalize_date_input(payload.due_date) or None
    with db() as con:
        entry = con.execute("SELECT * FROM performance_entries WHERE id=?", (entry_id,)).fetchone()
        if entry is None:
            raise HTTPException(404, "گزارش عملکرد پیدا نشد")
        if entry["user_id"] != user["id"]:
            raise HTTPException(403, "فقط صاحب گزارش میتواند آن را ویرایش کند")
        if entry["status"] == "APPROVED":
            raise HTTPException(409, "گزارش تأییدشده قابل ویرایش نیست")
        con.execute("""UPDATE performance_entries SET work_date=?,category=?,title=?,description=?,
            duration_minutes=?,status='PENDING',review_note='',reviewer_id=NULL,reviewed_at=NULL,
            company_id=?,fiscal_period=?,scope=?,priority=?,weight=?,due_date=?,progress=?,updated_at=? WHERE id=?""",
            (work_date,payload.category,payload.title.strip(),payload.description.strip(),payload.duration_minutes,
             payload.company_id or None, payload.fiscal_period, payload.scope,
             payload.priority, payload.weight, due_date, payload.progress, now(), entry_id))
        audit(con,user["id"],"PERFORMANCE_ENTRY_UPDATE","performance_entry",entry_id,
              {"category":payload.category,"duration_minutes":payload.duration_minutes})
    return {"id": entry_id, "status": "PENDING"}


@app.post("/api/performance-entries/{entry_id}/review")
def review_performance_entry(entry_id: str, payload: PerformanceReviewModel, request: Request):
    user = current_user(request)
    require_perm(user, "performance.review")
    if payload.status not in ("APPROVED", "NEEDS_EDIT"):
        raise HTTPException(400, "وضعیت بررسی معتبر نیست")
    with db() as con:
        entry = con.execute("SELECT * FROM performance_entries WHERE id=?", (entry_id,)).fetchone()
        if entry is None:
            raise HTTPException(404, "گزارش عملکرد پیدا نشد")
        if entry["user_id"] == user["id"]:
            raise HTTPException(403, "گزارش عملکرد خودتان را نمیتوانید بررسی کنید")
        if entry["status"] == "APPROVED":
            raise HTTPException(409, "این گزارش قبلاً تأیید شده است")
        reviewed = now()
        con.execute("UPDATE performance_entries SET status=?,review_note=?,reviewer_id=?,reviewed_at=? WHERE id=?",
                    (payload.status,payload.review_note.strip(),user["id"],reviewed,entry_id))
        notify(con,entry["user_id"],"بررسی ثبت عملکرد", "گزارش شما تأیید شد" if payload.status == "APPROVED" else "گزارش شما برای اصلاح بازگشت؛ یادداشت مدیر را ببینید")
        audit(con,user["id"],"PERFORMANCE_ENTRY_REVIEW","performance_entry",entry_id,{"status":payload.status})
    return {"id": entry_id, "status": payload.status}


@app.get("/api/requests")
def list_requests(request: Request):
    user=current_user(request)
    with db() as con:
        if user["role"] in ("ADMIN","CEO"):
            rows=con.execute("""SELECT r.*, u.name user_name, rt.name AS request_type_name, rt.icon AS request_type_icon
                                FROM requests r
                                LEFT JOIN users u ON u.id=r.user_id
                                LEFT JOIN request_types rt ON rt.id=r.request_type_id
                                ORDER BY CASE r.status WHEN 'PENDING' THEN 0 ELSE 1 END, r.created_at DESC""").fetchall()
        else:
            rows=con.execute("""SELECT r.*, u.name user_name, rt.name AS request_type_name, rt.icon AS request_type_icon
                                FROM requests r
                                LEFT JOIN users u ON u.id=r.user_id
                                LEFT JOIN request_types rt ON rt.id=r.request_type_id
                                WHERE r.user_id=? ORDER BY r.created_at DESC""",(user["id"],)).fetchall()
        return [dict(r) for r in rows]


@app.post("/api/requests")
def create_request(payload: RequestModel,request: Request):
    user=current_user(request)
    kind = payload.kind or "GENERAL"
    data_json = json.dumps(payload.data, ensure_ascii=False) if payload.data else "{}"
    start_date = payload.start_date or payload.data.get("from_date") if isinstance(payload.data, dict) else payload.start_date
    end_date = payload.end_date or payload.data.get("to_date") if isinstance(payload.data, dict) else payload.end_date
    body = payload.body or payload.data.get("body","") if isinstance(payload.data, dict) else payload.body

    # Validate request_type if provided
    request_type_name = None
    if payload.request_type_id:
        with db() as con:
            rt = con.execute("SELECT * FROM request_types WHERE id=? AND active=1",(payload.request_type_id,)).fetchone()
            if not rt: raise HTTPException(400,"نوع درخواست نامعتبر یا غیرفعال است")
            request_type_name = rt["name"]

    with db() as con:
        rid=uid()
        con.execute("""INSERT INTO requests
            (id, user_id, kind, request_type_id, data_json, user_name_override,
             start_date, end_date, body, status, reviewer_id, review_note, created_at, reviewed_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (rid, user["id"], kind, payload.request_type_id, data_json, payload.user_name_override,
             start_date, end_date, body or "", "PENDING", None, "", now(), None))
        for manager in con.execute("SELECT id FROM users WHERE role IN ('ADMIN','CEO') AND active=1").fetchall():
            notify(con,manager["id"],"درخواست جدید", request_type_name or kind)
        audit(con,user["id"],"REQUEST_CREATE","request",rid,{"kind":kind, "request_type_id": payload.request_type_id})
    return {"id":rid}


@app.patch("/api/requests/{request_id}")
def review_request(request_id:str,payload:ReviewRequestModel,request:Request):
    user=current_user(request); require_perm(user, "requests.decide")
    if payload.status not in ("APPROVED","REJECTED"): raise HTTPException(400,"وضعیت بررسی نامعتبر است")
    with db() as con:
        item=con.execute("SELECT * FROM requests WHERE id=?",(request_id,)).fetchone()
        if not item: raise HTTPException(404,"درخواست پیدا نشد")
        con.execute("UPDATE requests SET status=?,reviewer_id=?,review_note=?,reviewed_at=? WHERE id=?",(payload.status,user["id"],payload.review_note,now(),request_id))
        notify(con,item["user_id"],"درخواست شما بررسی شد",payload.status)
        audit(con,user["id"],"REQUEST_REVIEW","request",request_id,{"status":payload.status})
        return {"ok":True}


# ========================================================================
# REQUEST TYPES API (تنظیمات → انواع درخواست)
# ========================================================================

@app.get("/api/request-types")
def list_request_types(request: Request):
    user=current_user(request)
    require_perm(user, "requests.view")
    with db() as con:
        rows = con.execute("""SELECT rt.*, u.name AS created_by_name, COUNT(r.id) AS usage_count
                              FROM request_types rt LEFT JOIN users u ON u.id=rt.created_by
                              LEFT JOIN requests r ON r.request_type_id=rt.id
                              GROUP BY rt.id ORDER BY rt.created_at DESC""").fetchall()
        result = []
        for r in rows:
            d = dict(r)
            try:
                d["fields"] = json.loads(r["fields_json"]) if r["fields_json"] else []
            except Exception:
                d["fields"] = []
            del d["fields_json"]
            result.append(d)
        return result

@app.post("/api/request-types")
def create_request_type(payload: RequestTypeCreateModel, request: Request):
    user = current_user(request)
    require_perm(user, "settings.request_types")
    if not payload.code.strip() or not payload.name.strip():
        raise HTTPException(400, "کد و نام نوع درخواست الزامی است")
    rt_id = uid()
    fields_json = json.dumps(payload.fields, ensure_ascii=False) if payload.fields else "[]"
    with db() as con:
        try:
            con.execute("INSERT INTO request_types VALUES(?,?,?,?,?,?,?,?)",
                        (rt_id, payload.code.strip(), payload.name.strip(), payload.icon or "📝",
                         fields_json, payload.active, user["id"], now()))
        except Exception as e:
            if "UNIQUE" in str(e): raise HTTPException(400, "کد نوع درخواست تکراری است")
            raise
        audit(con, user["id"], "REQUEST_TYPE_CREATE", "request_type", rt_id, {"code": payload.code, "name": payload.name})
    return {"id": rt_id, "code": payload.code}

@app.get("/api/request-types/{rt_id}")
def get_request_type(rt_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "requests.view")
    with db() as con:
        r = con.execute("SELECT * FROM request_types WHERE id=?", (rt_id,)).fetchone()
        if not r: raise HTTPException(404, "نوع درخواست پیدا نشد")
        d = dict(r)
        try:
            d["fields"] = json.loads(r["fields_json"]) if r["fields_json"] else []
        except Exception:
            d["fields"] = []
        del d["fields_json"]
        return d

@app.patch("/api/request-types/{rt_id}")
def update_request_type(rt_id: str, payload: RequestTypeUpdateModel, request: Request):
    user = current_user(request)
    require_perm(user, "settings.request_types")
    with db() as con:
        existing = con.execute("SELECT * FROM request_types WHERE id=?", (rt_id,)).fetchone()
        if not existing: raise HTTPException(404, "نوع درخواست پیدا نشد")
        updates = []
        params = []
        if payload.name is not None:
            updates.append("name=?")
            params.append(payload.name.strip())
        if payload.icon is not None:
            updates.append("icon=?")
            params.append(payload.icon)
        if payload.fields is not None:
            updates.append("fields_json=?")
            params.append(json.dumps(payload.fields, ensure_ascii=False))
        if payload.active is not None:
            updates.append("active=?")
            params.append(int(payload.active))
        if not updates:
            return {"ok": True, "updated": 0}
        params.append(rt_id)
        con.execute(f"UPDATE request_types SET {', '.join(updates)} WHERE id=?", params)
        audit(con, user["id"], "REQUEST_TYPE_UPDATE", "request_type", rt_id, {"fields": updates})
    return {"ok": True, "updated": len(updates)}

@app.delete("/api/request-types/{rt_id}")
def delete_request_type(rt_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "settings.request_types")
    with db() as con:
        existing = con.execute("SELECT * FROM request_types WHERE id=?", (rt_id,)).fetchone()
        if not existing: raise HTTPException(404, "نوع درخواست پیدا نشد")
        # Check if there are requests using this type
        count = con.execute("SELECT COUNT(*) FROM requests WHERE request_type_id=?", (rt_id,)).fetchone()[0]
        if count > 0:
            # Soft delete: just deactivate
            con.execute("UPDATE request_types SET active=0 WHERE id=?", (rt_id,))
            audit(con, user["id"], "REQUEST_TYPE_DEACTIVATE", "request_type", rt_id, {"usage": count})
            return {"ok": True, "deactivated": True, "usage": count}
        con.execute("DELETE FROM request_types WHERE id=?", (rt_id,))
        audit(con, user["id"], "REQUEST_TYPE_DELETE", "request_type", rt_id, {"code": existing["code"]})
    return {"ok": True, "deactivated": False}


@app.post("/api/attendance/{action}")
def attendance(action:str,request:Request):
    user=current_user(request)
    if action not in ("in","out"): raise HTTPException(404,"عملیات نامعتبر است")
    with db() as con:
        day=datetime.now(ZoneInfo("Asia/Tehran")).strftime("%Y-%m-%d")
        row=con.execute("SELECT * FROM attendance WHERE user_id=? AND work_date=?",(user["id"],day)).fetchone()
        timestamp=now()
        if action=="in":
            if row and row["check_in"]: raise HTTPException(409,"ورود امروز قبلاً ثبت شده است")
            if row: con.execute("UPDATE attendance SET check_in=? WHERE id=?",(timestamp,row["id"]))
            else: con.execute("INSERT INTO attendance VALUES(?,?,?,?,?)",(uid(),user["id"],day,timestamp,None))
        else:
            if not row or not row["check_in"]: raise HTTPException(409,"ابتدا ورود امروز را ثبت کنید")
            if row["check_out"]: raise HTTPException(409,"خروج امروز قبلاً ثبت شده است")
            con.execute("UPDATE attendance SET check_out=? WHERE id=?",(timestamp,row["id"]))
        audit(con,user["id"],f"ATTENDANCE_{action.upper()}","attendance",user["id"],{"date":day})
        return {"ok":True,"at":timestamp}


@app.get("/api/attendance")
def get_attendance(request:Request):
    user=current_user(request)
    with db() as con:
        if user["role"] in ("ADMIN","CEO"):
            rows=con.execute("SELECT a.*,u.name user_name FROM attendance a JOIN users u ON u.id=a.user_id ORDER BY work_date DESC,check_in DESC LIMIT 100").fetchall()
        else: rows=con.execute("SELECT * FROM attendance WHERE user_id=? ORDER BY work_date DESC LIMIT 30",(user["id"],)).fetchall()
        return [dict(r) for r in rows]


@app.get("/api/notifications")
def get_notifications(request:Request):
    user=current_user(request)
    with db() as con: return [dict(r) for r in con.execute("SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 50",(user["id"],))]


@app.post("/api/notifications/{notification_id}/read")
def mark_read(notification_id:str,request:Request):
    user=current_user(request)
    with db() as con: con.execute("UPDATE notifications SET read_at=? WHERE id=? AND user_id=?",(now(),notification_id,user["id"]))
    return {"ok":True}


@app.get("/api/audit")
def get_audit(request:Request):
    user=current_user(request); require_perm(user, "audit.view")
    with db() as con:
        rows=con.execute("SELECT a.*,u.name actor_name FROM audit_events a LEFT JOIN users u ON u.id=a.actor_id ORDER BY created_at DESC LIMIT 200").fetchall()
        return [{**dict(r),"details":json.loads(r["details"])} for r in rows]


@app.get("/api/files/{stored_name}")
def download_file(stored_name:str,request:Request):
    user=current_user(request)
    if not re.fullmatch(r"[a-f0-9]{32}\.xlsx",stored_name): raise HTTPException(404,"فایل پیدا نشد")
    with db() as con:
        sub=con.execute("SELECT s.task_id,s.original_name,t.company_id,t.assignee_id FROM submissions s JOIN tasks t ON t.id=s.task_id WHERE s.stored_name=?",(stored_name,)).fetchone()
        ref=con.execute("SELECT company_id,original_name FROM reference_versions WHERE stored_name=?",(stored_name,)).fetchone()
        if sub:
            if user["role"] not in ("ADMIN","CEO") and sub["assignee_id"]!=user["id"] and not can_access_company(con,user,sub["company_id"]): raise HTTPException(403,"دسترسی ندارید")
            filename=sub["original_name"]
        elif ref:
            if user["role"] not in ("ADMIN","CEO") and not can_access_company(con,user,ref["company_id"]): raise HTTPException(403,"دسترسی ندارید")
            filename=ref["original_name"]
        else: raise HTTPException(404,"فایل پیدا نشد")
        if not (FILES/stored_name).exists(): raise HTTPException(404,"فایل پیدا نشد")
        return FileResponse(FILES/stored_name,filename=filename,media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.get("/api/template")
def template(request:Request):
    current_user(request)
    from io import BytesIO
    from openpyxl import Workbook
    wb=Workbook(); ws=wb.active; ws.title="اسناد"
    ws.append(["ردیف","شماره سند","تاریخ سند","کل","معین","تفصیل","شرح سند","بدهکار","بستانکار"])
    ws.freeze_panes="A2"; ws.auto_filter.ref="A1:I1"
    for col,width in zip("ABCDEFGHI",[10,18,16,18,18,18,36,18,18]): ws.column_dimensions[col].width=width
    out=BytesIO(); wb.save(out); out.seek(0)
    from fastapi.responses import StreamingResponse
    return StreamingResponse(out,media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",headers={"Content-Disposition":"attachment; filename=yfg-template.xlsx"})


# ========================================================================
# PHASE 2: TIME TRACKING API
# ========================================================================

class TimeStartModel(BaseModel):
    task_id: str
    description: str = ""

@app.post("/api/time/start")
def time_start(payload: TimeStartModel, request: Request):
    user = current_user(request)
    with db() as con:
        # Check no active timer
        active = con.execute("SELECT id FROM time_entries WHERE user_id=? AND end_at IS NULL", (user["id"],)).fetchone()
        if active:
            raise HTTPException(409, "تایمر فعالی دارید؛ ابتدا آن را متوقف کنید")
        entry_id = uid()
        con.execute("INSERT INTO time_entries VALUES(?,?,?,?,?,?,?,?,?)",
                     (entry_id, payload.task_id, user["id"], now(), None, 0, payload.description, 1, now()))
        audit(con, user["id"], "TIME_START", "time_entry", entry_id, {"task_id": payload.task_id})
        return {"id": entry_id, "started_at": now()}

@app.post("/api/time/stop")
def time_stop(request: Request):
    user = current_user(request)
    with db() as con:
        entry = con.execute("SELECT * FROM time_entries WHERE user_id=? AND end_at IS NULL", (user["id"],)).fetchone()
        if not entry:
            raise HTTPException(404, "تایمر فعالی وجود ندارد")
        end = now()
        start_dt = datetime.fromisoformat(entry["start_at"])
        end_dt = datetime.fromisoformat(end)
        duration = int((end_dt - start_dt).total_seconds())
        con.execute("UPDATE time_entries SET end_at=?, duration_seconds=? WHERE id=?", (end, duration, entry["id"]))
        audit(con, user["id"], "TIME_STOP", "time_entry", entry["id"], {"duration": duration})
        return {"id": entry["id"], "duration_seconds": duration}

@app.get("/api/time/active")
def time_active(request: Request):
    user = current_user(request)
    with db() as con:
        entry = con.execute("""SELECT te.*, t.title AS task_title, c.name AS company_name
                               FROM time_entries te LEFT JOIN tasks t ON t.id=te.task_id
                               LEFT JOIN companies c ON c.id=t.company_id
                               WHERE te.user_id=? AND te.end_at IS NULL""", (user["id"],)).fetchone()
        if entry:
            return dict(entry)
        return None

@app.get("/api/time/entries")
def time_entries_list(request: Request, task_id: str | None = None, user_id: str | None = None):
    user = current_user(request)
    with db() as con:
        query = """SELECT te.*, t.title AS task_title, u.name AS user_name, c.name AS company_name
                   FROM time_entries te LEFT JOIN tasks t ON t.id=te.task_id
                   LEFT JOIN users u ON u.id=te.user_id
                   LEFT JOIN companies c ON c.id=t.company_id WHERE 1=1"""
        args = []
        if user["role"] not in ("ADMIN", "CEO"):
            query += " AND te.user_id=?"
            args.append(user["id"])
        if task_id:
            query += " AND te.task_id=?"
            args.append(task_id)
        if user_id and user["role"] in ("ADMIN", "CEO"):
            query += " AND te.user_id=?"
            args.append(user_id)
        query += " ORDER BY te.start_at DESC LIMIT 200"
        rows = con.execute(query, args).fetchall()
        return [dict(r) for r in rows]

@app.get("/api/time/timesheet")
def timesheet(request: Request, start_date: str | None = None, end_date: str | None = None):
    user = current_user(request)
    with db() as con:
        query = """SELECT te.user_id, u.name AS user_name, te.task_id, t.title AS task_title,
                   c.name AS company_name, SUM(te.duration_seconds) AS total_seconds,
                   COUNT(te.id) AS entry_count
                   FROM time_entries te JOIN users u ON u.id=te.user_id
                   LEFT JOIN tasks t ON t.id=te.task_id
                   LEFT JOIN companies c ON c.id=t.company_id
                   WHERE te.end_at IS NOT NULL"""
        args = []
        if user["role"] not in ("ADMIN", "CEO"):
            query += " AND te.user_id=?"
            args.append(user["id"])
        if start_date:
            query += " AND te.start_at>=?"
            args.append(start_date)
        if end_date:
            query += " AND te.start_at<=?"
            args.append(end_date)
        query += " GROUP BY te.user_id, te.task_id ORDER BY u.name, t.title"
        rows = con.execute(query, args).fetchall()
        return [dict(r) for r in rows]


# ========================================================================
# PHASE 3: AUTOMATIONS API
# ========================================================================

class AutomationModel(BaseModel):
    name: str
    trigger_type: str  # TASK_OVERDUE, TASK_SUBMITTED, TASK_RETURNED, TASK_ASSIGNED
    trigger_config: dict = {}
    action_type: str   # NOTIFY_USER, NOTIFY_MANAGER, SET_PRIORITY, ADD_COMMENT
    action_config: dict = {}
    enabled: bool = True

@app.get("/api/automations")
def list_automations(request: Request):
    user = current_user(request)
    require_perm(user, "automations.manage")
    with db() as con:
        rows = con.execute("SELECT * FROM automations ORDER BY created_at DESC").fetchall()
        return [{**dict(r), "trigger_config": json.loads(r["trigger_config"]), "action_config": json.loads(r["action_config"])} for r in rows]

@app.post("/api/automations")
def create_automation(payload: AutomationModel, request: Request):
    user = current_user(request)
    require_perm(user, "automations.manage")
    with db() as con:
        a_id = uid()
        con.execute("INSERT INTO automations VALUES(?,?,?,?,?,?,?,?,?,?)",
                     (a_id, payload.name, payload.trigger_type, json.dumps(payload.trigger_config, ensure_ascii=False),
                      payload.action_type, json.dumps(payload.action_config, ensure_ascii=False),
                      1 if payload.enabled else 0, user["id"], now(), None))
        audit(con, user["id"], "AUTOMATION_CREATE", "automation", a_id, {"name": payload.name})
        return {"id": a_id}

@app.patch("/api/automations/{automation_id}")
def toggle_automation(automation_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "automations.manage")
    with db() as con:
        a = con.execute("SELECT * FROM automations WHERE id=?", (automation_id,)).fetchone()
        if not a:
            raise HTTPException(404, "اتوماسیون پیدا نشد")
        new_val = 0 if a["enabled"] else 1
        con.execute("UPDATE automations SET enabled=? WHERE id=?", (new_val, automation_id))
        audit(con, user["id"], "AUTOMATION_TOGGLE", "automation", automation_id, {"enabled": new_val})
        return {"enabled": new_val}

@app.delete("/api/automations/{automation_id}")
def delete_automation(automation_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "automations.manage")
    with db() as con:
        con.execute("DELETE FROM automations WHERE id=?", (automation_id,))
        audit(con, user["id"], "AUTOMATION_DELETE", "automation", automation_id, {})
        return {"ok": True}

@app.post("/api/automations/run")
def run_automations(request: Request):
    """Run all enabled automations — check overdue tasks, notify, etc."""
    user = current_user(request)
    require_perm(user, "automations.manage")
    results = []
    with db() as con:
        automations = con.execute("SELECT * FROM automations WHERE enabled=1").fetchall()
        for a in automations:
            fired = False
            if a["trigger_type"] == "TASK_OVERDUE":
                overdue = con.execute("""SELECT t.*, u.id AS assignee_id FROM tasks t JOIN users u ON u.id=t.assignee_id
                                         WHERE t.due_date < ? AND t.status NOT IN ('APPROVED','APPROVED_WITH_EXCEPTION','CANCELLED')""",
                                       (now(),)).fetchall()
                for t in overdue:
                    notify(con, t["assignee_id"], "مهلت تسک گذشته", f"تسک «{t['title']}» از موعد گذشته است")
                    fired = True
            elif a["trigger_type"] == "TASK_ASSIGNED":
                assigned = con.execute("""SELECT t.*, u.id AS assignee_id FROM tasks t JOIN users u ON u.id=t.assignee_id
                                          WHERE t.status='ASSIGNED' AND t.created_at > ?""", (a["last_fired_at"] or "2000-01-01")).fetchall()
                for t in assigned:
                    notify(con, t["assignee_id"], "تسک جدید", f"تسک «{t['title']}» به شما ارجاع شد")
                    fired = True
            if fired:
                con.execute("UPDATE automations SET last_fired_at=? WHERE id=?", (now(), a["id"]))
                results.append({"automation": a["name"], "fired": True})
        audit(con, user["id"], "AUTOMATION_RUN", "automation", None, {"results": len(results)})
    return {"results": results}


# ========================================================================
# PHASE 4: CHAT API — full in-app messenger
#   • Direct messages (DM) — auto channel between two users
#   • Group channels — admin or any user can create with member_ids
#   • File attachments (chat_attachments table)
#   • Read receipts (last_read_at)
#   • Polling-friendly list (no WebSocket needed for MVP)
# ========================================================================

class ChatMessageModel(BaseModel):
    body: str = ""
    attachment_id: str | None = None
    reply_to: str | None = None

class ChatChannelModel(BaseModel):
    name: str = ""
    member_ids: list[str] = []

class ChatAddMembersModel(BaseModel):
    member_ids: list[str] = []

class ChatRenameModel(BaseModel):
    name: str

def _channel_display_name(channel: sqlite3.Row, viewer_id: str, con) -> str:
    """For DIRECT channels, show the other user's name. For GROUP, show channel name."""
    if channel["kind"] == "DIRECT":
        others = con.execute(
            "SELECT u.name FROM chat_channel_members m JOIN users u ON u.id=m.user_id "
            "WHERE m.channel_id=? AND m.user_id!=?",
            (channel["id"], viewer_id)
        ).fetchall()
        names = [o["name"] for o in others]
        return "، ".join(names) if names else (channel["name"] or "گفتگو مستقیم")
    return channel["name"] or "گروه بدون نام"

@app.get("/api/chat/channels")
def list_channels(request: Request):
    user = current_user(request)
    require_perm(user, "chat.use")
    with db() as con:
        rows = con.execute("""
            SELECT cc.id, cc.name, cc.kind, cc.created_by, cc.created_at,
                   (SELECT COUNT(*) FROM chat_messages WHERE channel_id=cc.id) AS message_count,
                   (SELECT COUNT(*) FROM chat_messages WHERE channel_id=cc.id
                       AND created_at > COALESCE(
                           (SELECT last_read_at FROM chat_channel_members WHERE channel_id=cc.id AND user_id=?), ''
                       )) AS unread_count
            FROM chat_channels cc
            JOIN chat_channel_members m ON m.channel_id=cc.id AND m.user_id=?
            ORDER BY (SELECT MAX(created_at) FROM chat_messages WHERE channel_id=cc.id) DESC,
                     cc.created_at DESC
        """, (user["id"], user["id"])).fetchall()
        result = []
        for r in rows:
            d = dict(r)
            d["display_name"] = _channel_display_name(r, user["id"], con)
            result.append(d)
        return result

@app.get("/api/chat/channels/{channel_id}")
def get_channel(channel_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "chat.use")
    with db() as con:
        ch = con.execute("SELECT * FROM chat_channels WHERE id=?", (channel_id,)).fetchone()
        if not ch: raise HTTPException(404, "گفتگو پیدا نشد")
        is_member = con.execute(
            "SELECT 1 FROM chat_channel_members WHERE channel_id=? AND user_id=?",
            (channel_id, user["id"])
        ).fetchone()
        if not is_member and user["role"] not in ("ADMIN", "CEO"):
            raise HTTPException(403, "شما عضو این گفتگو نیستید")
        members = con.execute(
            "SELECT u.id, u.name, u.first_name, u.last_name, u.role, m.joined_at, m.last_read_at "
            "FROM chat_channel_members m JOIN users u ON u.id=m.user_id WHERE m.channel_id=? "
            "ORDER BY m.joined_at",
            (channel_id,)
        ).fetchall()
        d = dict(ch)
        d["display_name"] = _channel_display_name(ch, user["id"], con)
        d["members"] = [dict(m) for m in members]
        return d

@app.post("/api/chat/channels")
def create_channel(payload: ChatChannelModel, request: Request):
    user = current_user(request)
    require_perm(user, "chat.use")
    if not payload.member_ids:
        raise HTTPException(400, "حداقل یک کاربر را انتخاب کنید")
    with db() as con:
        for mid in payload.member_ids:
            exists = con.execute("SELECT 1 FROM users WHERE id=? AND active=1", (mid,)).fetchone()
            if not exists: raise HTTPException(400, f"کاربر انتخابشده وجود ندارد: {mid}")
        if len(payload.member_ids) == 1:
            other = payload.member_ids[0]
            if other == user["id"]:
                raise HTTPException(400, "نمیتوانید به خودتان گفتگو مستقیم بسازید")
            existing = con.execute("""
                SELECT c.* FROM chat_channels c
                WHERE c.kind='DIRECT'
                AND c.id IN (SELECT channel_id FROM chat_channel_members WHERE user_id=?)
                AND c.id IN (SELECT channel_id FROM chat_channel_members WHERE user_id=?)
                AND (SELECT COUNT(*) FROM chat_channel_members WHERE channel_id=c.id) = 2
            """, (user["id"], other)).fetchone()
            if existing:
                return {"id": existing["id"], "kind": "DIRECT", "name": "", "created": False}
            ch_id = uid()
            con.execute("INSERT INTO chat_channels VALUES(?,?,?,?,?)",
                        (ch_id, "", "DIRECT", user["id"], now()))
            con.execute("INSERT INTO chat_channel_members (channel_id, user_id, joined_at) VALUES(?,?,?)", (ch_id, user["id"], now()))
            con.execute("INSERT INTO chat_channel_members (channel_id, user_id, joined_at) VALUES(?,?,?)", (ch_id, other, now()))
            audit(con, user["id"], "CHAT_DM_CREATE", "chat_channel", ch_id, {"with": other})
            return {"id": ch_id, "kind": "DIRECT", "name": "", "created": True}
        name = (payload.name or "").strip() or "گروه جدید"
        ch_id = uid()
        con.execute("INSERT INTO chat_channels VALUES(?,?,?,?,?)",
                    (ch_id, name, "GROUP", user["id"], now()))
        members = set(payload.member_ids + [user["id"]])
        for mid in members:
            con.execute("INSERT OR IGNORE INTO chat_channel_members (channel_id, user_id, joined_at) VALUES(?,?,?)", (ch_id, mid, now()))
        audit(con, user["id"], "CHAT_GROUP_CREATE", "chat_channel", ch_id, {"name": name, "members": list(members)})
        return {"id": ch_id, "kind": "GROUP", "name": name, "created": True}

@app.patch("/api/chat/channels/{channel_id}")
def rename_channel(channel_id: str, payload: ChatRenameModel, request: Request):
    user = current_user(request)
    require_perm(user, "chat.use")
    name = (payload.name or "").strip()
    if not name: raise HTTPException(400, "نام گروه نمیتواند خالی باشد")
    with db() as con:
        ch = con.execute("SELECT * FROM chat_channels WHERE id=?", (channel_id,)).fetchone()
        if not ch: raise HTTPException(404, "گفتگو پیدا نشد")
        if ch["kind"] != "GROUP":
            raise HTTPException(400, "فقط گروهها قابل تغییر نام هستند")
        if user["role"] not in ("ADMIN", "CEO") and ch["created_by"] != user["id"]:
            raise HTTPException(403, "فقط سازنده گروه یا مدیر میتواند نام را تغییر دهد")
        con.execute("UPDATE chat_channels SET name=? WHERE id=?", (name, channel_id))
        audit(con, user["id"], "CHAT_RENAME", "chat_channel", channel_id, {"name": name})
        return {"id": channel_id, "name": name}

@app.post("/api/chat/channels/{channel_id}/members")
def add_members(channel_id: str, payload: ChatAddMembersModel, request: Request):
    user = current_user(request)
    require_perm(user, "chat.use")
    with db() as con:
        ch = con.execute("SELECT * FROM chat_channels WHERE id=?", (channel_id,)).fetchone()
        if not ch: raise HTTPException(404, "گفتگو پیدا نشد")
        if ch["kind"] != "GROUP":
            raise HTTPException(400, "فقط در گروهها میتوان عضو اضافه کرد")
        if user["role"] not in ("ADMIN", "CEO") and ch["created_by"] != user["id"]:
            raise HTTPException(403, "فقط سازنده گروه یا مدیر میتواند عضو اضافه کند")
        added = 0
        for mid in payload.member_ids:
            exists = con.execute("SELECT 1 FROM users WHERE id=? AND active=1", (mid,)).fetchone()
            if not exists: continue
            cur = con.execute("INSERT OR IGNORE INTO chat_channel_members (channel_id, user_id, joined_at) VALUES(?,?,?)",
                              (channel_id, mid, now()))
            added += cur.rowcount
            notify(con, mid, "گروه جدید", f"شما به گروه «{ch['name']}» اضافه شدید")
        audit(con, user["id"], "CHAT_ADD_MEMBERS", "chat_channel", channel_id, {"added": added})
        return {"added": added}

@app.get("/api/chat/channels/{channel_id}/messages")
def list_messages(channel_id: str, request: Request, monitor: int = 0):
    """Return messages for a channel. If monitor=1 and user has chat.monitor permission,
    no read/delivered events are recorded (silent admin oversight)."""
    user = current_user(request)
    require_perm(user, "chat.use")
    is_monitor = monitor == 1 and has_perm(user, "chat.monitor")
    with db() as con:
        if not is_monitor:
            is_member = con.execute(
                "SELECT 1 FROM chat_channel_members WHERE channel_id=? AND user_id=?",
                (channel_id, user["id"])
            ).fetchone()
            if not is_member and user["role"] not in ("ADMIN", "CEO"):
                raise HTTPException(403, "شما عضو این گفتگو نیستید")
            # Mark messages NOT sent by me as delivered (single tick → double tick)
            ts = now()
            con.execute("""UPDATE chat_messages SET delivered_at=?
                            WHERE channel_id=? AND user_id!=? AND delivered_at=''""",
                         (ts, channel_id, user["id"]))
            con.commit()
        else:
            # Monitoring silently: do not record delivered_at
            pass
        rows = con.execute("""
            SELECT cm.id, cm.channel_id, cm.user_id, cm.body, cm.attachment_id, cm.reply_to,
                   cm.delivered_at, cm.read_at, cm.created_at,
                   u.name AS user_name, u.first_name, u.last_name, u.role AS user_role,
                   ca.original_name AS attachment_name, ca.size_bytes AS attachment_size, ca.mime_type AS attachment_mime
            FROM chat_messages cm
            JOIN users u ON u.id=cm.user_id
            LEFT JOIN chat_attachments ca ON ca.id=cm.attachment_id
            WHERE cm.channel_id=?
            ORDER BY cm.created_at ASC LIMIT 500
        """, (channel_id,)).fetchall()
        return [dict(r) for r in rows]

@app.post("/api/chat/channels/{channel_id}/messages")
def send_message(channel_id: str, payload: ChatMessageModel, request: Request):
    user = current_user(request)
    require_perm(user, "chat.use")
    if not payload.body.strip() and not payload.attachment_id:
        raise HTTPException(400, "پیام نمیتواند خالی باشد")
    with db() as con:
        ch = con.execute("SELECT * FROM chat_channels WHERE id=?", (channel_id,)).fetchone()
        if not ch: raise HTTPException(404, "گفتگو پیدا نشد")
        is_member = con.execute(
            "SELECT 1 FROM chat_channel_members WHERE channel_id=? AND user_id=?",
            (channel_id, user["id"])
        ).fetchone()
        if not is_member and user["role"] not in ("ADMIN", "CEO"):
            raise HTTPException(403, "شما عضو این گفتگو نیستید")
        if payload.attachment_id:
            att = con.execute("SELECT * FROM chat_attachments WHERE id=?", (payload.attachment_id,)).fetchone()
            if not att or att["uploaded_by"] != user["id"]:
                raise HTTPException(400, "پیوست نامعتبر")
        msg_id = uid()
        con.execute(
            "INSERT INTO chat_messages (id, channel_id, user_id, body, attachment_id, reply_to, delivered_at, read_at, created_at) VALUES(?,?,?,?,?,?,?,?,?)",
            (msg_id, channel_id, user["id"], payload.body.strip(), payload.attachment_id, payload.reply_to, "", "", now())
        )
        members = con.execute(
            "SELECT user_id FROM chat_channel_members WHERE channel_id=? AND user_id!=?",
            (channel_id, user["id"])
        ).fetchall()
        ch_name = _channel_display_name(ch, user["id"], con) if ch["kind"] == "GROUP" else "گفتگو مستقیم"
        preview = (payload.body[:50] + "…") if len(payload.body) > 50 else payload.body
        if not preview and payload.attachment_id:
            preview = "[فایل پیوست]"
        for m in members:
            notify(con, m["user_id"], f"پیام جدید در {ch_name}", f"{user['name']}: {preview}")
        audit(con, user["id"], "CHAT_MESSAGE", "chat_message", msg_id, {"channel_id": channel_id})
        return {"id": msg_id, "created_at": now()}

@app.post("/api/chat/channels/{channel_id}/read")
def mark_channel_read(channel_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "chat.use")
    with db() as con:
        is_member = con.execute(
            "SELECT 1 FROM chat_channel_members WHERE channel_id=? AND user_id=?",
            (channel_id, user["id"])
        ).fetchone()
        if not is_member: raise HTTPException(403, "عضو نیستید")
        ts = now()
        # Update last_read_at (used for unread badges)
        con.execute("UPDATE chat_channel_members SET last_read_at=? WHERE channel_id=? AND user_id=?",
                    (ts, channel_id, user["id"]))
        # Mark all messages NOT sent by me as read (delivered_at → read_at, double tick → blue)
        con.execute("""UPDATE chat_messages SET delivered_at=COALESCE(NULLIF(delivered_at,''), ?), read_at=?
                       WHERE channel_id=? AND user_id!=? AND (read_at='' OR read_at IS NULL)""",
                    (ts, ts, channel_id, user["id"]))
        con.commit()
        return {"ok": True, "read_at": ts}

@app.post("/api/chat/upload")
async def chat_upload(request: Request, file: UploadFile = File(...)):
    """Upload a file for chat attachment. Returns attachment_id to use in send_message."""
    user = current_user(request)
    require_perm(user, "chat.use")
    content = await file.read(CHAT_ATTACHMENT_MAX + 1)
    if len(content) > CHAT_ATTACHMENT_MAX:
        raise HTTPException(413, "حجم فایل بیش از حد مجاز (۲۵ مگابایت)")
    if not file.filename:
        raise HTTPException(400, "نام فایل نامعتبر")
    suffix = Path(file.filename).suffix.lower()
    if suffix not in CHAT_ATTACHMENT_ALLOWED:
        raise HTTPException(400, f"نوع فایل پشتیبانی نمیشود: {suffix}. مجاز: تصویر، PDF، اکسل، ورد، فشرده")
    att_id = uid()
    stored_name = f"{att_id}{suffix}"
    (ATTACHMENTS_DIR / stored_name).write_bytes(content)
    import hashlib
    sha = hashlib.sha256(content).hexdigest()
    with db() as con:
        con.execute(
            "INSERT INTO chat_attachments VALUES(?,?,?,?,?,?,?,?)",
            (att_id, file.filename, stored_name, file.content_type or "application/octet-stream",
             len(content), sha, user["id"], now())
        )
        audit(con, user["id"], "CHAT_UPLOAD", "chat_attachment", att_id,
              {"name": file.filename, "size": len(content)})
    return {"attachment_id": att_id, "original_name": file.filename, "size": len(content)}

@app.get("/api/chat/attachments/{att_id}")
def download_attachment(att_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "chat.use")
    with db() as con:
        att = con.execute("SELECT * FROM chat_attachments WHERE id=?", (att_id,)).fetchone()
        if not att: raise HTTPException(404, "پیوست پیدا نشد")
        msg = con.execute(
            "SELECT channel_id FROM chat_messages WHERE attachment_id=?", (att_id,)
        ).fetchone()
        if msg:
            is_member = con.execute(
                "SELECT 1 FROM chat_channel_members WHERE channel_id=? AND user_id=?",
                (msg["channel_id"], user["id"])
            ).fetchone()
            if not is_member and user["role"] not in ("ADMIN", "CEO"):
                raise HTTPException(403, "دسترسی غیرمجاز")
        path = ATTACHMENTS_DIR / att["stored_name"]
        if not path.exists(): raise HTTPException(404, "فایل روی دیسک پیدا نشد")
        from fastapi.responses import FileResponse
        return FileResponse(str(path), filename=att["original_name"], media_type=att["mime_type"])

@app.get("/api/chat/users")
def list_chat_users(request: Request):
    """List active users (other than me) for the new chat picker."""
    user = current_user(request)
    require_perm(user, "chat.use")
    with db() as con:
        rows = con.execute(
            "SELECT id, name, first_name, last_name, role, active FROM users "
            "WHERE active=1 AND id!=? ORDER BY name",
            (user["id"],)
        ).fetchall()
        return [dict(r) for r in rows]

@app.get("/api/chat/admin/all-channels")
def admin_all_channels(request: Request):
    """List ALL channels (for silent admin monitoring).
    Requires chat.monitor permission. Returns display name, member list, last message preview,
    and per-message counts. No read/delivered events are recorded when admin views messages via
    the monitor endpoint."""
    user = current_user(request)
    require_perm(user, "chat.monitor")
    with db() as con:
        rows = con.execute("""
            SELECT c.id, c.name, c.kind, c.created_by, c.created_at,
                   (SELECT COUNT(*) FROM chat_messages WHERE channel_id=c.id) AS message_count,
                   (SELECT created_at FROM chat_messages WHERE channel_id=c.id
                       ORDER BY created_at DESC LIMIT 1) AS last_message_at,
                   (SELECT COUNT(*) FROM chat_channel_members WHERE channel_id=c.id) AS member_count
            FROM chat_channels c
            ORDER BY last_message_at DESC NULLS LAST, c.created_at DESC
        """).fetchall()
        result = []
        for r in rows:
            d = dict(r)
            # Get member names
            members = con.execute(
                "SELECT u.id, u.name, u.role FROM chat_channel_members m JOIN users u ON u.id=m.user_id WHERE m.channel_id=?",
                (r["id"],)
            ).fetchall()
            d["members"] = [dict(m) for m in members]
            if r["kind"] == "DIRECT":
                d["display_name"] = "، ".join(m["name"] for m in d["members"])
            else:
                d["display_name"] = r["name"] or "گروه بدون نام"
            result.append(d)
        return result


# ========================================================================
# PHASE 4b: CUSTOMERS API — persons (active) + placeholder stubs
# ========================================================================

class PersonCreateModel(BaseModel):
    code: str
    first_name: str
    last_name: str
    national_id: str = ""
    phone: str = ""
    email: str = ""
    address: str = ""
    postal_code: str = ""
    notes: str = ""
    linked_company_id: str | None = None
    active: int = 1

class PersonUpdateModel(BaseModel):
    first_name: str | None = None
    last_name: str | None = None
    national_id: str | None = None
    phone: str | None = None
    email: str | None = None
    address: str | None = None
    postal_code: str | None = None
    notes: str | None = None
    linked_company_id: str | None = None
    active: int | None = None

# ===== Contracts / Proformas / Invoices models =====
class ContractCreateModel(BaseModel):
    code: str
    title: str
    company_id: str
    person_id: str | None = None
    start_date: str  # ISO YYYY-MM-DD
    end_date: str
    value_amount: float = 0
    currency: str = "IRR"
    status: str = "DRAFT"
    contract_type: str = "general"
    subject: str = ""
    notes: str = ""

class ContractUpdateModel(BaseModel):
    title: str | None = None
    company_id: str | None = None
    person_id: str | None = None
    start_date: str | None = None
    end_date: str | None = None
    value_amount: float | None = None
    currency: str | None = None
    status: str | None = None
    contract_type: str | None = None
    subject: str | None = None
    notes: str | None = None

class ProformaItemModel(BaseModel):
    description: str
    qty: float = 1
    unit_price: float = 0
    total: float | None = None
    notes: str = ""

class ProformaCreateModel(BaseModel):
    code: str
    title: str
    company_id: str
    person_id: str | None = None
    contract_id: str | None = None
    issue_date: str
    valid_until: str | None = None
    status: str = "DRAFT"
    total_amount: float = 0
    currency: str = "IRR"
    items: list[dict] = []  # use list[dict] for flexibility (Pydantic v2)
    notes: str = ""

class ProformaUpdateModel(BaseModel):
    title: str | None = None
    company_id: str | None = None
    person_id: str | None = None
    contract_id: str | None = None
    issue_date: str | None = None
    valid_until: str | None = None
    status: str | None = None
    total_amount: float | None = None
    currency: str | None = None
    items: list[dict] | None = None
    notes: str | None = None

class InvoiceCreateModel(BaseModel):
    code: str
    title: str
    company_id: str
    person_id: str | None = None
    proforma_id: str | None = None
    contract_id: str | None = None
    issue_date: str
    due_date: str | None = None
    status: str = "DRAFT"
    total_amount: float = 0
    paid_amount: float = 0
    currency: str = "IRR"
    items: list[dict] = []
    notes: str = ""

class InvoiceUpdateModel(BaseModel):
    title: str | None = None
    company_id: str | None = None
    person_id: str | None = None
    proforma_id: str | None = None
    contract_id: str | None = None
    issue_date: str | None = None
    due_date: str | None = None
    status: str | None = None
    total_amount: float | None = None
    paid_amount: float | None = None
    currency: str | None = None
    items: list[dict] | None = None
    notes: str | None = None

class CompanyContactCreateModel(BaseModel):
    contact_type: str = "PHONE"
    label: str = ""
    value: str
    notes: str = ""

@app.get("/api/persons")
def list_persons(request: Request, q: str = ""):
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        sql = """SELECT p.*, c.name AS linked_company_name
                 FROM persons p LEFT JOIN companies c ON c.id=p.linked_company_id
                 WHERE 1=1"""
        params: list = []
        if q:
            sql += " AND (p.first_name LIKE ? OR p.last_name LIKE ? OR p.code LIKE ? OR p.national_id LIKE ? OR p.phone LIKE ?)"
            kw = f"%{q}%"
            params = [kw, kw, kw, kw, kw]
        sql += " ORDER BY p.created_at DESC LIMIT 500"
        rows = con.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

@app.post("/api/persons")
def create_person(payload: PersonCreateModel, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    if not payload.code.strip() or not payload.first_name.strip() or not payload.last_name.strip():
        raise HTTPException(400, "کد، نام و نام خانوادگی الزامی است")
    if payload.linked_company_id:
        with db() as con:
            if not con.execute("SELECT 1 FROM companies WHERE id=?", (payload.linked_company_id,)).fetchone():
                raise HTTPException(400, "شرکت انتخابشده وجود ندارد")
    pid = uid()
    with db() as con:
        try:
            con.execute("""INSERT INTO persons
                (id, code, first_name, last_name, national_id, phone, email, address, postal_code, notes,
                 linked_company_id, active, created_by, created_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (pid, payload.code.strip(), payload.first_name.strip(), payload.last_name.strip(),
                 payload.national_id, payload.phone, payload.email, payload.address, payload.postal_code,
                 payload.notes, payload.linked_company_id, payload.active, user["id"], now()))
        except Exception as e:
            if "UNIQUE" in str(e): raise HTTPException(400, "کد شخص تکراری است")
            raise
        audit(con, user["id"], "PERSON_CREATE", "person", pid, {"code": payload.code, "name": f"{payload.first_name} {payload.last_name}"})
    return {"id": pid, "code": payload.code}

@app.get("/api/persons/{person_id}")
def get_person(person_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        row = con.execute(
            "SELECT p.*, c.name AS linked_company_name FROM persons p "
            "LEFT JOIN companies c ON c.id=p.linked_company_id WHERE p.id=?",
            (person_id,)
        ).fetchone()
        if not row: raise HTTPException(404, "شخص پیدا نشد")
        return dict(row)

@app.patch("/api/persons/{person_id}")
def update_person(person_id: str, payload: PersonUpdateModel, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    with db() as con:
        existing = con.execute("SELECT * FROM persons WHERE id=?", (person_id,)).fetchone()
        if not existing: raise HTTPException(404, "شخص پیدا نشد")
        if payload.linked_company_id == "":
            payload.linked_company_id = None
        if payload.linked_company_id:
            if not con.execute("SELECT 1 FROM companies WHERE id=?", (payload.linked_company_id,)).fetchone():
                raise HTTPException(400, "شرکت انتخابشده وجود ندارد")
        updates = []
        params: list = []
        for k, v in payload.model_dump(exclude_unset=True).items():
            if v is None: continue
            updates.append(f"{k}=?")
            params.append(v)
        if not updates:
            return {"ok": True, "updated": 0}
        params.append(person_id)
        con.execute(f"UPDATE persons SET {', '.join(updates)} WHERE id=?", params)
        audit(con, user["id"], "PERSON_UPDATE", "person", person_id, {"fields": updates})
    return {"ok": True, "updated": len(updates)}

@app.delete("/api/persons/{person_id}")
def delete_person(person_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    with db() as con:
        existing = con.execute("SELECT * FROM persons WHERE id=?", (person_id,)).fetchone()
        if not existing: raise HTTPException(404, "شخص پیدا نشد")
        con.execute("DELETE FROM persons WHERE id=?", (person_id,))
        audit(con, user["id"], "PERSON_DELETE", "person", person_id, {"code": existing["code"]})
    return {"ok": True}


# ========================================================================
# CONTRACTS API (قراردادها) — full first version
# ========================================================================
def _contract_dict(row, con) -> dict:
    d = dict(row)
    if d.get("company_id"):
        company = con.execute("SELECT name FROM companies WHERE id=?", (d["company_id"],)).fetchone()
        d["company_name"] = company["name"] if company else None
    if d.get("person_id"):
        person = con.execute("SELECT first_name, last_name FROM persons WHERE id=?", (d["person_id"],)).fetchone()
        if person:
            d["person_name"] = f"{person['first_name']} {person['last_name']}".strip()
    # Compute is_active based on current date being within contract range
    today = now()[:10]
    d["is_currently_active"] = (d["status"] == "ACTIVE" and d["start_date"] <= today <= d["end_date"])
    return d

@app.get("/api/contracts")
def list_contracts(request: Request, status: str = "", active: int = 0, company_id: str = ""):
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        sql = """SELECT c.* FROM contracts c WHERE 1=1"""
        params: list = []
        if status:
            sql += " AND c.status=?"
            params.append(status)
        if active == 1:
            today = now()[:10]
            sql += " AND c.status='ACTIVE' AND c.start_date<=? AND c.end_date>=?"
            params.extend([today, today])
        if company_id:
            sql += " AND c.company_id=?"
            params.append(company_id)
        sql += " ORDER BY c.start_date DESC, c.created_at DESC"
        rows = con.execute(sql, params).fetchall()
        return [_contract_dict(r, con) for r in rows]

@app.get("/api/contracts/active")
def list_active_contracts(request: Request):
    """Returns only contracts where today's date is within the contract's date range."""
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        today = now()[:10]
        rows = con.execute("""SELECT * FROM contracts
                              WHERE status='ACTIVE' AND start_date<=? AND end_date>=?
                              ORDER BY end_date ASC""", (today, today)).fetchall()
        return [_contract_dict(r, con) for r in rows]

@app.get("/api/contracts/{contract_id}")
def get_contract(contract_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        r = con.execute("SELECT * FROM contracts WHERE id=?", (contract_id,)).fetchone()
        if not r: raise HTTPException(404, "قرارداد پیدا نشد")
        return _contract_dict(r, con)

@app.post("/api/contracts")
def create_contract(payload: ContractCreateModel, request: Request):
    user = current_user(request)
    require_perm(user, "customers.contracts")
    if not payload.code.strip() or not payload.title.strip() or not payload.company_id:
        raise HTTPException(400, "کد، عنوان و شرکت الزامی است")
    if payload.end_date < payload.start_date:
        raise HTTPException(400, "تاریخ پایان نباید قبل از شروع باشد")
    if payload.status not in ("DRAFT","ACTIVE","COMPLETED","TERMINATED"):
        raise HTTPException(400, "وضعیت نامعتبر")
    cid = uid()
    ts = now()
    with db() as con:
        try:
            con.execute("""INSERT INTO contracts
                (id, code, title, company_id, person_id, start_date, end_date, value_amount, currency, status, contract_type, subject, notes, attachment_id, created_by, created_at, updated_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (cid, payload.code.strip(), payload.title.strip(), payload.company_id, payload.person_id,
                 payload.start_date, payload.end_date, float(payload.value_amount), payload.currency,
                 payload.status, payload.contract_type, payload.subject, payload.notes, None, user["id"], ts, ts))
        except Exception as e:
            if "UNIQUE" in str(e): raise HTTPException(400, "کد قرارداد تکراری است")
            raise
        audit(con, user["id"], "CONTRACT_CREATE", "contract", cid, {"code": payload.code, "title": payload.title})
    return {"id": cid, "code": payload.code}

@app.patch("/api/contracts/{contract_id}")
def update_contract(contract_id: str, payload: ContractUpdateModel, request: Request):
    user = current_user(request)
    require_perm(user, "customers.contracts")
    with db() as con:
        existing = con.execute("SELECT * FROM contracts WHERE id=?", (contract_id,)).fetchone()
        if not existing: raise HTTPException(404, "قرارداد پیدا نشد")
        if payload.end_date and payload.start_date and payload.end_date < payload.start_date:
            raise HTTPException(400, "تاریخ پایان نباید قبل از شروع باشد")
        updates = []
        params = []
        for k, v in payload.model_dump(exclude_unset=True).items():
            if v is None: continue
            updates.append(f"{k}=?")
            params.append(v)
        if not updates:
            return {"ok": True, "updated": 0}
        updates.append("updated_at=?")
        params.append(now())
        params.append(contract_id)
        con.execute(f"UPDATE contracts SET {', '.join(updates)} WHERE id=?", params)
        audit(con, user["id"], "CONTRACT_UPDATE", "contract", contract_id, {"fields": updates})
    return {"ok": True, "updated": len(updates) - 1}

@app.delete("/api/contracts/{contract_id}")
def delete_contract(contract_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.contracts")
    with db() as con:
        existing = con.execute("SELECT * FROM contracts WHERE id=?", (contract_id,)).fetchone()
        if not existing: raise HTTPException(404, "قرارداد پیدا نشد")
        # Check if invoices/proformas reference this contract
        cnt = con.execute("SELECT COUNT(*) FROM invoices WHERE contract_id=?", (contract_id,)).fetchone()[0]
        cnt += con.execute("SELECT COUNT(*) FROM proformas WHERE contract_id=?", (contract_id,)).fetchone()[0]
        if cnt > 0:
            # Soft delete: change status to TERMINATED
            con.execute("UPDATE contracts SET status='TERMINATED', updated_at=? WHERE id=?", (now(), contract_id))
            audit(con, user["id"], "CONTRACT_TERMINATE", "contract", contract_id, {"usage": cnt})
            return {"ok": True, "terminated": True}
        con.execute("DELETE FROM contracts WHERE id=?", (contract_id,))
        audit(con, user["id"], "CONTRACT_DELETE", "contract", contract_id, {"code": existing["code"]})
    return {"ok": True, "terminated": False}


# ========================================================================
# PROFORMAS API (پیش فاکتور)
# ========================================================================
def _proforma_dict(row, con) -> dict:
    d = dict(row)
    try:
        d["items"] = json.loads(row["items_json"]) if row["items_json"] else []
    except Exception:
        d["items"] = []
    del d["items_json"]
    if d.get("company_id"):
        company = con.execute("SELECT name FROM companies WHERE id=?", (d["company_id"],)).fetchone()
        d["company_name"] = company["name"] if company else None
    if d.get("person_id"):
        person = con.execute("SELECT first_name, last_name FROM persons WHERE id=?", (d["person_id"],)).fetchone()
        if person:
            d["person_name"] = f"{person['first_name']} {person['last_name']}".strip()
    if d.get("contract_id"):
        contract = con.execute("SELECT code, title FROM contracts WHERE id=?", (d["contract_id"],)).fetchone()
        if contract:
            d["contract_code"] = contract["code"]
            d["contract_title"] = contract["title"]
    return d

@app.get("/api/proformas")
def list_proformas(request: Request, status: str = "", in_progress: int = 0, company_id: str = ""):
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        sql = """SELECT * FROM proformas WHERE 1=1"""
        params: list = []
        if status:
            sql += " AND status=?"
            params.append(status)
        if in_progress == 1:
            sql += " AND status IN ('DRAFT','IN_PROGRESS','SENT')"
        if company_id:
            sql += " AND company_id=?"
            params.append(company_id)
        sql += " ORDER BY issue_date DESC, created_at DESC"
        rows = con.execute(sql, params).fetchall()
        return [_proforma_dict(r, con) for r in rows]

@app.get("/api/proformas/in-progress")
def list_in_progress_proformas(request: Request):
    """Returns proformas that are still in progress (DRAFT, IN_PROGRESS, SENT)."""
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        rows = con.execute("""SELECT * FROM proformas
                              WHERE status IN ('DRAFT','IN_PROGRESS','SENT')
                              ORDER BY issue_date DESC, created_at DESC""").fetchall()
        return [_proforma_dict(r, con) for r in rows]

@app.get("/api/proformas/{proforma_id}")
def get_proforma(proforma_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        r = con.execute("SELECT * FROM proformas WHERE id=?", (proforma_id,)).fetchone()
        if not r: raise HTTPException(404, "پیش فاکتور پیدا نشد")
        return _proforma_dict(r, con)

@app.post("/api/proformas")
def create_proforma(payload: ProformaCreateModel, request: Request):
    user = current_user(request)
    require_perm(user, "customers.proformas")
    if not payload.code.strip() or not payload.title.strip() or not payload.company_id:
        raise HTTPException(400, "کد، عنوان و شرکت الزامی است")
    if payload.status not in ("DRAFT","IN_PROGRESS","SENT","ACCEPTED","REJECTED","EXPIRED"):
        raise HTTPException(400, "وضعیت نامعتبر")
    pid = uid()
    ts = now()
    items_json = json.dumps(payload.items, ensure_ascii=False) if payload.items else "[]"
    # Auto-calculate total_amount if items are provided and total is 0
    total = float(payload.total_amount)
    if not total and payload.items:
        total = sum((float(i.get("qty",1)) * float(i.get("unit_price",0))) for i in payload.items if isinstance(i, dict))
    with db() as con:
        try:
            con.execute("""INSERT INTO proformas
                (id, code, title, company_id, person_id, contract_id, issue_date, valid_until, status, total_amount, currency, items_json, notes, created_by, created_at, updated_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (pid, payload.code.strip(), payload.title.strip(), payload.company_id, payload.person_id,
                 payload.contract_id, payload.issue_date, payload.valid_until, payload.status, total,
                 payload.currency, items_json, payload.notes, user["id"], ts, ts))
        except Exception as e:
            if "UNIQUE" in str(e): raise HTTPException(400, "کد پیش فاکتور تکراری است")
            raise
        audit(con, user["id"], "PROFORMA_CREATE", "proforma", pid, {"code": payload.code, "title": payload.title})
    return {"id": pid, "code": payload.code}

@app.patch("/api/proformas/{proforma_id}")
def update_proforma(proforma_id: str, payload: ProformaUpdateModel, request: Request):
    user = current_user(request)
    require_perm(user, "customers.proformas")
    with db() as con:
        existing = con.execute("SELECT * FROM proformas WHERE id=?", (proforma_id,)).fetchone()
        if not existing: raise HTTPException(404, "پیش فاکتور پیدا نشد")
        updates = []
        params = []
        for k, v in payload.model_dump(exclude_unset=True).items():
            if v is None: continue
            if k == "items":
                updates.append("items_json=?")
                params.append(json.dumps(v, ensure_ascii=False))
                # Auto-recalculate total if not provided in same payload
                if payload.total_amount is None:
                    new_total = sum((float(i.get("qty",1)) * float(i.get("unit_price",0))) for i in v if isinstance(i, dict))
                    updates.append("total_amount=?")
                    params.append(new_total)
            else:
                updates.append(f"{k}=?")
                params.append(v)
        if not updates:
            return {"ok": True, "updated": 0}
        updates.append("updated_at=?")
        params.append(now())
        params.append(proforma_id)
        con.execute(f"UPDATE proformas SET {', '.join(updates)} WHERE id=?", params)
        audit(con, user["id"], "PROFORMA_UPDATE", "proforma", proforma_id, {"fields": updates})
    return {"ok": True, "updated": len(updates) - 1}

@app.delete("/api/proformas/{proforma_id}")
def delete_proforma(proforma_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.proformas")
    with db() as con:
        existing = con.execute("SELECT * FROM proformas WHERE id=?", (proforma_id,)).fetchone()
        if not existing: raise HTTPException(404, "پیش فاکتور پیدا نشد")
        # Check if invoices reference this proforma
        cnt = con.execute("SELECT COUNT(*) FROM invoices WHERE proforma_id=?", (proforma_id,)).fetchone()[0]
        if cnt > 0:
            con.execute("UPDATE proformas SET status='REJECTED', updated_at=? WHERE id=?", (now(), proforma_id))
            audit(con, user["id"], "PROFORMA_REJECT", "proforma", proforma_id, {"usage": cnt})
            return {"ok": True, "rejected": True}
        con.execute("DELETE FROM proformas WHERE id=?", (proforma_id,))
        audit(con, user["id"], "PROFORMA_DELETE", "proforma", proforma_id, {"code": existing["code"]})
    return {"ok": True, "rejected": False}


# ========================================================================
# INVOICES API (فاکتورها)
# ========================================================================
def _invoice_dict(row, con) -> dict:
    d = dict(row)
    try:
        d["items"] = json.loads(row["items_json"]) if row["items_json"] else []
    except Exception:
        d["items"] = []
    del d["items_json"]
    if d.get("company_id"):
        company = con.execute("SELECT name FROM companies WHERE id=?", (d["company_id"],)).fetchone()
        d["company_name"] = company["name"] if company else None
    if d.get("person_id"):
        person = con.execute("SELECT first_name, last_name FROM persons WHERE id=?", (d["person_id"],)).fetchone()
        if person:
            d["person_name"] = f"{person['first_name']} {person['last_name']}".strip()
    if d.get("proforma_id"):
        proforma = con.execute("SELECT code, title FROM proformas WHERE id=?", (d["proforma_id"],)).fetchone()
        if proforma:
            d["proforma_code"] = proforma["code"]
    if d.get("contract_id"):
        contract = con.execute("SELECT code, title FROM contracts WHERE id=?", (d["contract_id"],)).fetchone()
        if contract:
            d["contract_code"] = contract["code"]
    # Compute balance
    d["balance"] = float(d["total_amount"]) - float(d["paid_amount"])
    return d

@app.get("/api/invoices")
def list_invoices(request: Request, status: str = "", unpaid: int = 0, company_id: str = ""):
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        sql = """SELECT * FROM invoices WHERE 1=1"""
        params: list = []
        if status:
            sql += " AND status=?"
            params.append(status)
        if unpaid == 1:
            sql += " AND status IN ('UNPAID','PARTIAL','OVERDUE')"
        if company_id:
            sql += " AND company_id=?"
            params.append(company_id)
        sql += " ORDER BY issue_date DESC, created_at DESC"
        rows = con.execute(sql, params).fetchall()
        return [_invoice_dict(r, con) for r in rows]

@app.get("/api/invoices/unpaid")
def list_unpaid_invoices(request: Request):
    """Returns invoices that are unsettled (UNPAID, PARTIAL, OVERDUE)."""
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        rows = con.execute("""SELECT * FROM invoices
                              WHERE status IN ('UNPAID','PARTIAL','OVERDUE')
                              ORDER BY due_date ASC NULLS LAST, issue_date DESC""").fetchall()
        return [_invoice_dict(r, con) for r in rows]

@app.get("/api/invoices/{invoice_id}")
def get_invoice(invoice_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        r = con.execute("SELECT * FROM invoices WHERE id=?", (invoice_id,)).fetchone()
        if not r: raise HTTPException(404, "فاکتور پیدا نشد")
        return _invoice_dict(r, con)

@app.post("/api/invoices")
def create_invoice(payload: InvoiceCreateModel, request: Request):
    user = current_user(request)
    require_perm(user, "customers.invoices")
    if not payload.code.strip() or not payload.title.strip() or not payload.company_id:
        raise HTTPException(400, "کد، عنوان و شرکت الزامی است")
    if payload.status not in ("DRAFT","UNPAID","PARTIAL","PAID","OVERDUE","CANCELLED"):
        raise HTTPException(400, "وضعیت نامعتبر")
    iid = uid()
    ts = now()
    items_json = json.dumps(payload.items, ensure_ascii=False) if payload.items else "[]"
    total = float(payload.total_amount)
    if not total and payload.items:
        total = sum((float(i.get("qty",1)) * float(i.get("unit_price",0))) for i in payload.items if isinstance(i, dict))
    with db() as con:
        try:
            con.execute("""INSERT INTO invoices
                (id, code, title, company_id, person_id, proforma_id, contract_id, issue_date, due_date, status, total_amount, paid_amount, currency, items_json, notes, created_by, created_at, updated_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (iid, payload.code.strip(), payload.title.strip(), payload.company_id, payload.person_id,
                 payload.proforma_id, payload.contract_id, payload.issue_date, payload.due_date,
                 payload.status, total, float(payload.paid_amount), payload.currency,
                 items_json, payload.notes, user["id"], ts, ts))
        except Exception as e:
            if "UNIQUE" in str(e): raise HTTPException(400, "کد فاکتور تکراری است")
            raise
        audit(con, user["id"], "INVOICE_CREATE", "invoice", iid, {"code": payload.code, "title": payload.title})
    return {"id": iid, "code": payload.code}

@app.patch("/api/invoices/{invoice_id}")
def update_invoice(invoice_id: str, payload: InvoiceUpdateModel, request: Request):
    user = current_user(request)
    require_perm(user, "customers.invoices")
    with db() as con:
        existing = con.execute("SELECT * FROM invoices WHERE id=?", (invoice_id,)).fetchone()
        if not existing: raise HTTPException(404, "فاکتور پیدا نشد")
        updates = []
        params = []
        for k, v in payload.model_dump(exclude_unset=True).items():
            if v is None: continue
            if k == "items":
                updates.append("items_json=?")
                params.append(json.dumps(v, ensure_ascii=False))
                if payload.total_amount is None:
                    new_total = sum((float(i.get("qty",1)) * float(i.get("unit_price",0))) for i in v if isinstance(i, dict))
                    updates.append("total_amount=?")
                    params.append(new_total)
            else:
                updates.append(f"{k}=?")
                params.append(v)
        # Auto-update status if paid_amount >= total_amount
        if payload.paid_amount is not None and payload.status is None:
            new_paid = float(payload.paid_amount)
            new_total = float(existing["total_amount"]) if payload.total_amount is None else float(payload.total_amount)
            if new_paid >= new_total and new_total > 0:
                updates.append("status=?")
                params.append("PAID")
            elif new_paid > 0 and new_paid < new_total:
                updates.append("status=?")
                params.append("PARTIAL")
        if not updates:
            return {"ok": True, "updated": 0}
        updates.append("updated_at=?")
        params.append(now())
        params.append(invoice_id)
        con.execute(f"UPDATE invoices SET {', '.join(updates)} WHERE id=?", params)
        audit(con, user["id"], "INVOICE_UPDATE", "invoice", invoice_id, {"fields": updates})
    return {"ok": True, "updated": len(updates) - 1}

@app.delete("/api/invoices/{invoice_id}")
def delete_invoice(invoice_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.invoices")
    with db() as con:
        existing = con.execute("SELECT * FROM invoices WHERE id=?", (invoice_id,)).fetchone()
        if not existing: raise HTTPException(404, "فاکتور پیدا نشد")
        con.execute("DELETE FROM invoices WHERE id=?", (invoice_id,))
        audit(con, user["id"], "INVOICE_DELETE", "invoice", invoice_id, {"code": existing["code"]})
    return {"ok": True}


# ========================================================================
# COMPANY CONTACTS API (تماسهای متعدد شرکت)
# ========================================================================
@app.get("/api/companies/{company_id}/contacts")
def list_company_contacts(company_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        if not con.execute("SELECT 1 FROM companies WHERE id=?", (company_id,)).fetchone():
            raise HTTPException(404, "شرکت پیدا نشد")
        rows = con.execute("SELECT * FROM company_contacts WHERE company_id=? ORDER BY created_at DESC", (company_id,)).fetchall()
        return [dict(r) for r in rows]

@app.post("/api/companies/{company_id}/contacts")
def add_company_contact(company_id: str, payload: CompanyContactCreateModel, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    with db() as con:
        if not con.execute("SELECT 1 FROM companies WHERE id=?", (company_id,)).fetchone():
            raise HTTPException(404, "شرکت پیدا نشد")
        if payload.contact_type not in ("PHONE","MOBILE","EMAIL","FAX","WEBSITE","OTHER"):
            raise HTTPException(400, "نوع تماس نامعتبر")
        if not payload.value.strip():
            raise HTTPException(400, "مقدار تماس الزامی است")
        cid = uid()
        con.execute("INSERT INTO company_contacts (id, company_id, contact_type, label, value, notes, created_by, created_at) VALUES(?,?,?,?,?,?,?,?)",
                    (cid, company_id, payload.contact_type, payload.label, payload.value.strip(), payload.notes, user["id"], now()))
        audit(con, user["id"], "COMPANY_CONTACT_ADD", "company_contact", cid, {"company_id": company_id, "type": payload.contact_type})
    return {"id": cid}

@app.delete("/api/companies/{company_id}/contacts/{contact_id}")
def delete_company_contact(company_id: str, contact_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    with db() as con:
        existing = con.execute("SELECT * FROM company_contacts WHERE id=? AND company_id=?", (contact_id, company_id)).fetchone()
        if not existing: raise HTTPException(404, "تماس پیدا نشد")
        con.execute("DELETE FROM company_contacts WHERE id=?", (contact_id,))
        audit(con, user["id"], "COMPANY_CONTACT_DELETE", "company_contact", contact_id, {"company_id": company_id})
    return {"ok": True}


# ========================================================================
# CUSTOMERS DASHBOARD STATS (۳ کارت آماری)
# ========================================================================
@app.get("/api/customers/stats")
def customers_stats(request: Request):
    """Returns: count of active contracts, in-progress proformas, unpaid invoices, plus totals."""
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        today = now()[:10]
        # Active contracts: status=ACTIVE and today is within [start_date, end_date]
        active_contracts = con.execute("""SELECT COUNT(*) FROM contracts
            WHERE status='ACTIVE' AND start_date<=? AND end_date>=?""", (today, today)).fetchone()[0]
        # In-progress proformas: status IN (DRAFT, IN_PROGRESS, SENT)
        in_progress_proformas = con.execute("""SELECT COUNT(*) FROM proformas
            WHERE status IN ('DRAFT','IN_PROGRESS','SENT')""").fetchone()[0]
        # Unpaid invoices: status IN (UNPAID, PARTIAL, OVERDUE)
        unpaid_invoices = con.execute("""SELECT COUNT(*) FROM invoices
            WHERE status IN ('UNPAID','PARTIAL','OVERDUE')""").fetchone()[0]
        # Sum of unpaid invoice balances
        unpaid_balance_row = con.execute("""SELECT COALESCE(SUM(total_amount - paid_amount), 0) FROM invoices
            WHERE status IN ('UNPAID','PARTIAL','OVERDUE')""").fetchone()
        unpaid_balance = float(unpaid_balance_row[0]) if unpaid_balance_row else 0.0
        # Total counts
        total_companies = con.execute("SELECT COUNT(*) FROM companies WHERE active=1").fetchone()[0]
        total_persons = con.execute("SELECT COUNT(*) FROM persons WHERE active=1").fetchone()[0]
        total_contracts = con.execute("SELECT COUNT(*) FROM contracts").fetchone()[0]
        total_proformas = con.execute("SELECT COUNT(*) FROM proformas").fetchone()[0]
        total_invoices = con.execute("SELECT COUNT(*) FROM invoices").fetchone()[0]
        return {
            "active_contracts": active_contracts,
            "in_progress_proformas": in_progress_proformas,
            "unpaid_invoices": unpaid_invoices,
            "unpaid_balance": unpaid_balance,
            "total_companies": total_companies,
            "total_persons": total_persons,
            "total_contracts": total_contracts,
            "total_proformas": total_proformas,
            "total_invoices": total_invoices,
        }




@app.get("/api/iso30414/report")
def iso30414_report(request: Request):
    user = current_user(request)
    require_perm(user, "reports.iso")
    with db() as con:
        # 11 areas of ISO 30414 with computed metrics
        total_users = con.execute("SELECT COUNT(*) FROM users WHERE active=1").fetchone()[0]
        total_tasks = con.execute("SELECT COUNT(*) FROM tasks").fetchone()[0]
        approved = con.execute("SELECT COUNT(*) FROM tasks WHERE status IN ('APPROVED','APPROVED_WITH_EXCEPTION')").fetchone()[0]
        returned = con.execute("SELECT COUNT(*) FROM tasks WHERE status='RETURNED'").fetchone()[0]
        overdue = con.execute("SELECT COUNT(*) FROM tasks WHERE due_date < ? AND status NOT IN ('APPROVED','APPROVED_WITH_EXCEPTION','CANCELLED')", (now(),)).fetchone()[0]
        total_time = con.execute("SELECT COALESCE(SUM(duration_seconds),0) FROM time_entries WHERE end_at IS NOT NULL").fetchone()[0]
        avg_score = con.execute("SELECT COALESCE(AVG(score),0) FROM decisions WHERE score IS NOT NULL").fetchone()[0]
        total_companies = con.execute("SELECT COUNT(*) FROM companies WHERE active=1").fetchone()[0]
        pending_reviews = con.execute("SELECT COUNT(*) FROM tasks WHERE status IN ('SUBMITTED','RECONCILING','NEEDS_REVIEW')").fetchone()[0]
        leave_pending = con.execute("SELECT COUNT(*) FROM requests WHERE status='PENDING'").fetchone()[0]
        total_submissions = con.execute("SELECT COUNT(*) FROM submissions").fetchone()[0]
        
        metrics = {
            "snapshot_date": tehran_jalali_today(),
            "area_1_composition": {
                "total_employees": total_users,
                "total_companies": total_companies,
                "employees_by_role": {r[0]: r[1] for r in con.execute("SELECT role, COUNT(*) FROM users WHERE active=1 GROUP BY role").fetchall()},
            },
            "area_2_costs": {
                "total_tracked_hours": round(total_time / 3600, 1),
                "hours_per_employee": round(total_time / 3600 / max(total_users, 1), 1),
            },
            "area_3_diversity": {
                "note": "تنوع نیروی کار — نیاز به دادههای دموگرافیک",
            },
            "area_4_leadership": {
                "managers_count": con.execute("SELECT COUNT(*) FROM users WHERE role IN ('ADMIN','CEO') AND active=1").fetchone()[0],
                "span_of_control": round(total_users / max(con.execute("SELECT COUNT(*) FROM users WHERE role IN ('ADMIN','CEO') AND active=1").fetchone()[0], 1), 1),
            },
            "area_5_culture": {
                "avg_performance_score": round(avg_score, 1),
                "approval_rate": round(approved / max(total_tasks, 1) * 100, 1),
                "return_rate": round(returned / max(total_tasks, 1) * 100, 1),
            },
            "area_6_health_safety": {
                "pending_leave_requests": leave_pending,
                "note": "سلامت و ایمنی — نیاز به دادههای غیبت",
            },
            "area_7_productivity": {
                "tasks_completed": approved,
                "tasks_overdue": overdue,
                "total_submissions": total_submissions,
                "pending_reviews": pending_reviews,
                "productivity_ratio": round(approved / max(total_tasks, 1) * 100, 1),
            },
            "area_8_training": {
                "note": "آموزش و توسعه — نیاز به ثبت دادههای آموزش",
            },
            "area_9_recruitment": {
                "note": "جذب و استخدام — خارج از دامنه فعلی",
            },
            "area_10_turnover": {
                "active_users": total_users,
                "inactive_users": con.execute("SELECT COUNT(*) FROM users WHERE active=0").fetchone()[0],
            },
            "area_11_other": {
                "total_tasks": total_tasks,
                "total_decisions": con.execute("SELECT COUNT(*) FROM decisions").fetchone()[0],
            },
        }
        return metrics

@app.post("/api/iso30414/snapshot")
def save_iso_snapshot(request: Request):
    user = current_user(request)
    require_perm(user, "reports.iso")
    # Get current metrics and save
    with db() as con:
        snap_id = uid()
        # Compute metrics inline (simplified)
        total_users = con.execute("SELECT COUNT(*) FROM users WHERE active=1").fetchone()[0]
        total_tasks = con.execute("SELECT COUNT(*) FROM tasks").fetchone()[0]
        approved = con.execute("SELECT COUNT(*) FROM tasks WHERE status IN ('APPROVED','APPROVED_WITH_EXCEPTION')").fetchone()[0]
        metrics = json.dumps({"date": tehran_jalali_today(), "employees": total_users, "tasks": total_tasks, "approved": approved}, ensure_ascii=False)
        con.execute("INSERT INTO iso30414_snapshots VALUES(?,?,?,?)", (snap_id, tehran_jalali_today(), metrics, user["id"], now()))
        audit(con, user["id"], "ISO30414_SNAPSHOT", "iso30414_snapshot", snap_id, {})
        return {"id": snap_id, "saved_at": now()}


# ========================================================================
# PHASE 6: DASHBOARD CHART DATA API
# ========================================================================

@app.get("/api/dashboard/charts")
def dashboard_charts(request: Request):
    user = current_user(request)
    with db() as con:
        # Task status distribution (for pie chart)
        status_dist = {r[0]: r[1] for r in con.execute(
            "SELECT status, COUNT(*) FROM tasks GROUP BY status").fetchall()}
        
        # Tasks per company (for bar chart)
        company_tasks = [{"name": r[0], "count": r[1]} for r in con.execute(
            "SELECT c.name, COUNT(t.id) FROM companies c LEFT JOIN tasks t ON t.company_id=c.id GROUP BY c.id ORDER BY COUNT(t.id) DESC LIMIT 10").fetchall()]
        
        # Workload per employee (for bar chart)
        workload = [{"name": r[0], "open": r[1], "done": r[2]} for r in con.execute(
            """SELECT u.name, SUM(CASE WHEN t.status NOT IN ('APPROVED','APPROVED_WITH_EXCEPTION','CANCELLED') THEN 1 ELSE 0 END),
               SUM(CASE WHEN t.status IN ('APPROVED','APPROVED_WITH_EXCEPTION') THEN 1 ELSE 0 END)
               FROM users u LEFT JOIN tasks t ON t.assignee_id=u.id WHERE u.role='EMPLOYEE' AND u.active=1 GROUP BY u.id""").fetchall()]
        
        # Time tracked per day (for line chart)
        time_per_day = [{"date": r[0], "hours": round(r[1]/3600, 1)} for r in con.execute(
            """SELECT DATE(te.start_at) AS d, SUM(te.duration_seconds) FROM time_entries te
               WHERE te.end_at IS NOT NULL AND te.start_at >= date('now','-30 days')
               GROUP BY d ORDER BY d""").fetchall()]
        
        # Performance scores trend (for line chart)
        score_trend = [{"date": r[0], "avg_score": r[1]} for r in con.execute(
            """SELECT DATE(d.created_at) AS d, AVG(d.score) FROM decisions d
               WHERE d.score IS NOT NULL GROUP BY d ORDER BY d DESC LIMIT 30""").fetchall()]
        
        # Priority distribution (for doughnut chart)
        priority_dist = {r[0]: r[1] for r in con.execute(
            "SELECT priority, COUNT(*) FROM tasks GROUP BY priority").fetchall()}
        
        return {
            "status_distribution": status_dist,
            "company_tasks": company_tasks,
            "employee_workload": workload,
            "time_per_day": time_per_day,
            "score_trend": score_trend,
            "priority_distribution": priority_dist,
        }


# ========================================================================
# PHASE 7: KANBAN ORDERING API
# ========================================================================

class KanbanOrderModel(BaseModel):
    task_id: str
    column_status: str
    sort_order: int = 0

@app.post("/api/kanban/order")
def update_kanban_order(payload: KanbanOrderModel, request: Request):
    user = current_user(request)
    with db() as con:
        con.execute("INSERT OR REPLACE INTO task_kanban_order VALUES(?,?,?)",
                     (payload.task_id, payload.column_status, payload.sort_order))
        # Also update task status to match column
        valid_statuses = ["ASSIGNED", "IN_PROGRESS", "SUBMITTED", "NEEDS_REVIEW", "APPROVED", "RETURNED"]
        if payload.column_status in valid_statuses:
            con.execute("UPDATE tasks SET status=? WHERE id=?", (payload.column_status, payload.task_id))
            audit(con, user["id"], "KANBAN_MOVE", "task", payload.task_id,
                  {"column": payload.column_status, "order": payload.sort_order})
        return {"ok": True, "kanban": True}


# ========================================================================
# TASK CHECKLIST API (5-step workflow)
# ========================================================================

@app.get("/api/tasks/{task_id}/checklist")
def get_checklist(task_id: str, request: Request):
    user = current_user(request)
    with db() as con:
        task_access(con, user, task_id)
        rows = con.execute("SELECT * FROM task_checklist WHERE task_id=? ORDER BY step_number", (task_id,)).fetchall()
        return [dict(r) for r in rows]

@app.post("/api/tasks/{task_id}/checklist")
def create_checklist(task_id: str, payload: ChecklistModel, request: Request):
    user = current_user(request)
    with db() as con:
        task_access(con, user, task_id)
        con.execute("DELETE FROM task_checklist WHERE task_id=?", (task_id,))
        for i, title in enumerate((payload.steps or [])[:5], 1):
            con.execute("INSERT INTO task_checklist VALUES(?,?,?,?,?,?,?,?)", (uid(), task_id, i, title.strip(), 0, None, None, now()))
        con.execute("INSERT INTO task_events VALUES(?,?,?,?,?,?)", (uid(), task_id, user["id"], "CHECKLIST_CREATED", json.dumps({"steps": len(payload.steps or [])}), now()))
        return {"ok": True, "steps_created": len((payload.steps or [])[:5])}

@app.post("/api/tasks/{task_id}/checklist/toggle")
def toggle_checklist_item(task_id: str, payload: ChecklistToggleModel, request: Request):
    user = current_user(request)
    with db() as con:
        task_access(con, user, task_id)
        item = con.execute("SELECT * FROM task_checklist WHERE task_id=? AND step_number=?", (task_id, payload.step_number)).fetchone()
        if not item:
            raise HTTPException(404, "مرحله پیدا نشد")
        if payload.is_done:
            con.execute("UPDATE task_checklist SET is_done=1, done_by=?, done_at=? WHERE id=?", (user["id"], now(), item["id"]))
        else:
            con.execute("UPDATE task_checklist SET is_done=0, done_by=NULL, done_at=NULL WHERE id=?", (item["id"],))
        con.execute("INSERT INTO task_events VALUES(?,?,?,?,?,?)", (uid(), task_id, user["id"], "CHECKLIST_TOGGLE", json.dumps({"step": payload.step_number, "done": payload.is_done}), now()))
        total = con.execute("SELECT COUNT(*) FROM task_checklist WHERE task_id=?", (task_id,)).fetchone()[0]
        done = con.execute("SELECT COUNT(*) FROM task_checklist WHERE task_id=? AND is_done=1", (task_id,)).fetchone()[0]
        if total > 0:
            progress = int((done / total) * 100)
            con.execute("UPDATE tasks SET progress=?, updated_at=? WHERE id=?", (progress, now(), task_id))
        return {"ok": True, "done": done, "total": total}


# ========================================================================
# TASK HISTORY / ACTIVITY LOG API
# ========================================================================

@app.get("/api/tasks/{task_id}/history")
def get_task_history(task_id: str, request: Request):
    user = current_user(request)
    with db() as con:
        task_access(con, user, task_id)
        rows = con.execute("""SELECT e.*, u.name AS actor_name FROM task_events e
                              JOIN users u ON u.id=e.actor_id WHERE task_id=? ORDER BY created_at ASC""", (task_id,)).fetchall()
        return [{**dict(r), "details": json.loads(r["details"])} for r in rows]

@app.get("/api/tasks/{task_id}/collaborators")
def get_collaborators(task_id: str, request: Request):
    user = current_user(request)
    with db() as con:
        task_access(con, user, task_id)
        rows = con.execute("""SELECT tc.*, u.name AS user_name, u.role FROM task_collaborators tc
                              JOIN users u ON u.id=tc.user_id WHERE tc.task_id=?""", (task_id,)).fetchall()
        return [dict(r) for r in rows]


# ========================================================================
# PERFORMANCE ENHANCEMENT: Create with checklist + delegate + score
# ========================================================================

PERFORMANCE_CATEGORIES_SET = {"حسابداری","مالیاتی","حسابرسی","اداری","مشاوره","سایر"}

@app.post("/api/performance-entries/v2")
def create_performance_v2(payload: PerformanceCreateModel, request: Request):
    user = current_user(request)
    if payload.category not in PERFORMANCE_CATEGORIES_SET:
        raise HTTPException(400, "نوع عملکرد معتبر نیست")
    work_date = clean_work_date(payload.work_date)
    with db() as con:
        entry_id = uid()
        con.execute("""INSERT INTO performance_entries(id,user_id,work_date,category,title,description,duration_minutes,status,review_note,reviewer_id,reviewed_at,created_at)
                     VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
                     (entry_id, user["id"], work_date, payload.category, payload.title.strip(),
                      payload.description.strip(), payload.duration_minutes, "PENDING", "", None, None, now()))
        for i, step in enumerate((payload.checklist_steps or [])[:5], 1):
            con.execute("INSERT INTO performance_checklist VALUES(?,?,?,?,?,?,?,?)", (uid(), entry_id, i, step.strip(), 0, None, None, now()))
        con.execute("INSERT INTO performance_events VALUES(?,?,?,?,?,?)", (uid(), entry_id, user["id"], "CREATED", json.dumps({"checklist_steps": len(payload.checklist_steps or [])}), now()))
        if payload.delegate_to:
            target = con.execute("SELECT id FROM users WHERE id=? AND active=1", (payload.delegate_to,)).fetchone()
            if target:
                con.execute("INSERT INTO performance_delegations VALUES(?,?,?,?,?,?)",
                            (uid(), entry_id, user["id"], payload.delegate_to, payload.delegate_scope, "DELEGATED", now()))
                notify(con, payload.delegate_to, "ارجاع عملکرد", f"بخشی از عملکرد «{payload.title}» به شما ارجاع شد")
                con.execute("INSERT INTO performance_events VALUES(?,?,?,?,?,?)", (uid(), entry_id, user["id"], "DELEGATED", json.dumps({"to": payload.delegate_to, "scope": payload.delegate_scope}), now()))
        audit(con, user["id"], "PERFORMANCE_CREATE_V2", "performance_entry", entry_id, {"category": payload.category})
        return {"id": entry_id}

@app.post("/api/performance-entries/{entry_id}/score")
def score_performance(entry_id: str, payload: PerformanceScoreModel, request: Request):
    user = current_user(request)
    require_perm(user, "performance.review")
    with db() as con:
        entry = con.execute("SELECT * FROM performance_entries WHERE id=?", (entry_id,)).fetchone()
        if not entry:
            raise HTTPException(404, "گزارش عملکرد پیدا نشد")
        con.execute("INSERT INTO performance_scores_v2 VALUES(?,?,?,?,?,?)", (uid(), entry_id, user["id"], payload.score, payload.reason, now()))
        con.execute("INSERT INTO performance_events VALUES(?,?,?,?,?,?)", (uid(), entry_id, user["id"], "SCORED", json.dumps({"score": payload.score, "reason": payload.reason}), now()))
        notify(con, entry["user_id"], "امتیاز عملکرد", f"به عملکرد شما نمره {payload.score}/۱۰۰ داده شد")
        audit(con, user["id"], "PERFORMANCE_SCORE", "performance_entry", entry_id, {"score": payload.score})
        return {"ok": True, "score": payload.score}

@app.post("/api/performance-entries/{entry_id}/delegate")
def delegate_performance(entry_id: str, payload: PerformanceDelegateModel, request: Request):
    user = current_user(request)
    with db() as con:
        entry = con.execute("SELECT * FROM performance_entries WHERE id=?", (entry_id,)).fetchone()
        if not entry:
            raise HTTPException(404, "گزارش عملکرد پیدا نشد")
        if entry["user_id"] != user["id"] and user["role"] not in ("ADMIN", "CEO"):
            raise HTTPException(403, "فقط صاحب گزارش میتواند ارجاع دهد")
        target = con.execute("SELECT id FROM users WHERE id=? AND active=1", (payload.to_user,)).fetchone()
        if not target:
            raise HTTPException(404, "کاربر هدف پیدا نشد")
        con.execute("INSERT INTO performance_delegations VALUES(?,?,?,?,?,?)",
                    (uid(), entry_id, user["id"], payload.to_user, payload.scope, "DELEGATED", now()))
        con.execute("INSERT INTO performance_events VALUES(?,?,?,?,?,?)", (uid(), entry_id, user["id"], "DELEGATED", json.dumps({"to": payload.to_user, "scope": payload.scope}), now()))
        notify(con, payload.to_user, "ارجاع عملکرد", f"بخشی از عملکرد به شما ارجاع شد")
        return {"ok": True}

@app.get("/api/performance-entries/{entry_id}/history")
def performance_history(entry_id: str, request: Request):
    user = current_user(request)
    with db() as con:
        entry = con.execute("SELECT * FROM performance_entries WHERE id=?", (entry_id,)).fetchone()
        if not entry:
            raise HTTPException(404, "گزارش پیدا نشد")
        if entry["user_id"] != user["id"] and user["role"] not in ("ADMIN", "CEO"):
            raise HTTPException(403, "دسترسی ندارید")
        events = con.execute("""SELECT e.*, u.name AS actor_name FROM performance_events e
                                JOIN users u ON u.id=e.actor_id WHERE e.entry_id=? ORDER BY e.created_at""", (entry_id,)).fetchall()
        scores = con.execute("""SELECT s.*, u.name AS manager_name FROM performance_scores_v2 s
                               JOIN users u ON u.id=s.manager_id WHERE s.entry_id=? ORDER BY s.created_at DESC""", (entry_id,)).fetchall()
        delegations = con.execute("""SELECT d.*, u.name AS to_name FROM performance_delegations d
                                    JOIN users u ON u.id=d.to_user WHERE d.entry_id=? ORDER BY d.created_at""", (entry_id,)).fetchall()
        checklist = con.execute("SELECT * FROM performance_checklist WHERE entry_id=? ORDER BY step_number", (entry_id,)).fetchall()
        return {
            "events": [{**dict(r), "details": json.loads(r["details"])} for r in events],
            "scores": [dict(r) for r in scores],
            "delegations": [dict(r) for r in delegations],
            "checklist": [dict(r) for r in checklist],
        }

@app.get("/api/performance-entries/v2")
def list_performance_v2(request: Request):
    user = current_user(request)
    with db() as con:
        if user["role"] in ("ADMIN", "CEO"):
            rows = con.execute("""SELECT p.*, u.name AS user_name FROM performance_entries p
                                 JOIN users u ON u.id=p.user_id ORDER BY p.created_at DESC LIMIT 200""").fetchall()
        else:
            rows = con.execute("""SELECT p.*, u.name AS user_name FROM performance_entries p
                                 JOIN users u ON u.id=p.user_id WHERE p.user_id=? ORDER BY p.created_at DESC""", (user["id"],)).fetchall()
        result = []
        for r in rows:
            d = dict(r)
            scores = con.execute("SELECT score FROM performance_scores_v2 WHERE entry_id=? ORDER BY created_at DESC LIMIT 1", (r["id"],)).fetchall()
            d["latest_score"] = scores[0]["score"] if scores else None
            result.append(d)
        return result



# ========================================================================
# SETTINGS API — manage task types, process types, role types, performance types
# ========================================================================

class TypeModel(BaseModel):
    name: str = Field(min_length=2, max_length=80)
    description: str = Field(default="", max_length=500)
    icon: str = "📋"
    active: bool = True

class ProcessTypeModel(BaseModel):
    name: str = Field(min_length=2, max_length=80)
    description: str = Field(default="", max_length=500)
    default_steps: int = Field(default=3, ge=1, le=5)
    active: bool = True

class RoleTypeModel(BaseModel):
    name: str = Field(min_length=2, max_length=40)
    description: str = Field(default="", max_length=500)
    permissions: str = "[]"
    active: bool = True

class PerfTypeModel(BaseModel):
    name: str = Field(min_length=2, max_length=80)
    category: str = "general"
    description: str = Field(default="", max_length=500)
    active: bool = True

class KPIModel(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    category: str = Field(default="quality", max_length=40)
    description: str = Field(default="", max_length=1000)
    target_value: float = Field(ge=0, le=100000)
    target_operator: str = Field(default=">=", max_length=4)
    unit: str = Field(default="%", max_length=20)
    weight: int = Field(default=10, ge=1, le=100)
    frequency: str = Field(default="monthly", max_length=20)
    owner_role: str = Field(default="EMPLOYEE", max_length=20)
    formula: str = Field(default="", max_length=500)
    active: bool = True

@app.get("/api/settings")
def get_all_settings(request: Request):
    user = current_user(request)
    require_perm(user, "settings.view")
    with db() as con:
        return {
            "task_types": [dict(r) for r in con.execute("SELECT * FROM task_types ORDER BY name").fetchall()],
            "process_types": [dict(r) for r in con.execute("SELECT * FROM process_types ORDER BY name").fetchall()],
            "role_types": [dict(r) for r in con.execute("SELECT * FROM role_types ORDER BY name").fetchall()],
            "performance_types": [dict(r) for r in con.execute("SELECT * FROM performance_types ORDER BY name").fetchall()],
            "kpis": [dict(r) for r in con.execute("SELECT * FROM kpis ORDER BY weight DESC, name").fetchall()],
        }

@app.get("/api/settings/task-types")
def list_tt(request: Request):
    current_user(request)
    with db() as con: return [dict(r) for r in con.execute("SELECT * FROM task_types ORDER BY name").fetchall()]

@app.post("/api/settings/task-types")
def create_tt(payload: TypeModel, request: Request):
    user = current_user(request); require_perm(user, "settings.types")
    with db() as con:
        tid = uid()
        try: con.execute("INSERT INTO task_types VALUES(?,?,?,?,?,?)", (tid, payload.name, payload.description, payload.icon, 1 if payload.active else 0, now()))
        except sqlite3.IntegrityError: raise HTTPException(409, "نام تکراری است")
        audit(con, user["id"], "TT_CREATE", "setting", tid, {"name": payload.name})
        return {"id": tid, "ok": True}

@app.patch("/api/settings/task-types/{tid}")
def update_tt(tid: str, payload: TypeModel, request: Request):
    user = current_user(request); require_perm(user, "settings.types")
    with db() as con:
        if not con.execute("SELECT 1 FROM task_types WHERE id=?", (tid,)).fetchone(): raise HTTPException(404, "نوع پیدا نشد")
        con.execute("UPDATE task_types SET name=?, description=?, icon=?, active=? WHERE id=?", (payload.name, payload.description, payload.icon, 1 if payload.active else 0, tid))
        return {"ok": True}

@app.delete("/api/settings/task-types/{tid}")
def delete_tt(tid: str, request: Request):
    user = current_user(request); require_perm(user, "settings.types")
    with db() as con: con.execute("DELETE FROM task_types WHERE id=?", (tid,)); return {"ok": True}

@app.get("/api/settings/process-types")
def list_pt(request: Request):
    current_user(request)
    with db() as con: return [dict(r) for r in con.execute("SELECT * FROM process_types ORDER BY name").fetchall()]

@app.post("/api/settings/process-types")
def create_pt(payload: ProcessTypeModel, request: Request):
    user = current_user(request); require_perm(user, "settings.types")
    with db() as con:
        tid = uid()
        try: con.execute("INSERT INTO process_types VALUES(?,?,?,?,?,?)", (tid, payload.name, payload.description, payload.default_steps, 1 if payload.active else 0, now()))
        except sqlite3.IntegrityError: raise HTTPException(409, "نام تکراری است")
        return {"id": tid, "ok": True}

@app.patch("/api/settings/process-types/{tid}")
def update_pt(tid: str, payload: ProcessTypeModel, request: Request):
    user = current_user(request); require_perm(user, "settings.types")
    with db() as con:
        if not con.execute("SELECT 1 FROM process_types WHERE id=?", (tid,)).fetchone(): raise HTTPException(404, "نوع پیدا نشد")
        con.execute("UPDATE process_types SET name=?, description=?, default_steps=?, active=? WHERE id=?", (payload.name, payload.description, payload.default_steps, 1 if payload.active else 0, tid))
        return {"ok": True}

@app.delete("/api/settings/process-types/{tid}")
def delete_pt(tid: str, request: Request):
    user = current_user(request); require_perm(user, "settings.types")
    with db() as con: con.execute("DELETE FROM process_types WHERE id=?", (tid,)); return {"ok": True}

@app.get("/api/settings/role-types")
def list_rt(request: Request):
    current_user(request)
    with db() as con: return [dict(r) for r in con.execute("SELECT * FROM role_types ORDER BY name").fetchall()]

@app.post("/api/settings/role-types")
def create_rt(payload: RoleTypeModel, request: Request):
    user = current_user(request); require_perm(user, "settings.types")
    with db() as con:
        tid = uid()
        try: con.execute("INSERT INTO role_types VALUES(?,?,?,?,?,?)", (tid, payload.name, payload.description, payload.permissions, 1 if payload.active else 0, now()))
        except sqlite3.IntegrityError: raise HTTPException(409, "نام تکراری است")
        return {"id": tid, "ok": True}

@app.patch("/api/settings/role-types/{tid}")
def update_rt(tid: str, payload: RoleTypeModel, request: Request):
    user = current_user(request); require_perm(user, "settings.types")
    with db() as con:
        if not con.execute("SELECT 1 FROM role_types WHERE id=?", (tid,)).fetchone(): raise HTTPException(404, "نوع پیدا نشد")
        con.execute("UPDATE role_types SET name=?, description=?, permissions=?, active=? WHERE id=?", (payload.name, payload.description, payload.permissions, 1 if payload.active else 0, tid))
        return {"ok": True}

@app.delete("/api/settings/role-types/{tid}")
def delete_rt(tid: str, request: Request):
    user = current_user(request); require_perm(user, "settings.types")
    with db() as con: con.execute("DELETE FROM role_types WHERE id=?", (tid,)); return {"ok": True}

@app.get("/api/settings/performance-types")
def list_pft(request: Request):
    current_user(request)
    with db() as con: return [dict(r) for r in con.execute("SELECT * FROM performance_types ORDER BY name").fetchall()]

@app.post("/api/settings/performance-types")
def create_pft(payload: PerfTypeModel, request: Request):
    user = current_user(request); require_perm(user, "settings.types")
    with db() as con:
        tid = uid()
        try: con.execute("INSERT INTO performance_types VALUES(?,?,?,?,?,?)", (tid, payload.name, payload.category, payload.description, 1 if payload.active else 0, now()))
        except sqlite3.IntegrityError: raise HTTPException(409, "نام تکراری است")
        return {"id": tid, "ok": True}

@app.patch("/api/settings/performance-types/{tid}")
def update_pft(tid: str, payload: PerfTypeModel, request: Request):
    user = current_user(request); require_perm(user, "settings.types")
    with db() as con:
        if not con.execute("SELECT 1 FROM performance_types WHERE id=?", (tid,)).fetchone(): raise HTTPException(404, "نوع پیدا نشد")
        con.execute("UPDATE performance_types SET name=?, category=?, description=?, active=? WHERE id=?", (payload.name, payload.category, payload.description, 1 if payload.active else 0, tid))
        return {"ok": True}

@app.delete("/api/settings/performance-types/{tid}")
def delete_pft(tid: str, request: Request):
    user = current_user(request); require_perm(user, "settings.types")
    with db() as con: con.execute("DELETE FROM performance_types WHERE id=?", (tid,)); return {"ok": True}

# ---- KPI CRUD ----
@app.get("/api/settings/kpis")
def list_kpis(request: Request):
    current_user(request)
    with db() as con: return [dict(r) for r in con.execute("SELECT * FROM kpis ORDER BY weight DESC, name").fetchall()]

@app.post("/api/settings/kpis")
def create_kpi(payload: KPIModel, request: Request):
    user = current_user(request); require_perm(user, "settings.kpi")
    with db() as con:
        tid = uid()
        ts = now()
        con.execute(
            "INSERT INTO kpis(id,name,category,description,target_value,target_operator,unit,weight,frequency,owner_role,formula,active,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (tid, payload.name.strip(), payload.category, payload.description.strip(),
             payload.target_value, payload.target_operator, payload.unit,
             payload.weight, payload.frequency, payload.owner_role,
             payload.formula.strip(), 1 if payload.active else 0, ts, ts)
        )
        audit(con, user["id"], "KPI_CREATE", "kpi", tid, {"name": payload.name, "category": payload.category})
        return {"id": tid, "ok": True}

@app.patch("/api/settings/kpis/{tid}")
def update_kpi(tid: str, payload: KPIModel, request: Request):
    user = current_user(request); require_perm(user, "settings.kpi")
    with db() as con:
        if not con.execute("SELECT 1 FROM kpis WHERE id=?", (tid,)).fetchone():
            raise HTTPException(404, "شاخص کلیدی پیدا نشد")
        con.execute(
            "UPDATE kpis SET name=?, category=?, description=?, target_value=?, target_operator=?, unit=?, weight=?, frequency=?, owner_role=?, formula=?, active=?, updated_at=? WHERE id=?",
            (payload.name.strip(), payload.category, payload.description.strip(),
             payload.target_value, payload.target_operator, payload.unit,
             payload.weight, payload.frequency, payload.owner_role,
             payload.formula.strip(), 1 if payload.active else 0, now(), tid)
        )
        audit(con, user["id"], "KPI_UPDATE", "kpi", tid, {"name": payload.name})
        return {"ok": True}

@app.delete("/api/settings/kpis/{tid}")
def delete_kpi(tid: str, request: Request):
    user = current_user(request); require_perm(user, "settings.kpi")
    with db() as con:
        if not con.execute("SELECT 1 FROM kpis WHERE id=?", (tid,)).fetchone():
            raise HTTPException(404, "شاخص کلیدی پیدا نشد")
        con.execute("DELETE FROM kpis WHERE id=?", (tid,))
        audit(con, user["id"], "KPI_DELETE", "kpi", tid, {})
        return {"ok": True}

@app.get("/api/settings/kpis/{tid}/evaluate")
def evaluate_kpi(tid: str, request: Request):
    """Evaluate a single KPI for a given user/month — returns current value and status."""
    user = current_user(request); require_role(user, "ADMIN", "CEO")
    target_user = request.query_params.get("user_id", "")
    period = request.query_params.get("period", "")
    with db() as con:
        kpi = con.execute("SELECT * FROM kpis WHERE id=?", (tid,)).fetchone()
        if not kpi: raise HTTPException(404, "شاخص پیدا نشد")
        # Simple live evaluation based on category (placeholder formula parser)
        current_value = 0.0
        status = "PENDING"
        if kpi["category"] == "quality" and target_user:
            row = con.execute(
                "SELECT AVG(score) as v FROM performance_scores_v2 WHERE user_id=?", (target_user,)
            ).fetchone()
            current_value = float(row["v"]) if row and row["v"] is not None else 0.0
        elif kpi["category"] == "volume" and target_user:
            row = con.execute(
                "SELECT COALESCE(SUM(duration_minutes),0) as v FROM performance_entries WHERE user_id=?", (target_user,)
            ).fetchone()
            current_value = float(row["v"]) if row else 0.0
        elif kpi["category"] == "ontime" and target_user:
            # Use task_events for completion tracking, then compare completion time to due_date
            row = con.execute(
                """SELECT CAST(SUM(CASE WHEN te.created_at <= t.due_date THEN 1 ELSE 0 END) AS REAL) /
                   NULLIF(COUNT(*),0) * 100 as v
                   FROM task_events te
                   JOIN tasks t ON t.id = te.task_id
                   JOIN task_assignments ta ON ta.task_id = t.id
                   WHERE ta.to_user=? AND te.action='COMPLETED' AND t.due_date IS NOT NULL""",
                (target_user,)
            ).fetchone()
            current_value = float(row["v"]) if row and row["v"] is not None else 0.0
        elif kpi["category"] == "collaboration" and target_user:
            row = con.execute(
                "SELECT COUNT(*) as v FROM task_collaborators WHERE user_id=?", (target_user,)
            ).fetchone()
            current_value = float(row["v"]) if row else 0.0
        op = kpi["target_operator"]
        target = float(kpi["target_value"])
        if op == ">=": status = "PASS" if current_value >= target else "FAIL"
        elif op == "<=": status = "PASS" if current_value <= target else "FAIL"
        elif op == ">": status = "PASS" if current_value > target else "FAIL"
        elif op == "<": status = "PASS" if current_value < target else "FAIL"
        elif op == "==": status = "PASS" if abs(current_value - target) < 0.01 else "FAIL"
        return {
            "kpi_id": tid, "name": kpi["name"], "category": kpi["category"],
            "target_value": target, "operator": op, "unit": kpi["unit"],
            "current_value": current_value, "status": status, "period": period
        }


# ========================================================================
# KPI-BASED PERFORMANCE REPORT  (replaces fixed simple/weighted from /api/performance)
# ========================================================================
def _kpi_current_value(con, kpi: dict, user_id: str, period: str | None) -> float:
    """Compute current raw value of a single KPI for a user. Period is YYYY/MM (jalali) or empty."""
    cat = kpi["category"]
    if cat == "quality":
        row = con.execute(
            "SELECT AVG(s.score) as v FROM performance_scores_v2 s JOIN performance_entries e ON e.id=s.entry_id WHERE e.user_id=?",
            (user_id,)
        ).fetchone()
        return float(row["v"]) if row and row["v"] is not None else 0.0
    if cat == "volume":
        row = con.execute(
            "SELECT COALESCE(SUM(duration_minutes),0) as v FROM performance_entries WHERE user_id=?",
            (user_id,)
        ).fetchone()
        return float(row["v"]) if row else 0.0
    if cat == "ontime":
        row = con.execute(
            """SELECT CAST(SUM(CASE WHEN te.created_at <= t.due_date THEN 1 ELSE 0 END) AS REAL) /
                   NULLIF(COUNT(*),0) * 100 as v
               FROM task_events te
               JOIN tasks t ON t.id = te.task_id
               JOIN task_assignments ta ON ta.task_id = t.id
               WHERE ta.to_user=? AND te.action='COMPLETED' AND t.due_date IS NOT NULL""",
            (user_id,)
        ).fetchone()
        return float(row["v"]) if row and row["v"] is not None else 0.0
    if cat == "collaboration":
        row = con.execute(
            "SELECT COUNT(*) as v FROM task_collaborators WHERE user_id=?", (user_id,)
        ).fetchone()
        return float(row["v"]) if row else 0.0
    if cat == "satisfaction":
        # Use manager decision approval rate as proxy
        row = con.execute(
            """SELECT CAST(SUM(CASE WHEN d.decision='APPROVED' THEN 1 ELSE 0 END) AS REAL) /
                   NULLIF(COUNT(*),0) * 5 as v
               FROM decisions d JOIN tasks t ON t.id=d.task_id WHERE t.assignee_id=?""",
            (user_id,)
        ).fetchone()
        return float(row["v"]) if row and row["v"] is not None else 0.0
    # custom: try to read formula-based aggregate — fallback to 0
    return 0.0


def _kpi_ratio(current: float, target: float, op: str) -> float:
    """Return 0-1 ratio of achievement vs target."""
    if target <= 0:
        return 1.0 if current > 0 else 0.0
    if op in (">=", ">"):
        return min(current / target, 1.0)
    if op in ("<=", "<"):
        return min(target / max(current, 0.001), 1.0)
    if op == "==":
        return 1.0 if abs(current - target) < 0.01 else max(0.0, 1.0 - abs(current - target) / target)
    return min(current / target, 1.0)


@app.get("/api/performance/kpi-report")
def kpi_performance_report(request: Request):
    """For every employee: compute each KPI current_value + achievement ratio + weighted_score.
    Returns total_score (0-100) per employee using active KPI weights."""
    user = current_user(request); require_role(user, "ADMIN", "CEO")
    period = request.query_params.get("period", "")
    target_role = request.query_params.get("role", "EMPLOYEE")
    with db() as con:
        kpis = [dict(r) for r in con.execute("SELECT * FROM kpis WHERE active=1 ORDER BY weight DESC, name").fetchall()]
        people = [dict(r) for r in con.execute(
            "SELECT id, name, username FROM users WHERE role=? AND active=1 ORDER BY name", (target_role,)
        ).fetchall()]
        report = []
        for p in people:
            kpi_rows = []
            weighted_sum = 0.0
            weight_total = 0
            for k in kpis:
                current = _kpi_current_value(con, k, p["id"], period)
                target = float(k["target_value"])
                op = k["target_operator"]
                ratio = _kpi_ratio(current, target, op)
                weighted_score = round(ratio * 100, 2)
                contribution = (ratio * 100 * k["weight"]) / 100.0
                weighted_sum += contribution
                weight_total += k["weight"]
                # status
                if op == ">=": status = "PASS" if current >= target else "FAIL"
                elif op == "<=": status = "PASS" if current <= target else "FAIL"
                elif op == ">": status = "PASS" if current > target else "FAIL"
                elif op == "<": status = "PASS" if current < target else "FAIL"
                elif op == "==": status = "PASS" if abs(current - target) < 0.01 else "FAIL"
                else: status = "PENDING"
                kpi_rows.append({
                    "kpi_id": k["id"], "name": k["name"], "category": k["category"],
                    "target_value": target, "operator": op, "unit": k["unit"],
                    "current_value": round(current, 2), "ratio": round(ratio, 4),
                    "weighted_score": weighted_score, "weight": k["weight"],
                    "contribution": round(contribution, 2),
                    "status": status,
                })
            total = round(weighted_sum, 2) if weight_total else 0.0
            # Normalize to 100 if total weight != 100
            if weight_total and weight_total != 100:
                total = round(total * 100 / weight_total, 2)
            passed = sum(1 for k in kpi_rows if k["status"] == "PASS")
            report.append({
                "user_id": p["id"], "name": p["name"], "username": p["username"],
                "kpis": kpi_rows,
                "total_score": total,
                "passed": passed,
                "total_kpis": len(kpi_rows),
                "weight_total": weight_total,
                "grade": "عالی" if total >= 90 else "خوب" if total >= 75 else "متوسط" if total >= 60 else "ضعیف",
            })
        # Sort by total_score desc
        report.sort(key=lambda x: -x["total_score"])
        # Aggregate KPI summary across all employees
        summary = []
        for k in kpis:
            vals = [r["kpis"][i]["current_value"] for r in report for i, kk in enumerate(r["kpis"]) if kk["kpi_id"] == k["id"]]
            summary.append({
                "kpi_id": k["id"], "name": k["name"], "category": k["category"],
                "target_value": float(k["target_value"]), "unit": k["unit"], "weight": k["weight"],
                "avg_value": round(sum(vals) / len(vals), 2) if vals else 0.0,
                "min_value": round(min(vals), 2) if vals else 0.0,
                "max_value": round(max(vals), 2) if vals else 0.0,
            })
        return {
            "period": period,
            "generated_at": now(),
            "kpis": kpis,
            "employees": report,
            "summary": summary,
            "total_weight": sum(k["weight"] for k in kpis),
        }


@app.get("/api/performance/kpi-report/{user_id}")
def kpi_performance_for_user(user_id: str, request: Request):
    """KPI breakdown for a single user — used in user detail panel."""
    user = current_user(request)
    if user["id"] != user_id:
        require_role(user, "ADMIN", "CEO")
    period = request.query_params.get("period", "")
    with db() as con:
        kpis = [dict(r) for r in con.execute("SELECT * FROM kpis WHERE active=1 ORDER BY weight DESC, name").fetchall()]
        person = con.execute("SELECT id, name, username FROM users WHERE id=?", (user_id,)).fetchone()
        if not person: raise HTTPException(404, "کاربر پیدا نشد")
        kpi_rows = []
        weighted_sum = 0.0
        weight_total = 0
        for k in kpis:
            current = _kpi_current_value(con, k, user_id, period)
            target = float(k["target_value"])
            op = k["target_operator"]
            ratio = _kpi_ratio(current, target, op)
            contribution = (ratio * 100 * k["weight"]) / 100.0
            weighted_sum += contribution
            weight_total += k["weight"]
            if op == ">=": status = "PASS" if current >= target else "FAIL"
            elif op == "<=": status = "PASS" if current <= target else "FAIL"
            elif op == ">": status = "PASS" if current > target else "FAIL"
            elif op == "<": status = "PASS" if current < target else "FAIL"
            elif op == "==": status = "PASS" if abs(current - target) < 0.01 else "FAIL"
            else: status = "PENDING"
            kpi_rows.append({
                "kpi_id": k["id"], "name": k["name"], "category": k["category"],
                "target_value": target, "operator": op, "unit": k["unit"],
                "current_value": round(current, 2), "ratio": round(ratio, 4),
                "weighted_score": round(ratio * 100, 2), "weight": k["weight"],
                "contribution": round(contribution, 2),
                "status": status, "description": k.get("description", ""),
            })
        total = round(weighted_sum, 2) if weight_total else 0.0
        if weight_total and weight_total != 100:
            total = round(total * 100 / weight_total, 2)
        passed = sum(1 for k in kpi_rows if k["status"] == "PASS")
        return {
            "user_id": user_id,
            "name": person["name"],
            "username": person["username"],
            "kpis": kpi_rows,
            "total_score": total,
            "passed": passed,
            "total_kpis": len(kpi_rows),
            "weight_total": weight_total,
            "grade": "عالی" if total >= 90 else "خوب" if total >= 75 else "متوسط" if total >= 60 else "ضعیف",
            "period": period,
        }


# ========================================================================
# PERFORMANCE ENHANCEMENT: Add missing task-like features
# ========================================================================

class PerfV3Model(BaseModel):
    work_date: str = Field(min_length=8, max_length=12)
    category: str = Field(min_length=2, max_length=32)
    title: str = Field(min_length=2, max_length=120)
    description: str = Field(default="", max_length=2000)
    duration_minutes: int = Field(ge=1, le=1440)
    company_id: str = ""
    priority: str = "NORMAL"
    weight: int = Field(default=1, ge=1, le=3)
    due_date: str = ""
    collaborator_ids: list[str] = []
    checklist_steps: list[str] = []
    delegate_to: str = ""
    delegate_scope: str = ""

class PerfChecklistToggleModel(BaseModel):
    step_number: int
    is_done: bool

class PerfCommentModel(BaseModel):
    body: str = Field(min_length=1, max_length=4000)
    visibility: str = "EMPLOYEE_VISIBLE"

@app.post("/api/performance-entries/v3")
def create_perf_v3(payload: PerfV3Model, request: Request):
    user = current_user(request)
    work_date = clean_work_date(payload.work_date)
    with db() as con:
        entry_id = uid()
        con.execute("""INSERT INTO performance_entries(id,user_id,work_date,category,title,description,duration_minutes,status,review_note,reviewer_id,reviewed_at,created_at)
                     VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
                     (entry_id, user["id"], work_date, payload.category, payload.title.strip(),
                      payload.description.strip(), payload.duration_minutes, "PENDING", "", None, None, now()))
        # Checklist
        for i, step in enumerate((payload.checklist_steps or [])[:5], 1):
            con.execute("INSERT INTO performance_checklist VALUES(?,?,?,?,?,?,?,?)", (uid(), entry_id, i, step.strip(), 0, None, None, now()))
        # Collaborators (reuse task_collaborators structure with a perf_ prefix table)
        for cid in set(payload.collaborator_ids or []):
            if cid != user["id"]:
                try:
                    con.execute("INSERT INTO performance_delegations VALUES(?,?,?,?,?,?)",
                                (uid(), entry_id, user["id"], cid, "COLLABORATOR", "DELEGATED", now()))
                    notify(con, cid, "همکار در عملکرد", f"شما به عملکرد «{payload.title}» اضافه شدید")
                except: pass
        # Delegate
        if payload.delegate_to:
            target = con.execute("SELECT id FROM users WHERE id=? AND active=1", (payload.delegate_to,)).fetchone()
            if target:
                con.execute("INSERT INTO performance_delegations VALUES(?,?,?,?,?,?)",
                            (uid(), entry_id, user["id"], payload.delegate_to, payload.delegate_scope or "", "DELEGATED", now()))
                notify(con, payload.delegate_to, "ارجاع عملکرد", f"بخشی از عملکرد «{payload.title}» به شما ارجاع شد")
        con.execute("INSERT INTO performance_events VALUES(?,?,?,?,?,?)", (uid(), entry_id, user["id"], "CREATED", json.dumps({"checklist": len(payload.checklist_steps or []), "collaborators": len(payload.collaborator_ids or [])}), now()))
        audit(con, user["id"], "PERF_CREATE_V3", "performance_entry", entry_id, {"title": payload.title})
        return {"id": entry_id}

@app.post("/api/performance-entries/{entry_id}/checklist/toggle")
def toggle_perf_checklist(entry_id: str, payload: PerfChecklistToggleModel, request: Request):
    user = current_user(request)
    with db() as con:
        item = con.execute("SELECT * FROM performance_checklist WHERE entry_id=? AND step_number=?", (entry_id, payload.step_number)).fetchone()
        if not item:
            raise HTTPException(404, "مرحله پیدا نشد")
        if payload.is_done:
            con.execute("UPDATE performance_checklist SET is_done=1, done_by=?, done_at=? WHERE id=?", (user["id"], now(), item["id"]))
        else:
            con.execute("UPDATE performance_checklist SET is_done=0, done_by=NULL, done_at=NULL WHERE id=?", (item["id"],))
        con.execute("INSERT INTO performance_events VALUES(?,?,?,?,?,?)", (uid(), entry_id, user["id"], "CHECKLIST_TOGGLE", json.dumps({"step": payload.step_number, "done": payload.is_done}), now()))
        total = con.execute("SELECT COUNT(*) FROM performance_checklist WHERE entry_id=?", (entry_id,)).fetchone()[0]
        done = con.execute("SELECT COUNT(*) FROM performance_checklist WHERE entry_id=? AND is_done=1", (entry_id,)).fetchone()[0]
        return {"ok": True, "done": done, "total": total, "progress": int((done/max(total,1))*100)}

@app.post("/api/performance-entries/{entry_id}/comments")
def perf_comment(entry_id: str, payload: PerfCommentModel, request: Request):
    user = current_user(request)
    with db() as con:
        entry = con.execute("SELECT * FROM performance_entries WHERE id=?", (entry_id,)).fetchone()
        if not entry:
            raise HTTPException(404, "عملکرد پیدا نشد")
        cid = uid()
        con.execute("INSERT INTO perf_comments VALUES(?,?,?,?,?,?)", (cid, entry_id, user["id"], payload.visibility, payload.body, now()))
        con.execute("INSERT INTO performance_events VALUES(?,?,?,?,?,?)", (uid(), entry_id, user["id"], "COMMENT", json.dumps({"visibility": payload.visibility}), now()))
        return {"id": cid}

@app.get("/api/performance-entries/{entry_id}/comments")
def list_perf_comments(entry_id: str, request: Request):
    user = current_user(request)
    with db() as con:
        entry = con.execute("SELECT * FROM performance_entries WHERE id=?", (entry_id,)).fetchone()
        if not entry:
            raise HTTPException(404, "عملکرد پیدا نشد")
        if user["role"] not in ("ADMIN", "CEO"):
            rows = con.execute("""SELECT c.*, u.name AS author_name FROM perf_comments c
                                  JOIN users u ON u.id=c.author_id WHERE c.entry_id=? AND c.visibility='EMPLOYEE_VISIBLE'""", (entry_id,)).fetchall()
        else:
            rows = con.execute("""SELECT c.*, u.name AS author_name FROM perf_comments c
                                  JOIN users u ON u.id=c.author_id WHERE c.entry_id=?""", (entry_id,)).fetchall()
        return [dict(r) for r in rows]

@app.post("/api/performance-entries/{entry_id}/submit-file")
async def perf_submit_file(entry_id: str, request: Request):
    """Employee uploads Excel file. System validates against template (sample format).
    If template doesn't match, returns error message. Otherwise saves submission.
    Manager will later upload reference file and system reconciles."""
    user = current_user(request)
    form = await request.form()
    file = form.get("file")
    note = form.get("note", "")
    claimed_start = form.get("claimed_start", "")
    claimed_end = form.get("claimed_end", "")
    if not file:
        raise HTTPException(400, "فایل ارسال نشده")
    content = await file.read(MAX_UPLOAD + 1)
    rows, sheet_name = read_excel(file, content)
    file_hash = hashlib.sha256(content).hexdigest()

    # Step 1: Validate against template (system sample format)
    template_check = validate_template(rows)
    if not template_check["valid"]:
        # File doesn't match template — return error with details so employee can fix
        return {
            "accepted": False,
            "template_valid": False,
            "errors": template_check["errors"],
            "warnings": template_check["warnings"],
            "row_count": len(rows),
            "message": "فایل با قالب سیستم مطابقت ندارد. لطفاً خطاهای زیر را اصلاح کنید.",
        }

    stored_name = f"{file_hash}.xlsx"
    (FILES / stored_name).write_bytes(content)
    with db() as con:
        entry = con.execute("SELECT * FROM performance_entries WHERE id=?", (entry_id,)).fetchone()
        if not entry:
            raise HTTPException(404, "عملکرد پیدا نشد")
        # Check existing reference for this entry — if one exists, reconcile now
        ref = con.execute("SELECT * FROM perf_references WHERE entry_id=? ORDER BY version DESC LIMIT 1", (entry_id,)).fetchone()
        ref_rows = None
        ref_id = None
        if ref:
            ref_id = ref["id"]
            ref_content = (FILES / ref["stored_name"]).read_bytes()
            ref_rows, _ = read_excel(UploadFile(filename=ref["original_name"], file=None), ref_content)

        # Step 2: Reconcile (with reference if available)
        report, diffs = reconcile_detailed(rows, ref_rows, claimed_start or None, claimed_end or None)
        report["template_valid"] = True
        report["template_errors"] = []
        report["template_warnings"] = template_check.get("warnings", [])
        report["reference_id"] = ref_id
        report["reference_attached"] = ref_rows is not None

        # Step 3: Save submission
        sub_id = uid()
        version = con.execute("SELECT COUNT(*) FROM perf_submissions WHERE entry_id=?", (entry_id,)).fetchone()[0] + 1
        ts = now()
        # INSERT with all new columns
        con.execute("""INSERT INTO perf_submissions
            (id, entry_id, user_id, version, original_name, stored_name, sha256,
             note, claimed_start, claimed_end,
             row_count, voucher_count, duplicate_rows, out_of_range, report_json, created_at,
             reference_id, template_valid, template_errors, status, manager_id, decision_at, decision_note)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (sub_id, entry_id, user["id"], version, file.filename, stored_name, file_hash,
             note, claimed_start, claimed_end,
             report["row_count"], report["voucher_count"], report["duplicate_rows"],
             report["out_of_range"], json.dumps(report, ensure_ascii=False), ts,
             ref_id, 1, "[]", "PENDING", None, None, ""))

        # Step 4: Save row-level diffs
        for d in diffs:
            con.execute("""INSERT INTO perf_submission_diffs
                (id, submission_id, source_row, voucher, line, date, account, debit, credit, description,
                 issue_type, issue_detail, ref_debit, ref_credit, ref_date, ref_account, ref_description, created_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (uid(), sub_id, d["source_row"], d["voucher"], d["line"], d["date"],
                 d["account"], d["debit"], d["credit"], d["description"],
                 d["issue_type"], d["issue_detail"], d.get("ref_debit"), d.get("ref_credit"),
                 d.get("ref_date"), d.get("ref_account"), d.get("ref_description"), ts))

        # Notify managers about new submission
        con.execute("INSERT INTO performance_events VALUES(?,?,?,?,?,?)",
            (uid(), entry_id, user["id"], "FILE_SUBMITTED",
             json.dumps({"version": version, "rows": report["row_count"], "diffs": len(diffs)}), ts))
        managers = con.execute("SELECT id FROM users WHERE role IN ('ADMIN','CEO') AND active=1").fetchall()
        for m in managers:
            notify(con, m["id"], "ثبت عملکرد جدید برای بررسی",
                   f"عملکرد «{entry['title']}» — نسخه {version} ({len(diffs)} اختلاف)")
        audit(con, user["id"], "PERF_FILE_SUBMIT", "performance_entry", entry_id,
              {"rows": report["row_count"], "diffs": len(diffs)})
        return {
            "id": sub_id, "version": version, "accepted": True,
            "template_valid": True, "report": report, "diff_count": len(diffs),
            "diffs_sample": diffs[:20],  # first 20 diffs for preview
        }


# ============ Manager uploads reference Excel for performance entry ============

@app.post("/api/performance-entries/{entry_id}/reference")
async def perf_upload_reference(entry_id: str, request: Request):
    """Manager uploads the reference Excel file for a performance entry.
    System then re-reconciles all existing submissions against this reference."""
    user = current_user(request)
    require_role(user, "ADMIN", "CEO")
    form = await request.form()
    file = form.get("file")
    fiscal_period = form.get("fiscal_period", "")
    coverage_start = form.get("coverage_start", "")
    coverage_end = form.get("coverage_end", "")
    if not file:
        raise HTTPException(400, "فایل مرجع ارسال نشده")
    content = await file.read(MAX_UPLOAD + 1)
    rows, _ = read_excel(file, content)
    digest = hashlib.sha256(content).hexdigest()
    stored = f"{uuid.uuid4().hex}.xlsx"
    (FILES / stored).write_bytes(content)
    with db() as con:
        entry = con.execute("SELECT * FROM performance_entries WHERE id=?", (entry_id,)).fetchone()
        if not entry:
            raise HTTPException(404, "عملکرد پیدا نشد")
        # Determine version
        version = con.execute("SELECT COALESCE(MAX(version), 0) + 1 FROM perf_references WHERE entry_id=?", (entry_id,)).fetchone()[0]
        ref_id = uid()
        ts = now()
        # Try to find company_id from entry's submissions (since entry itself may not have company)
        company_id = entry["user_id"]  # fallback
        con.execute("""INSERT INTO perf_references
            (id, entry_id, company_id, fiscal_period, version, original_name, stored_name, sha256,
             row_count, coverage_start, coverage_end, uploaded_by, created_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (ref_id, entry_id, company_id, fiscal_period, version, file.filename, stored, digest,
             len(rows), coverage_start or None, coverage_end or None, user["id"], ts))

        # Re-reconcile all existing submissions against this new reference
        existing_subs = con.execute("SELECT * FROM perf_submissions WHERE entry_id=? ORDER BY version", (entry_id,)).fetchall()
        re_reconciled_count = 0
        for sub in existing_subs:
            sub_content = (FILES / sub["stored_name"]).read_bytes()
            sub_rows, _ = read_excel(UploadFile(filename=sub["original_name"], file=None), sub_content)
            report, diffs = reconcile_detailed(sub_rows, rows, sub["claimed_start"], sub["claimed_end"])
            report["template_valid"] = bool(sub["template_valid"])
            report["template_errors"] = json.loads(sub["template_errors"] or "[]")
            report["reference_id"] = ref_id
            report["reference_attached"] = True
            # Update submission
            con.execute("""UPDATE perf_submissions SET
                report_json=?, reference_id=?, row_count=?, voucher_count=?,
                duplicate_rows=?, out_of_range=? WHERE id=?""",
                (json.dumps(report, ensure_ascii=False), ref_id, report["row_count"],
                 report["voucher_count"], report["duplicate_rows"], report["out_of_range"], sub["id"]))
            # Delete old diffs for this submission
            con.execute("DELETE FROM perf_submission_diffs WHERE submission_id=?", (sub["id"],))
            for d in diffs:
                con.execute("""INSERT INTO perf_submission_diffs
                    (id, submission_id, source_row, voucher, line, date, account, debit, credit, description,
                     issue_type, issue_detail, ref_debit, ref_credit, ref_date, ref_account, ref_description, created_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (uid(), sub["id"], d["source_row"], d["voucher"], d["line"], d["date"],
                     d["account"], d["debit"], d["credit"], d["description"],
                     d["issue_type"], d["issue_detail"], d.get("ref_debit"), d.get("ref_credit"),
                     d.get("ref_date"), d.get("ref_account"), d.get("ref_description"), ts))
            re_reconciled_count += 1

        con.execute("INSERT INTO performance_events VALUES(?,?,?,?,?,?)",
            (uid(), entry_id, user["id"], "REFERENCE_UPLOADED",
             json.dumps({"version": version, "rows": len(rows), "re_reconciled": re_reconciled_count}), ts))
        audit(con, user["id"], "PERF_REF_UPLOAD", "perf_reference", ref_id,
              {"entry_id": entry_id, "rows": len(rows), "re_reconciled": re_reconciled_count})
        return {
            "id": ref_id, "version": version, "row_count": len(rows),
            "re_reconciled_submissions": re_reconciled_count,
            "message": f"مرجع بارگذاری شد و {re_reconciled_count} ثبت عملکرد مجدداً بررسی شد",
        }


# ============ List reference versions for performance entry ============

@app.get("/api/performance-entries/{entry_id}/references")
def list_perf_references(entry_id: str, request: Request):
    user = current_user(request)
    with db() as con:
        entry = con.execute("SELECT * FROM performance_entries WHERE id=?", (entry_id,)).fetchone()
        if not entry:
            raise HTTPException(404, "عملکرد پیدا نشد")
        rows = con.execute("""
            SELECT r.*, u.name AS uploaded_by_name
            FROM perf_references r JOIN users u ON u.id=r.uploaded_by
            WHERE r.entry_id=? ORDER BY r.version DESC""", (entry_id,)).fetchall()
        return [dict(r) for r in rows]


# ============ Get diffs for a specific submission ============

@app.get("/api/performance-entries/{entry_id}/submissions/{sub_id}/diffs")
def get_perf_submission_diffs(entry_id: str, sub_id: str, request: Request):
    user = current_user(request)
    with db() as con:
        sub = con.execute("SELECT * FROM perf_submissions WHERE id=? AND entry_id=?", (sub_id, entry_id)).fetchone()
        if not sub:
            raise HTTPException(404, "ارسال پیدا نشد")
        # Permission: owner or admin
        if sub["user_id"] != user["id"] and user["role"] not in ("ADMIN", "CEO"):
            raise HTTPException(403, "دسترسی ندارید")
        diffs = con.execute("SELECT * FROM perf_submission_diffs WHERE submission_id=? ORDER BY source_row", (sub_id,)).fetchall()
        return {
            "submission": dict(sub),
            "report": json.loads(sub["report_json"]),
            "diffs": [dict(d) for d in diffs],
            "diff_count": len(diffs),
        }


# ============ Download diffs as Excel ============

@app.get("/api/performance-entries/{entry_id}/submissions/{sub_id}/diffs/excel")
def download_perf_submission_diffs_excel(entry_id: str, sub_id: str, request: Request):
    """Download all diffs as an Excel file (for offline review)."""
    user = current_user(request)
    with db() as con:
        sub = con.execute("SELECT * FROM perf_submissions WHERE id=? AND entry_id=?", (sub_id, entry_id)).fetchone()
        if not sub:
            raise HTTPException(404, "ارسال پیدا نشد")
        if sub["user_id"] != user["id"] and user["role"] not in ("ADMIN", "CEO"):
            raise HTTPException(403, "دسترسی ندارید")
        diffs = con.execute("SELECT * FROM perf_submission_diffs WHERE submission_id=? ORDER BY source_row", (sub_id,)).fetchall()
        # Build Excel
        from io import BytesIO
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment
        wb = Workbook()
        ws = wb.active
        ws.title = "اختلافات"
        # Header row
        headers = ["ردیف فایل", "شماره سند", "خط", "تاریخ", "حساب", "بدهکار", "بستانکار", "شرح",
                   "نوع اختلاف", "جزئیات اختلاف",
                   "بدهکار مرجع", "بستانکار مرجع", "تاریخ مرجع", "حساب مرجع", "شرح مرجع"]
        ws.append(headers)
        # Style header
        header_fill = PatternFill(start_color="0b8f89", end_color="0b8f89", fill_type="solid")
        header_font = Font(color="FFFFFF", bold=True, size=11)
        for col_idx in range(1, len(headers) + 1):
            cell = ws.cell(row=1, column=col_idx)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center")
        # Color-code issue types
        issue_colors = {
            "MISSING_FROM_REFERENCE": "FECACA",    # red
            "DEBIT_MISMATCH": "FED7AA",            # orange
            "CREDIT_MISMATCH": "FED7AA",           # orange
            "DATE_MISMATCH": "FEF3C7",              # yellow
            "ACCOUNT_MISMATCH": "FEF3C7",           # yellow
            "DESCRIPTION_MISMATCH": "E0F2FE",      # blue
            "DUPLICATE": "F3E8FF",                 # purple
            "OUT_OF_RANGE": "FEE2E2",              # red
        }
        issue_labels = {
            "MISSING_FROM_REFERENCE": "در مرجع نیست",
            "DEBIT_MISMATCH": "اختلاف بدهکار",
            "CREDIT_MISMATCH": "اختلاف بستانکار",
            "DATE_MISMATCH": "اختلاف تاریخ",
            "ACCOUNT_MISMATCH": "اختلاف حساب",
            "DESCRIPTION_MISMATCH": "اختلاف شرح",
            "DUPLICATE": "ردیف تکراری",
            "OUT_OF_RANGE": "خارج از بازه",
        }
        for d in diffs:
            row_data = [
                d["source_row"], d["voucher"], d["line"], d["date"], d["account"],
                d["debit"], d["credit"], d["description"],
                issue_labels.get(d["issue_type"], d["issue_type"]),
                d["issue_detail"],
                d["ref_debit"] or "", d["ref_credit"] or "", d["ref_date"] or "",
                d["ref_account"] or "", d["ref_description"] or "",
            ]
            ws.append(row_data)
            row_idx = ws.max_row
            color = issue_colors.get(d["issue_type"], "FFFFFF")
            fill = PatternFill(start_color=color, end_color=color, fill_type="solid")
            for col_idx in range(1, len(headers) + 1):
                ws.cell(row=row_idx, column=col_idx).fill = fill
        # Column widths
        for col_letter, width in zip("ABCDEFGHIJKLMNO", [10, 18, 8, 14, 22, 14, 14, 30, 18, 50, 14, 14, 14, 22, 30]):
            ws.column_dimensions[col_letter].width = width
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = f"A1:{chr(64 + len(headers))}1"
        out = BytesIO()
        wb.save(out)
        out.seek(0)
        from fastapi.responses import StreamingResponse
        filename = f"diffs-entry-{entry_id}-v{sub['version']}.xlsx"
        return StreamingResponse(out,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f'attachment; filename="{filename}"'})


# ============ Manager decision on a submission ============

class PerfDecisionModel(BaseModel):
    decision: str = Field(min_length=2, max_length=20)  # APPROVED / RETURNED / REJECTED
    note: str = Field(default="", max_length=2000)


@app.post("/api/performance-entries/{entry_id}/submissions/{sub_id}/decision")
def perf_submission_decision(entry_id: str, sub_id: str, payload: PerfDecisionModel, request: Request):
    """Manager approves / returns / rejects a submission."""
    user = current_user(request)
    require_perm(user, "performance.review")
    if payload.decision not in ("APPROVED", "RETURNED", "REJECTED"):
        raise HTTPException(400, "تصمیم باید APPROVED، RETURNED یا REJECTED باشد")
    with db() as con:
        sub = con.execute("SELECT * FROM perf_submissions WHERE id=? AND entry_id=?", (sub_id, entry_id)).fetchone()
        if not sub:
            raise HTTPException(404, "ارسال پیدا نشد")
        ts = now()
        con.execute("""UPDATE perf_submissions SET status=?, manager_id=?, decision_at=?, decision_note=?
                       WHERE id=?""",
                     (payload.decision, user["id"], ts, payload.note, sub_id))
        con.execute("INSERT INTO performance_events VALUES(?,?,?,?,?,?)",
                    (uid(), entry_id, user["id"], f"SUBMISSION_{payload.decision}",
                     json.dumps({"submission_id": sub_id, "version": sub["version"], "note": payload.note}), ts))
        # Notify employee
        notify(con, sub["user_id"], f"تصمیم مدیر: {payload.decision}",
               f"نسخه {sub['version']} از عملکرد — {payload.decision}")
        audit(con, user["id"], f"PERF_SUB_{payload.decision}", "perf_submission", sub_id,
              {"entry_id": entry_id, "note": payload.note})
        return {"ok": True, "status": payload.decision}



@app.get("/api/performance-entries/{entry_id}/submissions")
def list_perf_submissions(entry_id: str, request: Request):
    user = current_user(request)
    with db() as con:
        entry = con.execute("SELECT * FROM performance_entries WHERE id=?", (entry_id,)).fetchone()
        if not entry:
            raise HTTPException(404, "عملکرد پیدا نشد")
        if entry["user_id"] != user["id"] and user["role"] not in ("ADMIN", "CEO"):
            raise HTTPException(403, "دسترسی ندارید")
        rows = con.execute("""
            SELECT s.*, u.name AS user_name, m.name AS manager_name,
                   (SELECT COUNT(*) FROM perf_submission_diffs WHERE submission_id=s.id) AS diff_count,
                   (SELECT COUNT(*) FROM perf_references WHERE entry_id=s.entry_id) AS reference_count
            FROM perf_submissions s
            JOIN users u ON u.id=s.user_id
            LEFT JOIN users m ON m.id=s.manager_id
            WHERE s.entry_id=? ORDER BY s.version DESC""", (entry_id,)).fetchall()
        result = []
        for r in rows:
            d = dict(r)
            d["report"] = json.loads(r["report_json"])
            del d["report_json"]
            result.append(d)
        return result

@app.post("/api/performance-entries/{entry_id}/timer/start")
def perf_timer_start(entry_id: str, request: Request):
    user = current_user(request)
    with db() as con:
        active = con.execute("SELECT id FROM time_entries WHERE user_id=? AND end_at IS NULL", (user["id"],)).fetchone()
        if active:
            raise HTTPException(409, "تایمر فعالی دارید")
        entry = con.execute("SELECT * FROM performance_entries WHERE id=?", (entry_id,)).fetchone()
        if not entry:
            raise HTTPException(404, "عملکرد پیدا نشد")
        tid = uid()
        con.execute("INSERT INTO time_entries VALUES(?,?,?,?,?,?,?,?,?)", (tid, None, user["id"], now(), None, 0, f"performance:{entry_id}", 1, now()))
        con.execute("INSERT INTO performance_events VALUES(?,?,?,?,?,?)", (uid(), entry_id, user["id"], "TIMER_START", json.dumps({}), now()))
        return {"id": tid, "started_at": now()}

@app.post("/api/performance-entries/{entry_id}/timer/stop")
def perf_timer_stop(entry_id: str, request: Request):
    user = current_user(request)
    with db() as con:
        entry = con.execute("SELECT * FROM time_entries WHERE user_id=? AND end_at IS NULL AND description=?", (user["id"], f"performance:{entry_id}")).fetchone()
        if not entry:
            raise HTTPException(404, "تایمر فعال پیدا نشد")
        end = now()
        start_dt = datetime.fromisoformat(entry["start_at"])
        end_dt = datetime.fromisoformat(end)
        duration = int((end_dt - start_dt).total_seconds())
        con.execute("UPDATE time_entries SET end_at=?, duration_seconds=? WHERE id=?", (end, duration, entry["id"]))
        con.execute("INSERT INTO performance_events VALUES(?,?,?,?,?,?)", (uid(), entry_id, user["id"], "TIMER_STOP", json.dumps({"duration": duration}), now()))
        return {"duration_seconds": duration, "minutes": round(duration/60)}


# ========================================================================
# SYSTEM UPDATE / BACKUP / RESTORE API
# ========================================================================
import shutil
import tempfile
import urllib.request
import subprocess

SYSTEM_VERSION = "0.3.0.17"
SYSTEM_REPO_URL = "https://github.com/glcco9819-lang/yafgtax.git"
SYSTEM_UPDATE_DIR = ROOT / "updates"  # temporary download location
SYSTEM_BACKUP_DIR = DATA / "backups"

class UpdateRequestModel(BaseModel):
    source: str = "github"  # "github" or "upload"
    branch: str = "main"

@app.get("/api/system/version")
def system_version(request: Request):
    """Returns current system version and latest available from GitHub."""
    user = current_user(request)
    require_perm(user, "settings.view")
    latest = None
    try:
        # Try to get latest commit info from GitHub API
        api_url = f"https://api.github.com/repos/glcco9819-lang/yafgtax/commits/{SYSTEM_REPO_URL.split('/').pop().replace('.git','').split('/')[-1] if '/yafgtax' in SYSTEM_REPO_URL else 'main'}"
        # Simpler: just try to fetch our own status endpoint from GitHub raw
        import urllib.request
        req = urllib.request.Request(f"https://raw.githubusercontent.com/glcco9819-lang/yafgtax/main/yfg-accounting/app/main.py", headers={"User-Agent": "YFG-Update-Check"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            content = resp.read().decode("utf-8", errors="replace")
            # Find SYSTEM_VERSION in remote
            import re as _re
            m = _re.search(r'SYSTEM_VERSION\s*=\s*"([^"]+)"', content)
            if m:
                latest = m.group(1)
    except Exception:
        latest = None
    return {
        "current": SYSTEM_VERSION,
        "latest": latest,
        "up_to_date": (latest == SYSTEM_VERSION) if latest else None,
        "repo_url": SYSTEM_REPO_URL,
    }

@app.get("/api/system/backups")
def list_backups(request: Request):
    """Lists available database backups."""
    user = current_user(request)
    require_perm(user, "settings.view")
    backups = []
    SYSTEM_BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    for f in sorted(SYSTEM_BACKUP_DIR.iterdir(), key=lambda x: x.stat().st_mtime, reverse=True):
        if f.is_file() and f.name.endswith(".sqlite3.bak"):
            stat = f.stat()
            backups.append({
                "filename": f.name,
                "size_bytes": stat.st_size,
                "size_mb": round(stat.st_size / (1024*1024), 2),
                "created_at": datetime.fromtimestamp(stat.st_mtime).isoformat(),
            })
    return backups

@app.post("/api/system/backup")
def create_backup(request: Request, label: str = ""):
    """Creates a backup of the SQLite database."""
    user = current_user(request)
    require_perm(user, "settings.view")
    SYSTEM_BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    ts = now().replace(":", "-").replace(".", "_")
    safe_label = re.sub(r"[^A-Za-z0-9_-]", "", label)[:30] if label else ""
    backup_name = f"backup_{ts}{'_' + safe_label if safe_label else ''}.sqlite3.bak"
    backup_path = SYSTEM_BACKUP_DIR / backup_name
    shutil.copy2(str(DB_PATH), str(backup_path))
    with sqlite3.connect(DB_PATH) as con: con.execute("INSERT INTO audit_events VALUES(?,?,?,?,?,?,?)", (uid(), user["id"], "SYSTEM_BACKUP", "system", None, json.dumps({"file": backup_name}), now())); con.commit()
    return {"filename": backup_name, "size_bytes": backup_path.stat().st_size}

@app.post("/api/system/restore")
def restore_backup(request: Request, filename: str = ""):
    """Restores a backup of the SQLite database."""
    user = current_user(request)
    require_perm(user, "settings.view")
    if not filename:
        raise HTTPException(400, "نام فایل پشتیبان الزامی است")
    backup_path = SYSTEM_BACKUP_DIR / filename
    if not backup_path.exists():
        raise HTTPException(404, "فایل پشتیبان پیدا نشد")
    # First, backup current DB
    current_backup = SYSTEM_BACKUP_DIR / f"pre_restore_{now().replace(':','-').replace('.','_')}.sqlite3.bak"
    shutil.copy2(str(DB_PATH), str(current_backup))
    # Restore
    shutil.copy2(str(backup_path), str(DB_PATH))
    return {"ok": True, "restored_from": filename, "auto_backup": current_backup.name}

@app.delete("/api/system/backups/{filename}")
def delete_backup(filename: str, request: Request):
    """Deletes a backup file."""
    user = current_user(request)
    require_perm(user, "settings.view")
    backup_path = SYSTEM_BACKUP_DIR / filename
    if not backup_path.exists():
        raise HTTPException(404, "فایل پشتیبان پیدا نشد")
    backup_path.unlink()
    return {"ok": True}

@app.post("/api/system/update")
def system_update(request: Request, source: str = "github", branch: str = "main"):
    """Downloads and applies an update from GitHub (or a manual upload).
    
    Steps:
    1. Back up current database
    2. Download ZIP from GitHub (main branch)
    3. Extract to a temp dir
    4. Copy new files to the app directory (preserving data/)
    5. Return summary — the user must restart the server after this.
    """
    user = current_user(request)
    require_perm(user, "settings.view")
    
    # Step 1: Auto-backup database
    SYSTEM_BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    auto_backup_name = f"pre_update_{now().replace(':','-').replace('.','_')}.sqlite3.bak"
    auto_backup_path = SYSTEM_BACKUP_DIR / auto_backup_name
    shutil.copy2(str(DB_PATH), str(auto_backup_path))
    
    # Step 2: Download
    SYSTEM_UPDATE_DIR.mkdir(parents=True, exist_ok=True)
    if source == "github":
        zip_url = f"https://github.com/glcco9819-lang/yafgtax/archive/refs/heads/{branch}.zip"
        try:
            req = urllib.request.Request(zip_url, headers={"User-Agent": "YFG-Update"})
            with urllib.request.urlopen(req, timeout=60) as resp:
                zip_data = resp.read()
        except Exception as e:
            return {"ok": False, "error": f"دانلود ناموفق: {e}"}
    else:
        return {"ok": False, "error": "منبع نامعتبر (فقط 'github' پشتیبانی میشود)"}
    
    # Step 3: Extract
    temp_dir = Path(tempfile.mkdtemp(prefix="yfg_update_"))
    zip_path = temp_dir / "update.zip"
    zip_path.write_bytes(zip_data)
    
    try:
        with zipfile.ZipFile(str(zip_path), "r") as zf:
            zf.extractall(str(temp_dir / "extracted"))
    except Exception as e:
        shutil.rmtree(str(temp_dir), ignore_errors=True)
        return {"ok": False, "error": f"استخراج ZIP ناموفق: {e}"}
    
    # Step 4: Find the extracted folder (github repo zip has a top-level folder like "yafgtax-main/")
    extracted_items = list((temp_dir / "extracted").iterdir())
    if not extracted_items:
        shutil.rmtree(str(temp_dir), ignore_errors=True)
        return {"ok": False, "error": "ZIP خالی است"}
    repo_dir = extracted_items[0]  # first subfolder
    
    # Step 5: Copy new files
    updated_files = []
    
    # Copy main.py
    src_main = repo_dir / "yfg-accounting" / "app" / "main.py"
    dst_main = ROOT / "app" / "main.py"
    if src_main.exists():
        shutil.copy2(str(src_main), str(dst_main))
        updated_files.append("app/main.py")
    
    # Copy static files
    src_static = repo_dir / "yfg-accounting" / "app" / "static"
    dst_static = ROOT / "app" / "static"
    if src_static.exists():
        for f in src_static.iterdir():
            if f.is_file():
                shutil.copy2(str(f), str(dst_static / f.name))
                updated_files.append(f"app/static/{f.name}")
    
    # Copy next.config.ts
    src_nextconfig = repo_dir / "next.config.ts"
    dst_nextconfig = ROOT.parent / "next.config.ts" if (ROOT.parent / "next.config.ts").exists() else None
    if src_nextconfig.exists() and dst_nextconfig:
        shutil.copy2(str(src_nextconfig), str(dst_nextconfig))
        updated_files.append("next.config.ts")
    
    # Copy src/ (Next.js)
    src_nextjs = repo_dir / "src"
    dst_nextjs = ROOT.parent / "src" if (ROOT.parent / "src").exists() else None
    if src_nextjs.exists() and dst_nextjs:
        for f in src_nextjs.rglob("*"):
            if f.is_file():
                rel = f.relative_to(src_nextjs)
                dst_f = dst_nextjs / rel
                dst_f.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(str(f), str(dst_f))
                updated_files.append(f"src/{rel}")
    
    # Copy public/static
    src_public = repo_dir / "public" / "static"
    dst_public = ROOT.parent / "public" / "static" if (ROOT.parent / "public" / "static").exists() else None
    if src_public.exists() and dst_public:
        for f in src_public.iterdir():
            if f.is_file():
                shutil.copy2(str(f), str(dst_public / f.name))
                updated_files.append(f"public/static/{f.name}")
    
    # Clean up temp
    shutil.rmtree(str(temp_dir), ignore_errors=True)
    
    # Get new version from updated main.py
    new_version = SYSTEM_VERSION
    try:
        with open(str(dst_main), "r", encoding="utf-8") as f:
            content = f.read()
            m = re.search(r'SYSTEM_VERSION\s*=\s*"([^"]+)"', content)
            if m:
                new_version = m.group(1)
    except Exception:
        pass
    
    return {
        "ok": True,
        "previous_version": SYSTEM_VERSION,
        "new_version": new_version,
        "backup_file": auto_backup_name,
        "updated_files": updated_files,
        "message": f"بهروزرسانی از {source}:{branch} انجام شد. {len(updated_files)} فایل آپدیت شد. سرور باید ریاستارت شود.",
        "restart_required": True,
    }

@app.post("/api/system/update/upload")
async def system_update_upload(request: Request, file: UploadFile = File(...)):
    """Apply update from an uploaded ZIP file (manual update)."""
    user = current_user(request)
    require_perm(user, "settings.view")
    
    # Auto-backup
    SYSTEM_BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    auto_backup_name = f"pre_update_{now().replace(':','-').replace('.','_')}.sqlite3.bak"
    auto_backup_path = SYSTEM_BACKUP_DIR / auto_backup_name
    shutil.copy2(str(DB_PATH), str(auto_backup_path))
    
    content = await file.read()
    temp_dir = Path(tempfile.mkdtemp(prefix="yfg_upload_"))
    zip_path = temp_dir / "upload.zip"
    zip_path.write_bytes(content)
    
    try:
        with zipfile.ZipFile(str(zip_path), "r") as zf:
            zf.extractall(str(temp_dir / "extracted"))
    except Exception as e:
        shutil.rmtree(str(temp_dir), ignore_errors=True)
        return {"ok": False, "error": f"استخراج ZIP ناموفق: {e}"}
    
    # Find the extracted folder
    extracted_root = temp_dir / "extracted"
    # Check if there's a yafgtax-main folder or direct structure
    repo_dir = extracted_root
    if (extracted_root / "yfg-accounting").exists():
        repo_dir = extracted_root
    else:
        subdirs = list(extracted_root.iterdir())
        if subdirs and (subdirs[0] / "yfg-accounting").exists():
            repo_dir = subdirs[0]
    
    updated_files = []
    
    # Copy main.py
    src_main = repo_dir / "yfg-accounting" / "app" / "main.py"
    dst_main = ROOT / "app" / "main.py"
    if src_main.exists():
        shutil.copy2(str(src_main), str(dst_main))
        updated_files.append("app/main.py")
    
    # Copy static files
    src_static = repo_dir / "yfg-accounting" / "app" / "static"
    dst_static = ROOT / "app" / "static"
    if src_static.exists():
        for f in src_static.iterdir():
            if f.is_file():
                shutil.copy2(str(f), str(dst_static / f.name))
                updated_files.append(f"app/static/{f.name}")
    
    # Copy public/static
    src_public = repo_dir / "public" / "static"
    dst_public = ROOT.parent / "public" / "static" if (ROOT.parent / "public" / "static").exists() else None
    if src_public.exists() and dst_public:
        for f in src_public.iterdir():
            if f.is_file():
                shutil.copy2(str(f), str(dst_public / f.name))
                updated_files.append(f"public/static/{f.name}")
    
    shutil.rmtree(str(temp_dir), ignore_errors=True)
    
    # Get new version
    new_version = SYSTEM_VERSION
    try:
        with open(str(dst_main), "r", encoding="utf-8") as f:
            content = f.read()
            m = re.search(r'SYSTEM_VERSION\s*=\s*"([^"]+)"', content)
            if m:
                new_version = m.group(1)
    except Exception:
        pass
    
    return {
        "ok": True,
        "previous_version": SYSTEM_VERSION,
        "new_version": new_version,
        "backup_file": auto_backup_name,
        "updated_files": updated_files,
        "message": f"بهروزرسانی از فایل آپلودی انجام شد. {len(updated_files)} فایل آپدیت شد. سرور باید ریاستارت شود.",
        "restart_required": True,
    }

@app.post("/api/system/restart")
def system_restart(request: Request):
    """Restarts the backend server by re-executing the process."""
    user = current_user(request)
    require_perm(user, "settings.view")
    
    import threading
    import time
    import os
    import subprocess
    
    def delayed_restart():
        time.sleep(2)  # Wait for response to be sent
        # Write a restart script
        restart_script = ROOT / "restart_server.sh"
        restart_script.write_text(f"""#!/bin/bash
# YFG Auto-Restart Script
sleep 1
cd "{ROOT}"
nohup /home/z/.venv/bin/python3 -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --proxy-headers < /dev/null > /tmp/yfg_backend.log 2>&1 &
echo "Restarted at $(date)" >> /tmp/yfg_restart.log
""")
        os.chmod(str(restart_script), 0o755)
        # Execute the restart script in background
        subprocess.Popen(["bash", str(restart_script)], start_new_session=True)
        # Kill current process
        os.kill(os.getpid(), 9)  # SIGKILL — the new process will take over
    
    threading.Thread(target=delayed_restart, daemon=True).start()
    
    return {
        "ok": True,
        "message": "سرور در حال ریاستارت است. لطفاً ۱۰ ثانیه صبر کنید و سپس صفحه را رفرش کنید.",
    }

@app.post("/api/system/update-and-restart")
def system_update_and_restart(request: Request, source: str = "github", branch: str = "main"):
    """Download, apply update, AND restart the server in one step.
    This is the 'one-click update' endpoint."""
    user = current_user(request)
    require_perm(user, "settings.view")
    
    # Step 1: Auto-backup database
    SYSTEM_BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    auto_backup_name = f"pre_update_{now().replace(':','-').replace('.','_')}.sqlite3.bak"
    auto_backup_path = SYSTEM_BACKUP_DIR / auto_backup_name
    shutil.copy2(str(DB_PATH), str(auto_backup_path))
    
    # Step 2: Download from GitHub
    if source == "github":
        zip_url = f"https://github.com/glcco9819-lang/yafgtax/archive/refs/heads/{branch}.zip"
        try:
            req = urllib.request.Request(zip_url, headers={"User-Agent": "YFG-Update"})
            with urllib.request.urlopen(req, timeout=60) as resp:
                zip_data = resp.read()
        except Exception as e:
            return {"ok": False, "error": f"دانلود ناموفق: {e}"}
    else:
        return {"ok": False, "error": "فقط GitHub پشتیبانی می‌شود"}
    
    # Step 3: Extract
    temp_dir = Path(tempfile.mkdtemp(prefix="yfg_update_"))
    zip_path = temp_dir / "update.zip"
    zip_path.write_bytes(zip_data)
    
    try:
        with zipfile.ZipFile(str(zip_path), "r") as zf:
            zf.extractall(str(temp_dir / "extracted"))
    except Exception as e:
        shutil.rmtree(str(temp_dir), ignore_errors=True)
        return {"ok": False, "error": f"استخراج ZIP ناموفق: {e}"}
    
    # Step 4: Find the extracted folder
    extracted_items = list((temp_dir / "extracted").iterdir())
    if not extracted_items:
        shutil.rmtree(str(temp_dir), ignore_errors=True)
        return {"ok": False, "error": "ZIP خالی است"}
    repo_dir = extracted_items[0]
    
    # Step 5: Copy all new files
    updated_files = []
    
    # Copy main.py
    src_main = repo_dir / "yfg-accounting" / "app" / "main.py"
    dst_main = ROOT / "app" / "main.py"
    if src_main.exists():
        shutil.copy2(str(src_main), str(dst_main))
        updated_files.append("app/main.py")
    
    # Copy static files
    src_static = repo_dir / "yfg-accounting" / "app" / "static"
    dst_static = ROOT / "app" / "static"
    if src_static.exists():
        for f in src_static.iterdir():
            if f.is_file():
                shutil.copy2(str(f), str(dst_static / f.name))
                updated_files.append(f"app/static/{f.name}")
    
    # Copy scripts
    src_scripts = repo_dir / "yfg-accounting" / "scripts"
    dst_scripts = ROOT.parent / "yfg-accounting" / "scripts"
    if src_scripts.exists() and dst_scripts.exists():
        for f in src_scripts.iterdir():
            if f.is_file():
                shutil.copy2(str(f), str(dst_scripts / f.name))
                updated_files.append(f"scripts/{f.name}")
    
    # Copy next.config.ts
    src_nextconfig = repo_dir / "next.config.ts"
    dst_nextconfig = ROOT.parent / "next.config.ts" if (ROOT.parent / "next.config.ts").exists() else None
    if src_nextconfig.exists() and dst_nextconfig:
        shutil.copy2(str(src_nextconfig), str(dst_nextconfig))
        updated_files.append("next.config.ts")
    
    # Copy public/static
    src_public = repo_dir / "public" / "static"
    dst_public = ROOT.parent / "public" / "static" if (ROOT.parent / "public" / "static").exists() else None
    if src_public.exists() and dst_public:
        for f in src_public.iterdir():
            if f.is_file():
                shutil.copy2(str(f), str(dst_public / f.name))
                updated_files.append(f"public/static/{f.name}")
    
    # Clean up
    shutil.rmtree(str(temp_dir), ignore_errors=True)
    
    # Get new version
    new_version = SYSTEM_VERSION
    try:
        with open(str(dst_main), "r", encoding="utf-8") as f:
            content_str = f.read()
            m = re.search(r'SYSTEM_VERSION\s*=\s*"([^"]+)"', content_str)
            if m:
                new_version = m.group(1)
    except Exception:
        pass
    
    # Step 6: Write restart script and schedule restart
    import threading, time, os, subprocess
    restart_script = ROOT / "restart_server.sh"
    restart_script.write_text(f"""#!/bin/bash
# YFG Auto-Restart after Update
sleep 2
cd "{ROOT}"
nohup /home/z/.venv/bin/python3 -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --proxy-headers < /dev/null > /tmp/yfg_backend.log 2>&1 &
echo "Auto-restarted at $(date) after update to {new_version}" >> /tmp/yfg_restart.log
""")
    os.chmod(str(restart_script), 0o755)
    
    def delayed_restart():
        time.sleep(3)
        subprocess.Popen(["bash", str(restart_script)], start_new_session=True)
        os.kill(os.getpid(), 9)
    
    threading.Thread(target=delayed_restart, daemon=True).start()
    
    return {
        "ok": True,
        "previous_version": SYSTEM_VERSION,
        "new_version": new_version,
        "backup_file": auto_backup_name,
        "updated_files": updated_files,
        "updated_count": len(updated_files),
        "message": f"آپدیت به نسخه {new_version} نصب شد. {len(updated_files)} فایل آپدیت شد. سرور در حال ریاستارت است — ۱۰ ثانیه صبر کنید.",
        "restart_required": True,
        "restart_scheduled": True,
    }


# ========================================================================
# PHASE 1: TAX DEADLINES API (تقویم سررسیدهای مالیاتی)
# ========================================================================
TAX_DEADLINE_TYPES = {
    'VAT_QUARTERLY': 'ارزش افزوده فصلی',
    'ANNUAL_RETURN': 'اظهارنامه سالانه',
    'PAYROLL_TAX': 'مالیات حقوق',
    'SOCIAL_SECURITY': 'بیمه تامین اجتماعی',
    'MOUDIAN': 'سامانه مودیان',
    'AUDIT': 'حسابرسی',
    'OTHER': 'سایر',
}
TAX_DEADLINE_STATUS = {
    'PENDING': {'label': 'در انتظار', 'color': '#f59e0b', 'bg': '#fef3c7'},
    'FILED': {'label': 'ارسال شد', 'color': '#3b82f6', 'bg': '#dbeafe'},
    'PAID': {'label': 'تسویه شد', 'color': '#10b981', 'bg': '#d1fae5'},
    'OVERDUE': {'label': 'سررسید گذشته', 'color': '#ef4444', 'bg': '#fee2e2'},
    'CANCELLED': {'label': 'لغو شد', 'color': '#94a3b8', 'bg': '#f1f5f9'},
}

class TaxDeadlineCreateModel(BaseModel):
    company_id: str
    deadline_type: str = "OTHER"
    title: str
    due_date: str
    period_label: str = ""
    amount: float | None = None
    notes: str = ""
    assigned_user_id: str | None = None

class TaxDeadlineUpdateModel(BaseModel):
    title: str | None = None
    deadline_type: str | None = None
    due_date: str | None = None
    period_label: str | None = None
    amount: float | None = None
    status: str | None = None
    notes: str | None = None
    assigned_user_id: str | None = None

@app.get("/api/tax-deadlines")
def list_tax_deadlines(request: Request, company_id: str = "", status: str = "", upcoming: int = 0):
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        sql = """SELECT td.*, c.name AS company_name, u.name AS assigned_user_name
                 FROM tax_deadlines td
                 LEFT JOIN companies c ON c.id=td.company_id
                 LEFT JOIN users u ON u.id=td.assigned_user_id
                 WHERE 1=1"""
        params = []
        if company_id:
            sql += " AND td.company_id=?"
            params.append(company_id)
        if status:
            sql += " AND td.status=?"
            params.append(status)
        if upcoming == 1:
            today = now()[:10]
            sql += " AND td.due_date >= ? AND td.status='PENDING' ORDER BY td.due_date ASC"
            params.append(today)
        else:
            sql += " ORDER BY td.due_date DESC, td.created_at DESC"
        rows = con.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

@app.post("/api/tax-deadlines")
def create_tax_deadline(payload: TaxDeadlineCreateModel, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    tid = uid()
    ts = now()
    with db() as con:
        con.execute("""INSERT INTO tax_deadlines
            (id, company_id, deadline_type, title, due_date, period_label, amount, status, notes, assigned_user_id, created_by, created_at, updated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (tid, payload.company_id, payload.deadline_type, payload.title, payload.due_date,
             payload.period_label, payload.amount, 'PENDING', payload.notes, payload.assigned_user_id,
             user["id"], ts, ts))
    return {"id": tid}

@app.patch("/api/tax-deadlines/{deadline_id}")
def update_tax_deadline(deadline_id: str, payload: TaxDeadlineUpdateModel, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    with db() as con:
        existing = con.execute("SELECT * FROM tax_deadlines WHERE id=?", (deadline_id,)).fetchone()
        if not existing: raise HTTPException(404, "سررسید پیدا نشد")
        updates = []
        params = []
        for k, v in payload.model_dump(exclude_unset=True).items():
            if v is None: continue
            updates.append(f"{k}=?")
            params.append(v)
        if payload.status in ('FILED', 'PAID') and not existing["completed_at"]:
            updates.append("completed_at=?")
            params.append(now())
            updates.append("completed_by=?")
            params.append(user["id"])
        if not updates: return {"ok": True, "updated": 0}
        updates.append("updated_at=?")
        params.append(now())
        params.append(deadline_id)
        con.execute(f"UPDATE tax_deadlines SET {', '.join(updates)} WHERE id=?", params)
    return {"ok": True, "updated": len(updates)-1}

@app.delete("/api/tax-deadlines/{deadline_id}")
def delete_tax_deadline(deadline_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    with db() as con:
        con.execute("DELETE FROM tax_deadlines WHERE id=?", (deadline_id,))
    return {"ok": True}

@app.get("/api/tax-deadlines/types")
def list_tax_deadline_types(request: Request):
    user = current_user(request)
    require_perm(user, "customers.view")
    return {"types": TAX_DEADLINE_TYPES, "statuses": TAX_DEADLINE_STATUS}


# ========================================================================
# PHASE 1: COMPANY STAFF API (تخصیص کارمند به شرکت)
# ========================================================================
STAFF_ROLES = {
    'lead': 'سرپرست',
    'accountant': 'حسابدار',
    'assistant': 'کمکحسابدار',
}

class CompanyStaffModel(BaseModel):
    company_id: str
    user_id: str
    role: str = "accountant"
    notes: str = ""

@app.get("/api/companies/{company_id}/staff")
def list_company_staff(company_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        rows = con.execute("""SELECT cs.*, u.name AS user_name, u.role AS user_role, u.first_name, u.last_name
                              FROM company_staff cs JOIN users u ON u.id=cs.user_id
                              WHERE cs.company_id=? ORDER BY cs.assigned_at DESC""", (company_id,)).fetchall()
        return [dict(r) for r in rows]

@app.post("/api/companies/{company_id}/staff")
def assign_company_staff(company_id: str, payload: CompanyStaffModel, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    sid = uid()
    with db() as con:
        try:
            con.execute("INSERT INTO company_staff VALUES(?,?,?,?,?,?,?,?)",
                        (sid, company_id, payload.user_id, payload.role, now(), user["id"], 1, payload.notes))
        except Exception as e:
            if "UNIQUE" in str(e): raise HTTPException(400, "این کاربر قبلاً به این شرکت تخصیص داده شده")
            raise
    return {"id": sid}

@app.delete("/api/companies/{company_id}/staff/{staff_id}")
def unassign_company_staff(company_id: str, staff_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    with db() as con:
        con.execute("DELETE FROM company_staff WHERE id=? AND company_id=?", (staff_id, company_id))
    return {"ok": True}

@app.get("/api/users/{user_id}/companies-assigned")
def list_user_assigned_companies(user_id: str, request: Request):
    """Returns companies assigned to a specific user."""
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        rows = con.execute("""SELECT cs.*, c.name AS company_name, c.code AS company_code
                              FROM company_staff cs JOIN companies c ON c.id=cs.company_id
                              WHERE cs.user_id=? AND cs.active=1""", (user_id,)).fetchall()
        return [dict(r) for r in rows]


# ========================================================================
# PHASE 1: FEE MODULE API (ماژول Fee و مطالبات)
# ========================================================================
FEE_TYPES = {
    'monthly': 'ماهانه',
    'quarterly': 'فصلی',
    'annual': 'سالانه',
    'hourly': 'ساعتی',
    'one_time': 'یکباره',
}
FEE_STATUS = {
    'UNPAID': {'label': 'پرداختنشده', 'color': '#ef4444', 'bg': '#fee2e2'},
    'PARTIAL': {'label': 'پرداخت جزئی', 'color': '#f59e0b', 'bg': '#fef3c7'},
    'PAID': {'label': 'تسویه شد', 'color': '#10b981', 'bg': '#d1fae5'},
    'OVERDUE': {'label': 'سررسید گذشته', 'color': '#dc2626', 'bg': '#fee2e2'},
    'CANCELLED': {'label': 'لغو شد', 'color': '#94a3b8', 'bg': '#f1f5f9'},
}

class FeeCreateModel(BaseModel):
    company_id: str
    contract_id: str | None = None
    title: str
    fee_type: str = "monthly"
    amount: float = 0
    currency: str = "IRR"
    period_start: str | None = None
    period_end: str | None = None
    issue_date: str
    due_date: str | None = None
    notes: str = ""

class FeeUpdateModel(BaseModel):
    title: str | None = None
    fee_type: str | None = None
    amount: float | None = None
    currency: str | None = None
    period_start: str | None = None
    period_end: str | None = None
    due_date: str | None = None
    status: str | None = None
    paid_amount: float | None = None
    paid_date: str | None = None
    notes: str | None = None

@app.get("/api/fees")
def list_fees(request: Request, company_id: str = "", status: str = ""):
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        sql = """SELECT f.*, c.name AS company_name
                 FROM fees f LEFT JOIN companies c ON c.id=f.company_id WHERE 1=1"""
        params = []
        if company_id:
            sql += " AND f.company_id=?"
            params.append(company_id)
        if status:
            sql += " AND f.status=?"
            params.append(status)
        sql += " ORDER BY f.issue_date DESC, f.created_at DESC"
        rows = con.execute(sql, params).fetchall()
        result = []
        for r in rows:
            d = dict(r)
            d["balance"] = float(d["amount"]) - float(d["paid_amount"])
            result.append(d)
        return result

@app.post("/api/fees")
def create_fee(payload: FeeCreateModel, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    fid = uid()
    ts = now()
    with db() as con:
        con.execute("""INSERT INTO fees
            (id, company_id, contract_id, title, fee_type, amount, currency, period_start, period_end,
             issue_date, due_date, status, paid_amount, paid_date, notes, created_by, created_at, updated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (fid, payload.company_id, payload.contract_id, payload.title, payload.fee_type,
             payload.amount, payload.currency, payload.period_start, payload.period_end,
             payload.issue_date, payload.due_date, 'UNPAID', 0, None, payload.notes,
             user["id"], ts, ts))
    return {"id": fid}

@app.patch("/api/fees/{fee_id}")
def update_fee(fee_id: str, payload: FeeUpdateModel, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    with db() as con:
        existing = con.execute("SELECT * FROM fees WHERE id=?", (fee_id,)).fetchone()
        if not existing: raise HTTPException(404, "fee پیدا نشد")
        updates = []
        params = []
        for k, v in payload.model_dump(exclude_unset=True).items():
            if v is None: continue
            updates.append(f"{k}=?")
            params.append(v)
        if payload.paid_amount is not None and payload.status is None:
            new_paid = float(payload.paid_amount)
            new_total = float(existing["amount"]) if payload.amount is None else float(payload.amount)
            if new_paid >= new_total and new_total > 0:
                updates.append("status=?")
                params.append("PAID")
            elif new_paid > 0:
                updates.append("status=?")
                params.append("PARTIAL")
        if not updates: return {"ok": True, "updated": 0}
        updates.append("updated_at=?")
        params.append(now())
        params.append(fee_id)
        con.execute(f"UPDATE fees SET {', '.join(updates)} WHERE id=?", params)
    return {"ok": True, "updated": len(updates)-1}

@app.delete("/api/fees/{fee_id}")
def delete_fee(fee_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    with db() as con:
        con.execute("DELETE FROM fees WHERE id=?", (fee_id,))
    return {"ok": True}

@app.get("/api/fees/summary")
def fees_summary(request: Request):
    """Summary of all fees — total, paid, outstanding."""
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        total = con.execute("SELECT COALESCE(SUM(amount),0) FROM fees WHERE status!='CANCELLED'").fetchone()[0]
        paid = con.execute("SELECT COALESCE(SUM(paid_amount),0) FROM fees WHERE status!='CANCELLED'").fetchone()[0]
        outstanding = float(total) - float(paid)
        count_unpaid = con.execute("SELECT COUNT(*) FROM fees WHERE status IN ('UNPAID','PARTIAL','OVERDUE')").fetchone()[0]
        count_overdue = con.execute("SELECT COUNT(*) FROM fees WHERE status='OVERDUE'").fetchone()[0]
        return {
            "total_amount": float(total),
            "paid_amount": float(paid),
            "outstanding": outstanding,
            "count_unpaid": count_unpaid,
            "count_overdue": count_overdue,
        }


# ========================================================================
# PHASE 1: MOUDIAN SYSTEM API (سامانه مودیان — فاکتور الکترونیکی)
# ========================================================================
MOUDIAN_STATUS = {
    'DRAFT': {'label': 'پیشنویس', 'color': '#94a3b8', 'bg': '#f1f5f9'},
    'PENDING': {'label': 'در انتظار', 'color': '#f59e0b', 'bg': '#fef3c7'},
    'SENT': {'label': 'ارسال شد', 'color': '#3b82f6', 'bg': '#dbeafe'},
    'ACCEPTED': {'label': 'تأیید شد', 'color': '#10b981', 'bg': '#d1fae5'},
    'REJECTED': {'label': 'رد شد', 'color': '#ef4444', 'bg': '#fee2e2'},
    'CANCELLED': {'label': 'ابطال شد', 'color': '#94a3b8', 'bg': '#f1f5f9'},
}

class MoudianInvoiceCreateModel(BaseModel):
    company_id: str
    invoice_number: str = ""
    invoice_type: str = "SALES"
    buyer_tin: str = ""
    buyer_name: str = ""
    issue_date: str
    items: list[dict] = []
    discount_amount: float = 0
    notes: str = ""

@app.get("/api/moudian/invoices")
def list_moudian_invoices(request: Request, company_id: str = "", status: str = ""):
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        sql = """SELECT mi.*, c.name AS company_name
                 FROM moudian_invoices mi LEFT JOIN companies c ON c.id=mi.company_id WHERE 1=1"""
        params = []
        if company_id:
            sql += " AND mi.company_id=?"
            params.append(company_id)
        if status:
            sql += " AND mi.status=?"
            params.append(status)
        sql += " ORDER BY mi.issue_date DESC, mi.created_at DESC"
        rows = con.execute(sql, params).fetchall()
        result = []
        for r in rows:
            d = dict(r)
            try:
                d["items"] = json.loads(r["items_json"]) if r["items_json"] else []
            except Exception:
                d["items"] = []
            del d["items_json"]
            result.append(d)
        return result

@app.post("/api/moudian/invoices")
def create_moudian_invoice(payload: MoudianInvoiceCreateModel, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    mid = uid()
    ts = now()
    items_json = json.dumps(payload.items, ensure_ascii=False) if payload.items else "[]"
    # Auto-calculate amounts
    total = sum(float(i.get("amount", 0)) for i in payload.items if isinstance(i, dict))
    tax = round(total * 0.09)  # 9% VAT
    payable = total + tax - float(payload.discount_amount or 0)
    with db() as con:
        # Get seller info from company
        company = con.execute("SELECT * FROM companies WHERE id=?", (payload.company_id,)).fetchone()
        seller_tin = company["national_id"] if company else ""
        seller_name = company["name"] if company else ""
        con.execute("""INSERT INTO moudian_invoices
            (id, company_id, invoice_number, invoice_type, buyer_tin, buyer_name, seller_tin, seller_name,
             issue_date, total_amount, tax_amount, discount_amount, payable_amount, items_json,
             status, reference_id, submitted_at, error_message, created_by, created_at, updated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (mid, payload.company_id, payload.invoice_number, payload.invoice_type,
             payload.buyer_tin, payload.buyer_name, seller_tin, seller_name,
             payload.issue_date, total, tax, float(payload.discount_amount or 0), payable,
             items_json, 'DRAFT', None, None, "", user["id"], ts, ts))
    return {"id": mid, "total": total, "tax": tax, "payable": payable}

@app.patch("/api/moudian/invoices/{invoice_id}")
def update_moudian_invoice(invoice_id: str, request: Request, status: str = "", reference_id: str = "", error_message: str = ""):
    user = current_user(request)
    require_perm(user, "customers.manage")
    with db() as con:
        existing = con.execute("SELECT * FROM moudian_invoices WHERE id=?", (invoice_id,)).fetchone()
        if not existing: raise HTTPException(404, "فاکتور مودیان پیدا نشد")
        updates = []
        params = []
        if status:
            updates.append("status=?")
            params.append(status)
            if status == 'SENT' and not existing["submitted_at"]:
                updates.append("submitted_at=?")
                params.append(now())
        if reference_id:
            updates.append("reference_id=?")
            params.append(reference_id)
        if error_message:
            updates.append("error_message=?")
            params.append(error_message)
        if not updates: return {"ok": True}
        updates.append("updated_at=?")
        params.append(now())
        params.append(invoice_id)
        con.execute(f"UPDATE moudian_invoices SET {', '.join(updates)} WHERE id=?", params)
    return {"ok": True}

@app.post("/api/moudian/invoices/{invoice_id}/submit")
def submit_moudian_invoice(invoice_id: str, request: Request):
    """Submit invoice to Moudian system (mock for now — returns reference_id)."""
    user = current_user(request)
    require_perm(user, "customers.manage")
    with db() as con:
        existing = con.execute("SELECT * FROM moudian_invoices WHERE id=?", (invoice_id,)).fetchone()
        if not existing: raise HTTPException(404, "فاکتور مودیان پیدا نشد")
        if existing["status"] not in ('DRAFT', 'REJECTED'):
            raise HTTPException(400, "فقط فاکتورهای پیشنویس یا ردشده قابل ارسال هستند")
        # Mock submission — in real implementation, this would call the Moudian API
        ref_id = f"MOU-{uid()[:12].upper()}"
        con.execute("UPDATE moudian_invoices SET status='SENT', reference_id=?, submitted_at=?, updated_at=? WHERE id=?",
                    (ref_id, now(), now(), invoice_id))
    return {"ok": True, "reference_id": ref_id, "status": "SENT"}

@app.delete("/api/moudian/invoices/{invoice_id}")
def delete_moudian_invoice(invoice_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    with db() as con:
        con.execute("DELETE FROM moudian_invoices WHERE id=?", (invoice_id,))
    return {"ok": True}



# ========================================================================
# PHASE 2: CLIENT PORTAL API (پرتال مشتری)
# ========================================================================
class ClientPortalUserCreateModel(BaseModel):
    company_id: str
    person_id: str | None = None
    username: str
    password: str
    display_name: str = ""
    email: str = ""
    phone: str = ""

@app.get("/api/portal/users")
def list_portal_users(request: Request, company_id: str = ""):
    user = current_user(request)
    require_perm(user, "customers.manage")
    with db() as con:
        sql = """SELECT pu.*, c.name AS company_name, p.first_name, p.last_name
                 FROM client_portal_users pu
                 LEFT JOIN companies c ON c.id=pu.company_id
                 LEFT JOIN persons p ON p.id=pu.person_id WHERE 1=1"""
        params = []
        if company_id:
            sql += " AND pu.company_id=?"
            params.append(company_id)
        sql += " ORDER BY pu.created_at DESC"
        rows = con.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

@app.post("/api/portal/users")
def create_portal_user(payload: ClientPortalUserCreateModel, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    if len(payload.password) < 4:
        raise HTTPException(400, "رمز حداقل ۴ نویسه")
    pid = uid()
    with db() as con:
        try:
            con.execute("""INSERT INTO client_portal_users
                (id, company_id, person_id, username, password_hash, display_name, email, phone, active, created_by, created_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                (pid, payload.company_id, payload.person_id, payload.username.lower(),
                 password_hash(payload.password), payload.display_name, payload.email, payload.phone,
                 1, user["id"], now()))
        except Exception as e:
            if "UNIQUE" in str(e): raise HTTPException(400, "نام کاربری تکراری")
            raise
    return {"id": pid}

@app.delete("/api/portal/users/{portal_user_id}")
def delete_portal_user(portal_user_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    with db() as con:
        con.execute("DELETE FROM client_portal_users WHERE id=?", (portal_user_id,))
    return {"ok": True}

@app.post("/api/portal/login")
def portal_login(payload: LoginModel, request: Request):
    """Login for client portal users."""
    with db() as con:
        pu = con.execute("SELECT * FROM client_portal_users WHERE username=? AND active=1", (payload.username.lower(),)).fetchone()
        if pu is None or not password_ok(payload.password, pu["password_hash"]):
            raise HTTPException(401, "نام کاربری یا رمز نادرست")
        con.execute("UPDATE client_portal_users SET last_login=? WHERE id=?", (now(), pu["id"]))
        company = con.execute("SELECT name FROM companies WHERE id=?", (pu["company_id"],)).fetchone()
        return {"ok": True, "user": {"id": pu["id"], "display_name": pu["display_name"] or pu["username"], "company_id": pu["company_id"], "company_name": company["name"] if company else ""}}

@app.get("/api/portal/invoices")
def portal_invoices(request: Request, company_id: str = ""):
    """Client portal: view their invoices."""
    with db() as con:
        rows = con.execute("""SELECT i.*, c.name AS company_name FROM invoices i
            LEFT JOIN companies c ON c.id=i.company_id
            WHERE i.company_id=? ORDER BY i.issue_date DESC""", (company_id,)).fetchall()
        return [dict(r) for r in rows]

@app.get("/api/portal/fees")
def portal_fees(request: Request, company_id: str = ""):
    """Client portal: view their fees/receivables."""
    with db() as con:
        rows = con.execute("""SELECT f.*, c.name AS company_name FROM fees f
            LEFT JOIN companies c ON c.id=f.company_id
            WHERE f.company_id=? ORDER BY f.issue_date DESC""", (company_id,)).fetchall()
        result = []
        for r in rows:
            d = dict(r)
            d["balance"] = float(d["amount"]) - float(d["paid_amount"])
            result.append(d)
        return result

@app.get("/api/portal/tax-deadlines")
def portal_tax_deadlines(request: Request, company_id: str = ""):
    """Client portal: view upcoming tax deadlines."""
    with db() as con:
        rows = con.execute("""SELECT td.* FROM tax_deadlines td
            WHERE td.company_id=? ORDER BY td.due_date ASC""", (company_id,)).fetchall()
        return [dict(r) for r in rows]


# ========================================================================
# PHASE 2: DOCUMENT MANAGEMENT API (مدیریت اسناد)
# ========================================================================
DOC_CATEGORIES = {
    'general': 'عمومی', 'contract': 'قرارداد', 'invoice': 'فاکتور',
    'tax': 'مالیاتی', 'audit': 'حسابرسی', 'bank': 'بانکی', 'other': 'سایر',
}

class DocumentUploadModel(BaseModel):
    company_id: str
    category: str = "general"
    title: str
    description: str = ""
    tags: str = ""

@app.get("/api/documents")
def list_documents(request: Request, company_id: str = "", category: str = "", q: str = ""):
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        sql = """SELECT d.*, c.name AS company_name, u.name AS uploaded_by_name
                 FROM documents d LEFT JOIN companies c ON c.id=d.company_id
                 LEFT JOIN users u ON u.id=d.uploaded_by WHERE 1=1"""
        params = []
        if company_id:
            sql += " AND d.company_id=?"
            params.append(company_id)
        if category:
            sql += " AND d.category=?"
            params.append(category)
        if q:
            sql += " AND (d.title LIKE ? OR d.description LIKE ? OR d.tags LIKE ?)"
            kw = f"%{q}%"
            params.extend([kw, kw, kw])
        sql += " ORDER BY d.uploaded_at DESC"
        rows = con.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

@app.post("/api/documents/upload")
async def upload_document(request: Request, file: UploadFile = File(...),
    company_id: str = Form(...), category: str = Form("general"),
    title: str = Form(...), description: str = Form(""), tags: str = Form("")):
    user = current_user(request)
    require_perm(user, "customers.view")
    content_bytes = await file.read(MAX_UPLOAD + 1)
    if len(content_bytes) > MAX_UPLOAD:
        raise HTTPException(413, "حجم فایل بیش از حد مجاز")
    if not file.filename:
        raise HTTPException(400, "نام فایل نامعتبر")
    doc_id = uid()
    stored_name = f"{doc_id}_{file.filename}"
    doc_dir = DATA / "documents"
    doc_dir.mkdir(parents=True, exist_ok=True)
    (doc_dir / stored_name).write_bytes(content_bytes)
    sha = hashlib.sha256(content_bytes).hexdigest()
    with db() as con:
        con.execute("""INSERT INTO documents
            (id, company_id, category, title, description, file_name, stored_name, file_size, mime_type, sha256, version, parent_id, uploaded_by, uploaded_at, tags)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (doc_id, company_id, category, title, description, file.filename, stored_name,
             len(content_bytes), file.content_type or "application/octet-stream", sha, 1, None,
             user["id"], now(), tags))
    return {"id": doc_id, "file_name": file.filename, "size": len(content_bytes)}

@app.get("/api/documents/{doc_id}/download")
def download_document(doc_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        doc = con.execute("SELECT * FROM documents WHERE id=?", (doc_id,)).fetchone()
        if not doc: raise HTTPException(404, "سند پیدا نشد")
        path = DATA / "documents" / doc["stored_name"]
        if not path.exists(): raise HTTPException(404, "فایل پیدا نشد")
        return FileResponse(str(path), filename=doc["file_name"], media_type=doc["mime_type"])

@app.delete("/api/documents/{doc_id}")
def delete_document(doc_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    with db() as con:
        doc = con.execute("SELECT * FROM documents WHERE id=?", (doc_id,)).fetchone()
        if not doc: raise HTTPException(404, "سند پیدا نشد")
        path = DATA / "documents" / doc["stored_name"]
        if path.exists(): path.unlink()
        con.execute("DELETE FROM documents WHERE id=?", (doc_id,))
    return {"ok": True}


# ========================================================================
# PHASE 2: E-SIGNATURE API (امضای الکترونیکی)
# ========================================================================
class SignatureModel(BaseModel):
    document_id: str
    signer_name: str
    signature_text: str  # typed name or base64 image

@app.get("/api/documents/{doc_id}/signatures")
def list_signatures(doc_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        rows = con.execute("SELECT * FROM document_signatures WHERE document_id=? ORDER BY signed_at DESC", (doc_id,)).fetchall()
        return [dict(r) for r in rows]

@app.post("/api/documents/{doc_id}/sign")
def sign_document(doc_id: str, payload: SignatureModel, request: Request):
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        doc = con.execute("SELECT * FROM documents WHERE id=?", (doc_id,)).fetchone()
        if not doc: raise HTTPException(404, "سند پیدا نشد")
        sig_id = uid()
        sig_hash = hashlib.sha256(f"{payload.signer_name}:{payload.signature_text}:{doc_id}:{now()}".encode()).hexdigest()
        con.execute("INSERT INTO document_signatures VALUES(?,?,?,?,?,?,?,?)",
                    (sig_id, doc_id, "internal", user["id"], payload.signer_name,
                     payload.signature_text, sig_hash, now(), request.client.host if request.client else ""))
    return {"id": sig_id, "signature_hash": sig_hash, "signed_at": now()}


# ========================================================================
# PHASE 2: RECURRING TASK TEMPLATES API (قالب‌های کار تکرارپذیر)
# ========================================================================
class TaskTemplateCreateModel(BaseModel):
    name: str
    description: str = ""
    company_id: str | None = None
    task_type: str = "ثبت اسناد"
    priority: str = "NORMAL"
    weight: int = 1
    scope: str = ""
    frequency: str = "monthly"
    day_of_month: int | None = None
    day_of_week: int | None = None
    assignee_id: str | None = None

class TaskTemplateUpdateModel(BaseModel):
    name: str | None = None
    description: str | None = None
    company_id: str | None = None
    task_type: str | None = None
    priority: str | None = None
    weight: int | None = None
    scope: str | None = None
    frequency: str | None = None
    day_of_month: int | None = None
    day_of_week: int | None = None
    assignee_id: str | None = None
    active: int | None = None

TEMPLATE_FREQUENCIES = {
    'daily': 'روزانه', 'weekly': 'هفتگی', 'monthly': 'ماهانه',
    'quarterly': 'فصلی', 'annual': 'سالانه',
}

@app.get("/api/task-templates")
def list_task_templates(request: Request, company_id: str = ""):
    user = current_user(request)
    require_perm(user, "tasks.view")
    with db() as con:
        sql = """SELECT tt.*, c.name AS company_name, u.name AS assignee_name
                 FROM task_templates tt
                 LEFT JOIN companies c ON c.id=tt.company_id
                 LEFT JOIN users u ON u.id=tt.assignee_id WHERE 1=1"""
        params = []
        if company_id:
            sql += " AND (tt.company_id=? OR tt.company_id IS NULL)"
            params.append(company_id)
        sql += " ORDER BY tt.created_at DESC"
        rows = con.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

@app.post("/api/task-templates")
def create_task_template(payload: TaskTemplateCreateModel, request: Request):
    user = current_user(request)
    require_perm(user, "tasks.create")
    tid = uid()
    ts = now()
    with db() as con:
        con.execute("""INSERT INTO task_templates
            (id, name, description, company_id, task_type, priority, weight, scope, frequency,
             day_of_month, day_of_week, assignee_id, active, created_by, created_at, updated_at, last_generated)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (tid, payload.name, payload.description, payload.company_id, payload.task_type,
             payload.priority, payload.weight, payload.scope, payload.frequency,
             payload.day_of_month, payload.day_of_week, payload.assignee_id, 1,
             user["id"], ts, ts, None))
    return {"id": tid}

@app.patch("/api/task-templates/{template_id}")
def update_task_template(template_id: str, payload: TaskTemplateUpdateModel, request: Request):
    user = current_user(request)
    require_perm(user, "tasks.create")
    with db() as con:
        existing = con.execute("SELECT * FROM task_templates WHERE id=?", (template_id,)).fetchone()
        if not existing: raise HTTPException(404, "قالب پیدا نشد")
        updates = []
        params = []
        for k, v in payload.model_dump(exclude_unset=True).items():
            if v is None: continue
            updates.append(f"{k}=?")
            params.append(v)
        if not updates: return {"ok": True, "updated": 0}
        updates.append("updated_at=?")
        params.append(now())
        params.append(template_id)
        con.execute(f"UPDATE task_templates SET {', '.join(updates)} WHERE id=?", params)
    return {"ok": True, "updated": len(updates)-1}

@app.delete("/api/task-templates/{template_id}")
def delete_task_template(template_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "tasks.create")
    with db() as con:
        con.execute("DELETE FROM task_templates WHERE id=?", (template_id,))
    return {"ok": True}

@app.post("/api/task-templates/{template_id}/generate")
def generate_task_from_template(template_id: str, request: Request):
    """Manually generate a task from a template."""
    user = current_user(request)
    require_perm(user, "tasks.create")
    with db() as con:
        template = con.execute("SELECT * FROM task_templates WHERE id=? AND active=1", (template_id,)).fetchone()
        if not template: raise HTTPException(404, "قالب پیدا نشد یا غیرفعال است")
        if not template["company_id"]:
            raise HTTPException(400, "این قالب برای همه شرکت‌هاست — شرکت خاصی را انتخاب کنید")
        if not template["assignee_id"]:
            raise HTTPException(400, "قالب فاقد مسئول است")
        task_id = uid()
        ts = now()
        # Calculate due date based on frequency
        from datetime import timedelta
        due = (datetime.now() + timedelta(days={'daily':1,'weekly':7,'monthly':30,'quarterly':90,'annual':365}.get(template["frequency"], 30))).isoformat()
        con.execute("""INSERT INTO tasks
            (id, company_id, title, description, fiscal_period, scope, priority, weight,
             due_date, status, progress, parent_task_id, reference_version_id,
             assignee_id, created_by, created_at, updated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (task_id, template["company_id"], template["name"], template["description"],
             '', template["scope"], template["priority"], template["weight"],
             due, 'ASSIGNED', 0, None, None,
             template["assignee_id"], user["id"], ts, ts))
        con.execute("UPDATE task_templates SET last_generated=? WHERE id=?", (ts, template_id))
    return {"id": task_id, "due_date": due}


# ========================================================================
# PHASE 3: ADVANCED DASHBOARD (داشبورد پیشرفته)
# ========================================================================
@app.get("/api/dashboard/advanced")
def advanced_dashboard(request: Request):
    """Advanced dashboard with financial trends, revenue forecast, workload analysis."""
    user = current_user(request)
    require_perm(user, "dashboard.view")
    with db() as con:
        # Revenue trend (last 6 months from fees)
        revenue_rows = con.execute("""SELECT
            strftime('%Y-%m', issue_date) AS month,
            SUM(amount) AS total_billed,
            SUM(paid_amount) AS total_paid
            FROM fees WHERE status!='CANCELLED' AND issue_date >= date('now', '-6 months')
            GROUP BY month ORDER BY month DESC LIMIT 6""").fetchall()
        revenue_trend = [dict(r) for r in revenue_rows]

        # Outstanding by company
        outstanding_rows = con.execute("""SELECT
            c.name AS company_name,
            COUNT(f.id) AS fee_count,
            SUM(f.amount - f.paid_amount) AS outstanding
            FROM fees f JOIN companies c ON c.id=f.company_id
            WHERE f.status IN ('UNPAID','PARTIAL','OVERDUE')
            GROUP BY c.id ORDER BY outstanding DESC LIMIT 10""").fetchall()
        outstanding_by_company = [dict(r) for r in outstanding_rows]

        # Tax deadline summary
        today = now()[:10]
        upcoming_tax = con.execute("""SELECT COUNT(*) FROM tax_deadlines
            WHERE status='PENDING' AND due_date >= ?""", (today,)).fetchone()[0]
        overdue_tax = con.execute("""SELECT COUNT(*) FROM tax_deadlines
            WHERE status='PENDING' AND due_date < ?""", (today,)).fetchone()[0]

        # Task workload per employee
        workload = con.execute("""SELECT
            u.name AS employee_name,
            COUNT(t.id) AS total_tasks,
            SUM(CASE WHEN t.status='ASSIGNED' THEN 1 ELSE 0 END) AS assigned,
            SUM(CASE WHEN t.status IN ('SUBMITTED','NEEDS_REVIEW') THEN 1 ELSE 0 END) AS in_review,
            SUM(CASE WHEN t.status IN ('APPROVED','APPROVED_WITH_EXCEPTION') THEN 1 ELSE 0 END) AS completed,
            SUM(CASE WHEN t.due_date < ? AND t.status NOT IN ('APPROVED','APPROVED_WITH_EXCEPTION','CANCELLED') THEN 1 ELSE 0 END) AS overdue
            FROM users u LEFT JOIN tasks t ON t.assignee_id=u.id
            WHERE u.active=1 AND u.role='EMPLOYEE'
            GROUP BY u.id ORDER BY total_tasks DESC""", (today,)).fetchall()
        task_workload = [dict(r) for r in workload]

        # Moudian summary
        moudian_stats = con.execute("""SELECT
            COUNT(*) AS total,
            SUM(CASE WHEN status='DRAFT' THEN 1 ELSE 0 END) AS draft,
            SUM(CASE WHEN status='SENT' THEN 1 ELSE 0 END) AS sent,
            SUM(CASE WHEN status='ACCEPTED' THEN 1 ELSE 0 END) AS accepted,
            SUM(CASE WHEN status='REJECTED' THEN 1 ELSE 0 END) AS rejected,
            SUM(payable_amount) AS total_payable
            FROM moudian_invoices""").fetchone()
        moudian_summary = dict(moudian_stats) if moudian_stats else {}

        # Company distribution
        company_count = con.execute("SELECT COUNT(*) FROM companies WHERE active=1").fetchone()[0]
        person_count = con.execute("SELECT COUNT(*) FROM persons WHERE active=1").fetchone()[0]
        contract_active = con.execute("SELECT COUNT(*) FROM contracts WHERE status='ACTIVE'").fetchone()[0]

        # Monthly forecast (simple: average of last 3 months * 1.1)
        recent_revenue = revenue_rows[:3] if len(revenue_rows) >= 3 else revenue_rows
        avg_revenue = sum(float(r["total_billed"]) for r in recent_revenue) / max(len(recent_revenue), 1)
        forecast = avg_revenue * 1.1

        return {
            "revenue_trend": revenue_trend,
            "outstanding_by_company": outstanding_by_company,
            "tax_summary": {"upcoming": upcoming_tax, "overdue": overdue_tax},
            "task_workload": task_workload,
            "moudian_summary": moudian_summary,
            "company_count": company_count,
            "person_count": person_count,
            "contract_active": contract_active,
            "forecast_next_month": round(forecast, 0),
        }


# ========================================================================
# PHASE 3: PWA + PUSH NOTIFICATIONS
# ========================================================================
import json as _json

@app.get("/api/notifications/unread-count")
def unread_notification_count(request: Request):
    """Returns count of unread notifications for the current user."""
    user = current_user(request)
    with db() as con:
        count = con.execute("SELECT COUNT(*) FROM notifications WHERE user_id=? AND read_at IS NULL", (user["id"],)).fetchone()[0]
        return {"unread": count}

@app.post("/api/notifications/{notif_id}/read")
def mark_notification_read(notif_id: str, request: Request):
    """Mark a single notification as read."""
    user = current_user(request)
    with db() as con:
        con.execute("UPDATE notifications SET read_at=? WHERE id=? AND user_id=?", (now(), notif_id, user["id"]))
    return {"ok": True}

@app.post("/api/notifications/mark-all-read")
def mark_all_notifications_read(request: Request):
    """Mark all notifications as read for current user."""
    user = current_user(request)
    with db() as con:
        con.execute("UPDATE notifications SET read_at=? WHERE user_id=? AND read_at IS NULL", (now(), user["id"]))
    return {"ok": True}

@app.get("/api/notifications/recent")
def recent_notifications(request: Request, limit: int = 20):
    """Returns recent notifications with read status."""
    user = current_user(request)
    with db() as con:
        rows = con.execute("""SELECT n.*, CASE WHEN n.read_at IS NOT NULL THEN 1 ELSE 0 END AS is_read
            FROM notifications n WHERE n.user_id=?
            ORDER BY n.created_at DESC LIMIT ?""", (user["id"], limit)).fetchall()
        return [dict(r) for r in rows]


# ========================================================================
# PHASE 3: CALENDAR SYNC (تقویم)
# ========================================================================
@app.get("/api/calendar/events")
def calendar_events(request: Request, company_id: str = "", start: str = "", end: str = ""):
    """Returns calendar events (tax deadlines, task due dates, contract dates) in iCal-like format."""
    user = current_user(request)
    require_perm(user, "dashboard.view")
    events = []
    with db() as con:
        # Tax deadlines
        td_sql = "SELECT * FROM tax_deadlines WHERE status='PENDING'"
        td_params = []
        if company_id:
            td_sql += " AND company_id=?"
            td_params.append(company_id)
        if start:
            td_sql += " AND due_date >= ?"
            td_params.append(start)
        if end:
            td_sql += " AND due_date <= ?"
            td_params.append(end)
        td_rows = con.execute(td_sql, td_params).fetchall()
        for td in td_rows:
            comp = con.execute("SELECT name FROM companies WHERE id=?", (td["company_id"],)).fetchone()
            events.append({
                "id": f"tax_{td['id']}",
                "type": "tax_deadline",
                "title": f"📅 {td['title']}",
                "date": td["due_date"],
                "company": comp["name"] if comp else "",
                "status": td["status"],
            })
        # Task due dates
        task_sql = "SELECT t.*, c.name AS company_name FROM tasks t LEFT JOIN companies c ON c.id=t.company_id WHERE t.status NOT IN ('APPROVED','APPROVED_WITH_EXCEPTION','CANCELLED')"
        task_params = []
        if company_id:
            task_sql += " AND t.company_id=?"
            task_params.append(company_id)
        if start:
            task_sql += " AND t.due_date >= ?"
            task_params.append(start)
        if end:
            task_sql += " AND t.due_date <= ?"
            task_params.append(end)
        task_rows = con.execute(task_sql, task_params).fetchall()
        for t in task_rows:
            events.append({
                "id": f"task_{t['id']}",
                "type": "task_due",
                "title": f"✓ {t['title']}",
                "date": t["due_date"],
                "company": t["company_name"] or "",
                "status": t["status"],
            })
        # Contract end dates
        contract_rows = con.execute("SELECT * FROM contracts WHERE status='ACTIVE' AND end_date >= ?", (start or "2000-01-01",)).fetchall()
        for c in contract_rows:
            if company_id and c["company_id"] != company_id:
                continue
            events.append({
                "id": f"contract_{c['id']}",
                "type": "contract_end",
                "title": f"📜 پایان قرارداد: {c['title']}",
                "date": c["end_date"],
                "status": "ACTIVE",
            })
    events.sort(key=lambda e: e.get("date") or "")
    return events

@app.get("/api/calendar/export")
def calendar_export(request: Request, company_id: str = ""):
    """Export calendar as iCal (.ics) format."""
    user = current_user(request)
    require_perm(user, "dashboard.view")
    events = calendar_events(request, company_id)
    ics_lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//YFG Accounting Desk//Calendar//FA",
                 "CALSCALE:GREGORIAN", "METHOD:PUBLISH"]
    for e in events:
        date_str = e.get("date", "")
        if not date_str or len(date_str) < 10:
            continue
        d = date_str[:10].replace("-", "")
        uid_ics = e.get("id", "")
        title = e.get("title", "").replace(",", "\\,").replace(";", "\\;").replace("\n", "\\n")
        ics_lines.extend([
            "BEGIN:VEVENT",
            f"UID:{uid_ics}@yfg-desk",
            f"DTSTART;VALUE=DATE:{d}",
            f"DTEND;VALUE=DATE:{d}",
            f"SUMMARY:{title}",
            f"DESCRIPTION:نوع: {e.get('type','')} - شرکت: {e.get('company','')}",
            "END:VEVENT",
        ])
    ics_lines.append("END:VCALENDAR")
    from fastapi.responses import PlainTextResponse
    return PlainTextResponse("\r\n".join(ics_lines), media_type="text/calendar", headers={"Content-Disposition": "attachment; filename=yfg-calendar.ics"})


# ========================================================================
# PHASE 3: ENHANCED NOTIFICATIONS (نوتیفیکیشن چندکاناله)
# ========================================================================
class NotificationPreferenceModel(BaseModel):
    channel: str  # in_app, email, push
    enabled: bool = True
    categories: list[str] = []  # which notification types to receive

@app.get("/api/notifications/preferences")
def get_notification_preferences(request: Request):
    """Get notification preferences for current user."""
    user = current_user(request)
    # Return defaults if not stored
    return {
        "in_app": True,
        "email": False,
        "push": False,
        "categories": ["task", "request", "chat", "deadline", "system"],
    }

@app.post("/api/notifications/send")
def send_custom_notification(request: Request, title: str = "", body: str = "", target_user_id: str = ""):
    """Send a notification to a specific user (admin only)."""
    user = current_user(request)
    if user["role"] not in ("ADMIN", "CEO"):
        raise HTTPException(403, "فقط مدیر می‌تواند اعلان ارسال کند")
    if not title or not target_user_id:
        raise HTTPException(400, "عنوان و کاربر هدف الزامی است")
    with db() as con:
        notify(con, target_user_id, title, body)
    return {"ok": True}


# ========================================================================
# PHASE 4: PUBLIC API + WEBHOOKS (API عمومی)
# ========================================================================
from fastapi import Header

API_KEYS_TABLE = """CREATE TABLE IF NOT EXISTS api_keys(
 id TEXT PRIMARY KEY,
 key_hash TEXT NOT NULL UNIQUE,
 name TEXT NOT NULL,
 user_id TEXT NOT NULL REFERENCES users(id),
 scopes TEXT NOT NULL DEFAULT 'read',
 active INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL,
 last_used TEXT
);"""

# Add to DB
with db() as con:
    con.executescript(API_KEYS_TABLE)

WEBHOOKS_TABLE = """CREATE TABLE IF NOT EXISTS webhooks(
 id TEXT PRIMARY KEY,
 url TEXT NOT NULL,
 event_type TEXT NOT NULL,
 active INTEGER NOT NULL DEFAULT 1,
 secret TEXT NOT NULL DEFAULT '',
 created_by TEXT NOT NULL REFERENCES users(id),
 created_at TEXT NOT NULL
);"""

with db() as con:
    con.executescript(WEBHOOKS_TABLE)

class APIKeyCreateModel(BaseModel):
    name: str
    scopes: str = "read"

@app.get("/api/api-keys")
def list_api_keys(request: Request):
    user = current_user(request)
    if user["role"] != "ADMIN": raise HTTPException(403, "فقط مدیر")
    with db() as con:
        rows = con.execute("SELECT id, name, scopes, active, created_at, last_used FROM api_keys WHERE user_id=?", (user["id"],)).fetchall()
        return [dict(r) for r in rows]

@app.post("/api/api-keys")
def create_api_key(payload: APIKeyCreateModel, request: Request):
    user = current_user(request)
    if user["role"] != "ADMIN": raise HTTPException(403, "فقط مدیر")
    raw_key = secrets.token_urlsafe(32)
    key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
    kid = uid()
    with db() as con:
        con.execute("INSERT INTO api_keys VALUES(?,?,?,?,?,?,?,?)",
                    (kid, key_hash, payload.name, user["id"], payload.scopes, 1, now(), None))
    return {"id": kid, "key": raw_key, "name": payload.name}

@app.delete("/api/api-keys/{key_id}")
def revoke_api_key(key_id: str, request: Request):
    user = current_user(request)
    if user["role"] != "ADMIN": raise HTTPException(403, "فقط مدیر")
    with db() as con:
        con.execute("DELETE FROM api_keys WHERE id=? AND user_id=?", (key_id, user["id"]))
    return {"ok": True}

@app.get("/api/public/status")
def public_api_status(x_api_key: str = Header(default="")):
    """Public API endpoint — requires API key."""
    if not x_api_key:
        raise HTTPException(401, "API key required")
    key_hash = hashlib.sha256(x_api_key.encode()).hexdigest()
    with db() as con:
        key_row = con.execute("SELECT * FROM api_keys WHERE key_hash=? AND active=1", (key_hash,)).fetchone()
        if not key_row: raise HTTPException(401, "Invalid API key")
        con.execute("UPDATE api_keys SET last_used=? WHERE id=?", (now(), key_row["id"]))
        return {"status": "ok", "version": SYSTEM_VERSION, "scopes": key_row["scopes"]}

@app.get("/api/public/companies")
def public_list_companies(x_api_key: str = Header(default="")):
    """Public API — list companies."""
    key_hash = hashlib.sha256(x_api_key.encode()).hexdigest()
    with db() as con:
        key_row = con.execute("SELECT * FROM api_keys WHERE key_hash=? AND active=1", (key_hash,)).fetchone()
        if not key_row: raise HTTPException(401, "Invalid API key")
        if "read" not in key_row["scopes"] and "all" not in key_row["scopes"]:
            raise HTTPException(403, "Insufficient scope")
        rows = con.execute("SELECT id, code, name, kind, national_id, phone, active FROM companies ORDER BY name").fetchall()
        return [dict(r) for r in rows]

@app.get("/api/public/invoices")
def public_list_invoices(x_api_key: str = Header(default=""), company_id: str = ""):
    """Public API — list invoices."""
    key_hash = hashlib.sha256(x_api_key.encode()).hexdigest()
    with db() as con:
        key_row = con.execute("SELECT * FROM api_keys WHERE key_hash=? AND active=1", (key_hash,)).fetchone()
        if not key_row: raise HTTPException(401, "Invalid API key")
        if "read" not in key_row["scopes"] and "all" not in key_row["scopes"]:
            raise HTTPException(403, "Insufficient scope")
        sql = "SELECT i.id, i.code, i.title, i.issue_date, i.due_date, i.status, i.total_amount, i.paid_amount, c.name AS company_name FROM invoices i LEFT JOIN companies c ON c.id=i.company_id WHERE 1=1"
        params = []
        if company_id:
            sql += " AND i.company_id=?"
            params.append(company_id)
        sql += " ORDER BY i.issue_date DESC LIMIT 100"
        rows = con.execute(sql, params).fetchall()
        return [dict(r) for r in rows]


# ========================================================================
# PHASE 4: WEBHOOKS
# ========================================================================
class WebhookCreateModel(BaseModel):
    url: str
    event_type: str  # task.created, task.approved, invoice.created, fee.paid, etc.
    secret: str = ""

@app.get("/api/webhooks")
def list_webhooks(request: Request):
    user = current_user(request)
    if user["role"] != "ADMIN": raise HTTPException(403, "فقط مدیر")
    with db() as con:
        rows = con.execute("SELECT * FROM webhooks WHERE created_by=?", (user["id"],)).fetchall()
        return [dict(r) for r in rows]

@app.post("/api/webhooks")
def create_webhook(payload: WebhookCreateModel, request: Request):
    user = current_user(request)
    if user["role"] != "ADMIN": raise HTTPException(403, "فقط مدیر")
    wid = uid()
    with db() as con:
        con.execute("INSERT INTO webhooks VALUES(?,?,?,?,?,?,?)",
                    (wid, payload.url, payload.event_type, 1, payload.secret, user["id"], now()))
    return {"id": wid}

@app.delete("/api/webhooks/{webhook_id}")
def delete_webhook(webhook_id: str, request: Request):
    user = current_user(request)
    if user["role"] != "ADMIN": raise HTTPException(403, "فقط مدیر")
    with db() as con:
        con.execute("DELETE FROM webhooks WHERE id=?", (webhook_id,))
    return {"ok": True}

def fire_webhook(con, event_type: str, payload: dict):
    """Fire webhooks matching the event type."""
    import urllib.request
    webhooks = con.execute("SELECT * FROM webhooks WHERE event_type=? AND active=1", (event_type,)).fetchall()
    for wh in webhooks:
        try:
            data = json.dumps({"event": event_type, "data": payload, "timestamp": now()}, ensure_ascii=False).encode()
            req = urllib.request.Request(wh["url"], data=data, headers={"Content-Type": "application/json"})
            if wh["secret"]:
                req.add_header("X-Webhook-Secret", wh["secret"])
            urllib.request.urlopen(req, timeout=5)
        except Exception:
            pass  # webhook failures are silent


# ========================================================================
# PHASE 4: OCR PLACEHOLDER (خواندن خودکار فاکتور)
# ========================================================================
@app.post("/api/ocr/parse-invoice")
async def ocr_parse_invoice(request: Request, file: UploadFile = File(...)):
    """Upload an image/PDF of an invoice and extract data (mock OCR)."""
    user = current_user(request)
    require_perm(user, "customers.manage")
    content = await file.read(5 * 1024 * 1024)  # 5MB max
    if not file.filename:
        raise HTTPException(400, "فایل نامعتبر")
    # Mock OCR — in production, integrate with Tesseract or cloud OCR
    return {
        "ok": True,
        "filename": file.filename,
        "size": len(content),
        "extracted": {
            "invoice_number": None,
            "date": None,
            "total": None,
            "seller_name": None,
            "buyer_name": None,
            "items": [],
        },
        "message": "OCR در حالت شبیه‌سازی است. برای فعال‌سازی واقعی، به سرویس OCR (Tesseract/Google Vision/Azure) متصل شود.",
    }


# ========================================================================
# PHASE 5: DOCUMENT REQUEST LIST (درخواست سند ساختاریافته)
# ========================================================================
# New table for structured document requests from clients
DOC_REQUEST_SCHEMA = """CREATE TABLE IF NOT EXISTS document_requests(
 id TEXT PRIMARY KEY,
 company_id TEXT NOT NULL REFERENCES companies(id),
 title TEXT NOT NULL,
 description TEXT NOT NULL DEFAULT '',
 status TEXT NOT NULL DEFAULT 'OPEN', -- OPEN, PARTIAL, COMPLETED, CANCELLED
 due_date TEXT,
 created_by TEXT NOT NULL REFERENCES users(id),
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS document_request_items(
 id TEXT PRIMARY KEY,
 request_id TEXT NOT NULL REFERENCES document_requests(id),
 document_name TEXT NOT NULL,
 description TEXT NOT NULL DEFAULT '',
 required INTEGER NOT NULL DEFAULT 1,
 status TEXT NOT NULL DEFAULT 'PENDING', -- PENDING, UPLOADED, REJECTED, APPROVED
 uploaded_file TEXT, -- path to uploaded file
 uploaded_at TEXT,
 uploaded_by_portal TEXT, -- portal user id if uploaded via portal
 notes TEXT NOT NULL DEFAULT '',
 created_at TEXT NOT NULL
);"""

with db() as con:
    con.executescript(DOC_REQUEST_SCHEMA)

class DocRequestCreateModel(BaseModel):
    company_id: str
    title: str
    description: str = ""
    due_date: str | None = None
    items: list[dict] = []  # [{document_name, description, required}]

class DocRequestItemUpdateModel(BaseModel):
    status: str | None = None
    notes: str | None = None

@app.get("/api/document-requests")
def list_document_requests(request: Request, company_id: str = "", status: str = ""):
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        sql = """SELECT dr.*, c.name AS company_name,
                 (SELECT COUNT(*) FROM document_request_items WHERE request_id=dr.id) AS total_items,
                 (SELECT COUNT(*) FROM document_request_items WHERE request_id=dr.id AND status='UPLOADED') AS uploaded_items
                 FROM document_requests dr LEFT JOIN companies c ON c.id=dr.company_id WHERE 1=1"""
        params = []
        if company_id:
            sql += " AND dr.company_id=?"
            params.append(company_id)
        if status:
            sql += " AND dr.status=?"
            params.append(status)
        sql += " ORDER BY dr.created_at DESC"
        rows = con.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

@app.post("/api/document-requests")
def create_document_request(payload: DocRequestCreateModel, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    rid = uid()
    ts = now()
    with db() as con:
        con.execute("INSERT INTO document_requests VALUES(?,?,?,?,?,?,?,?)",
                    (rid, payload.company_id, payload.title, payload.description, 'OPEN',
                     payload.due_date, user["id"], ts, ts))
        for item in payload.items:
            if isinstance(item, dict) and item.get("document_name"):
                con.execute("INSERT INTO document_request_items VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                            (uid(), rid, item["document_name"], item.get("description",""),
                             1 if item.get("required", True) else 0, 'PENDING', None, None, None, "", ts))
    return {"id": rid}

@app.get("/api/document-requests/{request_id}")
def get_document_request(request_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        dr = con.execute("SELECT * FROM document_requests WHERE id=?", (request_id,)).fetchone()
        if not dr: raise HTTPException(404, "درخواست پیدا نشد")
        items = con.execute("SELECT * FROM document_request_items WHERE request_id=?", (request_id,)).fetchall()
        d = dict(dr)
        d["items"] = [dict(i) for i in items]
        return d

@app.patch("/api/document-request-items/{item_id}")
def update_doc_request_item(item_id: str, payload: DocRequestItemUpdateModel, request: Request):
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        existing = con.execute("SELECT * FROM document_request_items WHERE id=?", (item_id,)).fetchone()
        if not existing: raise HTTPException(404, "مورد پیدا نشد")
        updates = []
        params = []
        for k, v in payload.model_dump(exclude_unset=True).items():
            if v is None: continue
            updates.append(f"{k}=?")
            params.append(v)
        if updates:
            params.append(item_id)
            con.execute(f"UPDATE document_request_items SET {', '.join(updates)} WHERE id=?", params)
    return {"ok": True}

@app.delete("/api/document-requests/{request_id}")
def delete_document_request(request_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    with db() as con:
        con.execute("DELETE FROM document_request_items WHERE request_id=?", (request_id,))
        con.execute("DELETE FROM document_requests WHERE id=?", (request_id,))
    return {"ok": True}


# ========================================================================
# PHASE 5: KIOSK MODE (کیوسک دفتر — امضای حضوری روی تبلت)
# ========================================================================
class KioskSignModel(BaseModel):
    company_id: str
    document_title: str
    signer_name: str
    signature_data: str  # base64 image or typed text
    signer_type: str = "client"  # client, visitor

@app.post("/api/kiosk/sign")
def kiosk_sign(payload: KioskSignModel, request: Request):
    """Kiosk mode: quick sign without login. Used on a tablet in the office."""
    # No auth required — kiosk is a physical device in the office
    sig_id = uid()
    sig_hash = hashlib.sha256(f"{payload.signer_name}:{payload.signature_data}:{payload.company_id}:{now()}".encode()).hexdigest()
    with db() as con:
        # Store as a document signature
        con.execute("""INSERT INTO documents (id, company_id, category, title, description, file_name, stored_name, file_size, mime_type, sha256, version, parent_id, uploaded_by, uploaded_at, tags)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (uid(), payload.company_id, 'other', payload.document_title, f'کیوسک - امضا: {payload.signer_name}',
             'kiosk_signature.txt', 'kiosk_' + sig_id + '.txt', len(payload.signature_data),
             'text/plain', sig_hash, 1, None, 'kiosk', now(), 'kiosk'))
    return {"ok": True, "signature_id": sig_id, "hash": sig_hash, "signed_at": now()}

@app.get("/api/kiosk/companies")
def kiosk_companies():
    """Kiosk: list active companies for the sign screen."""
    with db() as con:
        rows = con.execute("SELECT id, name FROM companies WHERE active=1 ORDER BY name").fetchall()
        return [dict(r) for r in rows]


# ========================================================================
# PHASE 5: PROPOSALS + AUTO-PAYMENT (پیشنهاد و دریافت‌وجه خودکار)
# ========================================================================
PROPOSAL_SCHEMA = """CREATE TABLE IF NOT EXISTS proposals(
 id TEXT PRIMARY KEY,
 company_id TEXT NOT NULL REFERENCES companies(id),
 title TEXT NOT NULL,
 description TEXT NOT NULL DEFAULT '',
 total_amount REAL NOT NULL DEFAULT 0,
 currency TEXT NOT NULL DEFAULT 'IRR',
 status TEXT NOT NULL DEFAULT 'DRAFT', -- DRAFT, SENT, ACCEPTED, REJECTED, EXPIRED
 items_json TEXT NOT NULL DEFAULT '[]',
 valid_until TEXT,
 accepted_at TEXT,
 accepted_by TEXT,
 created_by TEXT NOT NULL REFERENCES users(id),
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL
);"""

with db() as con:
    con.executescript(PROPOSAL_SCHEMA)

class ProposalCreateModel(BaseModel):
    company_id: str
    title: str
    description: str = ""
    total_amount: float = 0
    currency: str = "IRR"
    items: list[dict] = []
    valid_until: str | None = None

@app.get("/api/proposals")
def list_proposals(request: Request, company_id: str = "", status: str = ""):
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        sql = """SELECT p.*, c.name AS company_name FROM proposals p
                 LEFT JOIN companies c ON c.id=p.company_id WHERE 1=1"""
        params = []
        if company_id:
            sql += " AND p.company_id=?"
            params.append(company_id)
        if status:
            sql += " AND p.status=?"
            params.append(status)
        sql += " ORDER BY p.created_at DESC"
        rows = con.execute(sql, params).fetchall()
        result = []
        for r in rows:
            d = dict(r)
            try: d["items"] = json.loads(r["items_json"])
            except: d["items"] = []
            del d["items_json"]
            result.append(d)
        return result

@app.post("/api/proposals")
def create_proposal(payload: ProposalCreateModel, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    pid = uid()
    ts = now()
    items_json = json.dumps(payload.items, ensure_ascii=False) if payload.items else "[]"
    with db() as con:
        con.execute("""INSERT INTO proposals
            (id, company_id, title, description, total_amount, currency, status, items_json, valid_until, created_by, created_at, updated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
            (pid, payload.company_id, payload.title, payload.description, payload.total_amount,
             payload.currency, 'DRAFT', items_json, payload.valid_until, user["id"], ts, ts))
    return {"id": pid}

@app.patch("/api/proposals/{proposal_id}")
def update_proposal(proposal_id: str, request: Request, status: str = ""):
    user = current_user(request)
    require_perm(user, "customers.manage")
    with db() as con:
        existing = con.execute("SELECT * FROM proposals WHERE id=?", (proposal_id,)).fetchone()
        if not existing: raise HTTPException(404, "پیشنهاد پیدا نشد")
        if status:
            updates = ["status=?", "updated_at=?"]
            params = [status, now()]
            if status == 'ACCEPTED':
                updates.extend(["accepted_at=?", "accepted_by=?"])
                params.extend([now(), user["id"]])
                # Auto-create a fee when proposal is accepted
                con.execute("""INSERT INTO fees
                    (id, company_id, contract_id, title, fee_type, amount, currency, period_start, period_end,
                     issue_date, due_date, status, paid_amount, paid_date, notes, created_by, created_at, updated_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (uid(), existing["company_id"], None, f"پیشنهاد: {existing['title']}",
                     'one_time', existing["total_amount"], existing["currency"],
                     None, None, now()[:10], None, 'UNPAID', 0, None, 'از پیشنهاد',
                     user["id"], now(), now()))
            params.append(proposal_id)
            con.execute(f"UPDATE proposals SET {', '.join(updates)} WHERE id=?", params)
    return {"ok": True}

@app.delete("/api/proposals/{proposal_id}")
def delete_proposal(proposal_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    with db() as con:
        con.execute("DELETE FROM proposals WHERE id=?", (proposal_id,))
    return {"ok": True}


# ========================================================================
# PHASE 5: REAL MOUDIAN INTEGRATION (اتصال واقعی به سامانه مودیان)
# ========================================================================
MOUDIAN_CONFIG_SCHEMA = """CREATE TABLE IF NOT EXISTS moudian_config(
 id TEXT PRIMARY KEY,
 company_id TEXT NOT NULL REFERENCES companies(id),
 base_url TEXT NOT NULL DEFAULT 'https://api.tax.gov.ir',
 client_id TEXT NOT NULL,
 client_secret TEXT NOT NULL,
 username TEXT NOT NULL,
 password_encrypted TEXT NOT NULL,
 tax_id TEXT NOT NULL, -- شناسه مالیاتی
 token TEXT,
 token_expires TEXT,
 created_by TEXT NOT NULL REFERENCES users(id),
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL,
 UNIQUE(company_id)
);"""

with db() as con:
    con.executescript(MOUDIAN_CONFIG_SCHEMA)

class MoudianConfigModel(BaseModel):
    company_id: str
    base_url: str = "https://api.tax.gov.ir"
    client_id: str
    client_secret: str
    username: str
    password: str
    tax_id: str

@app.get("/api/moudian/config/{company_id}")
def get_moudian_config(company_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.moudian")
    with db() as con:
        row = con.execute("SELECT * FROM moudian_config WHERE company_id=?", (company_id,)).fetchone()
        if not row: return {"configured": False}
        d = dict(row)
        d["configured"] = True
        d["client_secret"] = "***"  # don't expose secret
        return d

@app.post("/api/moudian/config")
def set_moudian_config(payload: MoudianConfigModel, request: Request):
    user = current_user(request)
    require_perm(user, "customers.moudian")
    cid = uid()
    ts = now()
    # Simple encryption (in production, use proper encryption)
    import base64
    pwd_enc = base64.b64encode(payload.password.encode()).decode()
    with db() as con:
        existing = con.execute("SELECT id FROM moudian_config WHERE company_id=?", (payload.company_id,)).fetchone()
        if existing:
            con.execute("""UPDATE moudian_config SET base_url=?, client_id=?, client_secret=?, username=?, password_encrypted=?, tax_id=?, updated_at=? WHERE company_id=?""",
                        (payload.base_url, payload.client_id, payload.client_secret, payload.username, pwd_enc, payload.tax_id, ts, payload.company_id))
        else:
            con.execute("""INSERT INTO moudian_config VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                        (cid, payload.company_id, payload.base_url, payload.client_id, payload.client_secret,
                         payload.username, pwd_enc, payload.tax_id, None, None, user["id"], ts, ts, ts))
    return {"ok": True}

@app.post("/api/moudian/real-submit/{invoice_id}")
def moudian_real_submit(invoice_id: str, request: Request):
    """Real submission to Moudian API (if configured). Falls back to mock if not."""
    user = current_user(request)
    require_perm(user, "customers.moudian")
    with db() as con:
        inv = con.execute("SELECT * FROM moudian_invoices WHERE id=?", (invoice_id,)).fetchone()
        if not inv: raise HTTPException(404, "فاکتور پیدا نشد")
        config = con.execute("SELECT * FROM moudian_config WHERE company_id=?", (inv["company_id"],)).fetchone()

        if not config:
            # Fall back to mock
            ref_id = f"MOU-{uid()[:12].upper()}"
            con.execute("UPDATE moudian_invoices SET status='SENT', reference_id=?, submitted_at=?, updated_at=? WHERE id=?",
                        (ref_id, now(), now(), invoice_id))
            return {"ok": True, "reference_id": ref_id, "mode": "mock", "message": "شبیه‌سازی (تنظیمات مودیان موجود نیست)"}

        # Real API call attempt
        try:
            import urllib.request
            # Step 1: Get token
            token_url = f"{config['base_url']}/api/v1/auth/token"
            token_data = json.dumps({
                "client_id": config["client_id"],
                "client_secret": config["client_secret"],
                "username": config["username"],
                "password": base64.b64decode(config["password_encrypted"]).decode(),
                "grant_type": "password"
            }).encode()
            req = urllib.request.Request(token_url, data=token_data, headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=15) as resp:
                token_resp = json.loads(resp.read())
                token = token_resp.get("access_token")

            if not token:
                raise Exception("Token not received")

            # Step 2: Submit invoice
            submit_url = f"{config['base_url']}/api/v1/invoices/submit"
            items = json.loads(inv["items_json"]) if inv["items_json"] else []
            invoice_data = {
                "invoice_number": inv["invoice_number"] or "",
                "invoice_type": inv["invoice_type"],
                "buyer_tin": inv["buyer_tin"],
                "buyer_name": inv["buyer_name"],
                "seller_tin": inv["seller_tin"],
                "seller_name": inv["seller_name"],
                "issue_date": inv["issue_date"],
                "total_amount": inv["total_amount"],
                "tax_amount": inv["tax_amount"],
                "discount_amount": inv["discount_amount"],
                "payable_amount": inv["payable_amount"],
                "items": items,
            }
            req2 = urllib.request.Request(submit_url, data=json.dumps(invoice_data).encode(),
                                           headers={"Content-Type": "application/json", "Authorization": f"Bearer {token}"})
            with urllib.request.urlopen(req2, timeout=15) as resp2:
                submit_resp = json.loads(resp2.read())
                ref_id = submit_resp.get("reference_id", f"MOU-{uid()[:12].upper()}")

            con.execute("UPDATE moudian_invoices SET status='SENT', reference_id=?, submitted_at=?, updated_at=? WHERE id=?",
                        (ref_id, now(), now(), invoice_id))
            return {"ok": True, "reference_id": ref_id, "mode": "real", "message": "ارسال واقعی به سامانه مودیان انجام شد"}
        except Exception as e:
            con.execute("UPDATE moudian_invoices SET status='REJECTED', error_message=?, updated_at=? WHERE id=?",
                        (str(e)[:500], now(), invoice_id))
            return {"ok": False, "mode": "real", "error": f"خطا در ارسال به مودیان: {e}"}


# ========================================================================
# PHASE 5: ACCOUNTING SOFTWARE INTEGRATION (اتصال به هلو/سپیدار)
# ========================================================================
INTEGRATION_SCHEMA = """CREATE TABLE IF NOT EXISTS accounting_integrations(
 id TEXT PRIMARY KEY,
 company_id TEXT NOT NULL REFERENCES companies(id),
 software TEXT NOT NULL, -- holoo, sepidar, parsiyan, paydar, nosa, other
 import_type TEXT NOT NULL DEFAULT 'file', -- file or api
 last_sync TEXT,
 config_json TEXT NOT NULL DEFAULT '{}',
 created_by TEXT NOT NULL REFERENCES users(id),
 created_at TEXT NOT NULL,
 UNIQUE(company_id, software)
);"""

with db() as con:
    con.executescript(INTEGRATION_SCHEMA)

ACCOUNTING_SOFTWARES = {
    'holoo': 'هلو', 'sepidar': 'سپیدار', 'parsiyan': 'پارسیان',
    'paydar': 'پایدار', 'nosa': 'نوسا', 'other': 'سایر',
}

@app.get("/api/integrations")
def list_integrations(request: Request, company_id: str = ""):
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        sql = """SELECT ai.*, c.name AS company_name FROM accounting_integrations ai
                 LEFT JOIN companies c ON c.id=ai.company_id WHERE 1=1"""
        params = []
        if company_id:
            sql += " AND ai.company_id=?"
            params.append(company_id)
        sql += " ORDER BY ai.created_at DESC"
        rows = con.execute(sql, params).fetchall()
        result = []
        for r in rows:
            d = dict(r)
            try: d["config"] = json.loads(r["config_json"])
            except: d["config"] = {}
            del d["config_json"]
            d["software_name"] = ACCOUNTING_SOFTWARES.get(r["software"], r["software"])
            result.append(d)
        return result

@app.post("/api/integrations")
def create_integration(request: Request, company_id: str = Form(...), software: str = Form(...), config: str = Form("{}")):
    user = current_user(request)
    require_perm(user, "customers.manage")
    iid = uid()
    with db() as con:
        try:
            con.execute("INSERT INTO accounting_integrations VALUES(?,?,?,?,?,?,?)",
                        (iid, company_id, software, 'file', None, config, user["id"], now()))
        except Exception as e:
            if "UNIQUE" in str(e):
                con.execute("UPDATE accounting_integrations SET config_json=?, updated_at=? WHERE company_id=? AND software=?",
                            (config, now(), company_id, software))
            else:
                raise
    return {"ok": True}

@app.post("/api/integrations/{integration_id}/import")
async def import_from_accounting(integration_id: str, request: Request, file: UploadFile = File(...)):
    """Import financial data from accounting software export file."""
    user = current_user(request)
    require_perm(user, "customers.manage")
    content = await file.read(20 * 1024 * 1024)  # 20MB max
    # Parse the file based on format (Excel/CSV/XML from Holoo/Sepidar)
    # For now, store the file and return summary
    stored_name = f"import_{uid()}_{file.filename}"
    import_dir = DATA / "imports"
    import_dir.mkdir(parents=True, exist_ok=True)
    (import_dir / stored_name).write_bytes(content)

    with db() as con:
        con.execute("UPDATE accounting_integrations SET last_sync=? WHERE id=?", (now(), integration_id))

    return {
        "ok": True,
        "filename": file.filename,
        "size": len(content),
        "message": f"فایل واردات از نرم‌افزار حسابداری دریافت شد. داده‌ها پس از پردازش در سیستم قرار می‌گیرند.",
    }

@app.get("/api/integrations/software-list")
def list_accounting_software(request: Request):
    user = current_user(request)
    require_perm(user, "customers.view")
    return {"software": ACCOUNTING_SOFTWARES}


# ========================================================================
# PHASE 5: PAYROLL MODULE (مدیریت حقوق و دستمزد مشتریان)
# ========================================================================
PAYROLL_SCHEMA = """CREATE TABLE IF NOT EXISTS payroll_entries(
 id TEXT PRIMARY KEY,
 company_id TEXT NOT NULL REFERENCES companies(id),
 employee_name TEXT NOT NULL,
 employee_tin TEXT NOT NULL DEFAULT '',
 position TEXT NOT NULL DEFAULT '',
 period TEXT NOT NULL, -- 1403-01, 1403-02, etc.
 gross_salary REAL NOT NULL DEFAULT 0,
 deductions REAL NOT NULL DEFAULT 0,
 tax_amount REAL NOT NULL DEFAULT 0,
 insurance_amount REAL NOT NULL DEFAULT 0,
 net_salary REAL NOT NULL DEFAULT 0,
 status TEXT NOT NULL DEFAULT 'DRAFT', -- DRAFT, CALCULATED, FILED, PAID
 filed_at TEXT,
 notes TEXT NOT NULL DEFAULT '',
 created_by TEXT NOT NULL REFERENCES users(id),
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL
);"""

with db() as con:
    con.executescript(PAYROLL_SCHEMA)

class PayrollCreateModel(BaseModel):
    company_id: str
    employee_name: str
    employee_tin: str = ""
    position: str = ""
    period: str
    gross_salary: float = 0
    deductions: float = 0
    tax_amount: float = 0
    insurance_amount: float = 0
    notes: str = ""

class PayrollUpdateModel(BaseModel):
    employee_name: str | None = None
    employee_tin: str | None = None
    position: str | None = None
    gross_salary: float | None = None
    deductions: float | None = None
    tax_amount: float | None = None
    insurance_amount: float | None = None
    status: str | None = None
    notes: str | None = None

@app.get("/api/payroll")
def list_payroll(request: Request, company_id: str = "", period: str = "", status: str = ""):
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        sql = """SELECT p.*, c.name AS company_name FROM payroll_entries p
                 LEFT JOIN companies c ON c.id=p.company_id WHERE 1=1"""
        params = []
        if company_id:
            sql += " AND p.company_id=?"
            params.append(company_id)
        if period:
            sql += " AND p.period=?"
            params.append(period)
        if status:
            sql += " AND p.status=?"
            params.append(status)
        sql += " ORDER BY p.period DESC, p.created_at DESC"
        rows = con.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

@app.post("/api/payroll")
def create_payroll(payload: PayrollCreateModel, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    pid = uid()
    ts = now()
    net = payload.gross_salary - payload.deductions - payload.tax_amount - payload.insurance_amount
    with db() as con:
        con.execute("""INSERT INTO payroll_entries
            (id, company_id, employee_name, employee_tin, position, period, gross_salary, deductions,
             tax_amount, insurance_amount, net_salary, status, filed_at, notes, created_by, created_at, updated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (pid, payload.company_id, payload.employee_name, payload.employee_tin, payload.position,
             payload.period, payload.gross_salary, payload.deductions, payload.tax_amount,
             payload.insurance_amount, net, 'DRAFT', None, payload.notes, user["id"], ts, ts))
    return {"id": pid, "net_salary": net}

@app.patch("/api/payroll/{payroll_id}")
def update_payroll(payroll_id: str, payload: PayrollUpdateModel, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    with db() as con:
        existing = con.execute("SELECT * FROM payroll_entries WHERE id=?", (payroll_id,)).fetchone()
        if not existing: raise HTTPException(404, "رکورد پیدا نشد")
        updates = []
        params = []
        for k, v in payload.model_dump(exclude_unset=True).items():
            if v is None: continue
            updates.append(f"{k}=?")
            params.append(v)
        # Recalculate net salary if any financial field changed
        if any(k in ['gross_salary', 'deductions', 'tax_amount', 'insurance_amount'] for k in payload.model_dump(exclude_unset=True).keys()):
            gross = float(payload.gross_salary) if payload.gross_salary is not None else float(existing["gross_salary"])
            ded = float(payload.deductions) if payload.deductions is not None else float(existing["deductions"])
            tax = float(payload.tax_amount) if payload.tax_amount is not None else float(existing["tax_amount"])
            ins = float(payload.insurance_amount) if payload.insurance_amount is not None else float(existing["insurance_amount"])
            net = gross - ded - tax - ins
            updates.append("net_salary=?")
            params.append(net)
        if payload.status == 'FILED' and not existing["filed_at"]:
            updates.append("filed_at=?")
            params.append(now())
        if not updates: return {"ok": True}
        updates.append("updated_at=?")
        params.append(now())
        params.append(payroll_id)
        con.execute(f"UPDATE payroll_entries SET {', '.join(updates)} WHERE id=?", params)
    return {"ok": True}

@app.delete("/api/payroll/{payroll_id}")
def delete_payroll(payroll_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    with db() as con:
        con.execute("DELETE FROM payroll_entries WHERE id=?", (payroll_id,))
    return {"ok": True}

@app.get("/api/payroll/summary")
def payroll_summary(request: Request, company_id: str = "", period: str = ""):
    """Summary of payroll for a period."""
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        sql = "SELECT COUNT(*) AS count, SUM(gross_salary) AS total_gross, SUM(net_salary) AS total_net, SUM(tax_amount) AS total_tax, SUM(insurance_amount) AS total_insurance FROM payroll_entries WHERE 1=1"
        params = []
        if company_id:
            sql += " AND company_id=?"
            params.append(company_id)
        if period:
            sql += " AND period=?"
            params.append(period)
        row = con.execute(sql, params).fetchone()
        return dict(row) if row else {}


# ========================================================================
# PHASE 5: TAX RESOLUTION (تسویه مالیاتی تخصصی)
# ========================================================================
TAX_CASE_SCHEMA = """CREATE TABLE IF NOT EXISTS tax_cases(
 id TEXT PRIMARY KEY,
 company_id TEXT NOT NULL REFERENCES companies(id),
 case_type TEXT NOT NULL, -- AUDIT, DISPUTE, PENALTY, ASSESSMENT, RESOLUTION
 title TEXT NOT NULL,
 description TEXT NOT NULL DEFAULT '',
 tax_year TEXT NOT NULL DEFAULT '',
 assessed_amount REAL NOT NULL DEFAULT 0,
 disputed_amount REAL NOT NULL DEFAULT 0,
 settled_amount REAL NOT NULL DEFAULT 0,
 status TEXT NOT NULL DEFAULT 'OPEN', -- OPEN, IN_PROGRESS, RESOLVED, CLOSED
 assigned_user_id TEXT REFERENCES users(id),
 deadline TEXT,
 resolution_notes TEXT NOT NULL DEFAULT '',
 created_by TEXT NOT NULL REFERENCES users(id),
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL
);"""

with db() as con:
    con.executescript(TAX_CASE_SCHEMA)

class TaxCaseCreateModel(BaseModel):
    company_id: str
    case_type: str = "AUDIT"
    title: str
    description: str = ""
    tax_year: str = ""
    assessed_amount: float = 0
    disputed_amount: float = 0
    deadline: str | None = None
    assigned_user_id: str | None = None

class TaxCaseUpdateModel(BaseModel):
    title: str | None = None
    description: str | None = None
    case_type: str | None = None
    tax_year: str | None = None
    assessed_amount: float | None = None
    disputed_amount: float | None = None
    settled_amount: float | None = None
    status: str | None = None
    assigned_user_id: str | None = None
    deadline: str | None = None
    resolution_notes: str | None = None

TAX_CASE_TYPES = {
    'AUDIT': 'حسابرسی مالیاتی', 'DISPUTE': 'اختلاف مالیاتی', 'PENALTY': 'جریمه',
    'ASSESSMENT': 'ارزیابی', 'RESOLUTION': 'تسویه',
}
TAX_CASE_STATUS = {
    'OPEN': 'باز', 'IN_PROGRESS': 'در دست بررسی', 'RESOLVED': 'حل شده', 'CLOSED': 'بسته شده',
}

@app.get("/api/tax-cases")
def list_tax_cases(request: Request, company_id: str = "", status: str = ""):
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        sql = """SELECT tc.*, c.name AS company_name, u.name AS assigned_name
                 FROM tax_cases tc LEFT JOIN companies c ON c.id=tc.company_id
                 LEFT JOIN users u ON u.id=tc.assigned_user_id WHERE 1=1"""
        params = []
        if company_id:
            sql += " AND tc.company_id=?"
            params.append(company_id)
        if status:
            sql += " AND tc.status=?"
            params.append(status)
        sql += " ORDER BY tc.created_at DESC"
        rows = con.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

@app.post("/api/tax-cases")
def create_tax_case(payload: TaxCaseCreateModel, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    cid = uid()
    ts = now()
    with db() as con:
        con.execute("""INSERT INTO tax_cases
            (id, company_id, case_type, title, description, tax_year, assessed_amount, disputed_amount,
             settled_amount, status, assigned_user_id, deadline, resolution_notes, created_by, created_at, updated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (cid, payload.company_id, payload.case_type, payload.title, payload.description,
             payload.tax_year, payload.assessed_amount, payload.disputed_amount, 0, 'OPEN',
             payload.assigned_user_id, payload.deadline, "", user["id"], ts, ts))
    return {"id": cid}

@app.patch("/api/tax-cases/{case_id}")
def update_tax_case(case_id: str, payload: TaxCaseUpdateModel, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    with db() as con:
        existing = con.execute("SELECT * FROM tax_cases WHERE id=?", (case_id,)).fetchone()
        if not existing: raise HTTPException(404, "پرونده پیدا نشد")
        updates = []
        params = []
        for k, v in payload.model_dump(exclude_unset=True).items():
            if v is None: continue
            updates.append(f"{k}=?")
            params.append(v)
        if not updates: return {"ok": True}
        updates.append("updated_at=?")
        params.append(now())
        params.append(case_id)
        con.execute(f"UPDATE tax_cases SET {', '.join(updates)} WHERE id=?", params)
    return {"ok": True}

@app.delete("/api/tax-cases/{case_id}")
def delete_tax_case(case_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    with db() as con:
        con.execute("DELETE FROM tax_cases WHERE id=?", (case_id,))
    return {"ok": True}

@app.get("/api/tax-cases/types")
def list_tax_case_types(request: Request):
    user = current_user(request)
    require_perm(user, "customers.view")
    return {"types": TAX_CASE_TYPES, "statuses": TAX_CASE_STATUS}


# ========================================================================
# PHASE 5: I18N / MULTILINGUAL (چندزبانه)
# ========================================================================
# Simple i18n: store language preference per user
I18N_SCHEMA = """CREATE TABLE IF NOT EXISTS user_preferences(
 user_id TEXT NOT NULL REFERENCES users(id),
 pref_key TEXT NOT NULL,
 pref_value TEXT NOT NULL,
 PRIMARY KEY(user_id, pref_key)
);"""

with db() as con:
    con.executescript(I18N_SCHEMA)

# Persian translations (default)
FA_TRANSLATIONS = {
    "nav.dashboard": "نمای کلی", "nav.tasks": "تسک‌ها", "nav.requests": "درخواست‌ها",
    "nav.attendance": "کارکرد", "nav.performance": "ثبت عملکرد", "nav.customers": "مشتریان",
    "nav.reports": "گزارشات", "nav.settings": "تنظیمات", "nav.chat": "گفتگو",
    "nav.kanban": "کانبان", "nav.time": "تایم ترکینگ",
    "common.new": "جدید", "common.edit": "ویرایش", "common.delete": "حذف",
    "common.save": "ذخیره", "common.cancel": "انصراف", "common.search": "جستجو",
    "common.confirm": "تأیید", "common.close": "بستن", "common.back": "بازگشت",
    "common.yes": "بله", "common.no": "خیر", "common.loading": "در حال بارگذاری...",
    "common.success": "موفق", "common.error": "خطا",
    "login.title": "خوش آمدید", "login.username": "نام کاربری", "login.password": "گذرواژه",
    "login.submit": "ورود به سامانه",
}

# English translations
EN_TRANSLATIONS = {
    "nav.dashboard": "Overview", "nav.tasks": "Tasks", "nav.requests": "Requests",
    "nav.attendance": "Attendance", "nav.performance": "Performance", "nav.customers": "Customers",
    "nav.reports": "Reports", "nav.settings": "Settings", "nav.chat": "Chat",
    "nav.kanban": "Kanban", "nav.time": "Time Tracking",
    "common.new": "New", "common.edit": "Edit", "common.delete": "Delete",
    "common.save": "Save", "common.cancel": "Cancel", "common.search": "Search",
    "common.confirm": "Confirm", "common.close": "Close", "common.back": "Back",
    "common.yes": "Yes", "common.no": "No", "common.loading": "Loading...",
    "common.success": "Success", "common.error": "Error",
    "login.title": "Welcome", "login.username": "Username", "login.password": "Password",
    "login.submit": "Sign In",
}

@app.get("/api/i18n/{lang}")
def get_translations(lang: str, request: Request):
    """Get translations for a language (fa or en)."""
    if lang == "en":
        return {"lang": "en", "dir": "ltr", "translations": EN_TRANSLATIONS}
    return {"lang": "fa", "dir": "rtl", "translations": FA_TRANSLATIONS}

@app.get("/api/user/preferences")
def get_user_preferences(request: Request):
    """Get all preferences for the current user."""
    user = current_user(request)
    with db() as con:
        rows = con.execute("SELECT pref_key, pref_value FROM user_preferences WHERE user_id=?", (user["id"],)).fetchall()
        return {r["pref_key"]: r["pref_value"] for r in rows}

@app.post("/api/user/preferences")
def set_user_preference(request: Request, key: str = "", value: str = ""):
    """Set a user preference."""
    user = current_user(request)
    if not key:
        raise HTTPException(400, "کلید تنظیمات الزامی است")
    with db() as con:
        con.execute("INSERT OR REPLACE INTO user_preferences VALUES(?,?)", (user["id"], key, value))
    return {"ok": True}


# ========================================================================
# PHASE 6: SECURITY & COMPLIANCE (امنیت و انطباق)
# ========================================================================
import base64 as _b64

# AES-256 encryption for sensitive data at rest
def aes_encrypt(plaintext: str, key: bytes = b"YFG-2026-AES256!!") -> str:
    """Simple AES-256-CBC encryption (using hashlib for key derivation)."""
    from hashlib import sha256
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    from cryptography.hazmat.backends import default_backend
    key_hash = sha256(key).digest()[:32]
    iv = os.urandom(16)
    cipher = Cipher(algorithms.AES(key_hash), modes.CBC(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    # Pad plaintext to 16-byte blocks
    padded = plaintext + ' ' * (16 - len(plaintext) % 16) if len(plaintext) % 16 != 0 else plaintext
    encrypted = encryptor.update(padded.encode()) + encryptor.finalize()
    return _b64.b64encode(iv + encrypted).decode()

def aes_decrypt(ciphertext: str, key: bytes = b"YFG-2026-AES256!!") -> str:
    """Decrypt AES-256-CBC encrypted text."""
    from hashlib import sha256
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    from cryptography.hazmat.backends import default_backend
    key_hash = sha256(key).digest()[:32]
    data = _b64.b64decode(ciphertext)
    iv = data[:16]
    encrypted = data[16:]
    cipher = Cipher(algorithms.AES(key_hash), modes.CBC(iv), backend=default_backend())
    decryptor = cipher.decryptor()
    decrypted = decryptor.update(encrypted) + decryptor.finalize()
    return decrypted.decode().rstrip()

# MFA (Two-Factor Authentication) — TOTP
MFA_SCHEMA = """CREATE TABLE IF NOT EXISTS user_mfa(
 user_id TEXT NOT NULL REFERENCES users(id),
 secret TEXT NOT NULL,
 enabled INTEGER NOT NULL DEFAULT 0,
 backup_codes TEXT NOT NULL DEFAULT '[]',
 created_at TEXT NOT NULL,
 PRIMARY KEY(user_id)
);"""

with db() as con:
    con.executescript(MFA_SCHEMA)

def generate_totp_secret() -> str:
    import secrets as _s
    return _s.token_hex(20)

def verify_totp(token: str, secret: str) -> bool:
    """Verify a TOTP token (6-digit code)."""
    import time, hashlib, hmac, struct
    if not token or not secret:
        return False
    try:
        token = token.strip().replace(' ', '')
        if len(token) != 6:
            return False
        counter = int(time.time()) // 30
        secret_bytes = bytes.fromhex(secret)
        for offset in (-1, 0, 1):  # allow 30s clock drift
            msg = struct.pack('>Q', counter + offset)
            hmac_hash = hmac.new(secret_bytes, msg, hashlib.sha1).digest()
            offset_byte = hmac_hash[-1] & 0x0F
            code = struct.unpack('>I', hmac_hash[offset_byte:offset_byte+4])[0] & 0x7FFFFFFF
            if f"{code % 1000000:06d}" == token:
                return True
    except Exception:
        pass
    return False

@app.get("/api/mfa/status")
def mfa_status(request: Request):
    """Check if MFA is enabled for the current user."""
    user = current_user(request)
    with db() as con:
        mfa = con.execute("SELECT * FROM user_mfa WHERE user_id=?", (user["id"],)).fetchone()
        if not mfa:
            return {"enabled": False}
        return {"enabled": bool(mfa["enabled"])}

@app.post("/api/mfa/setup")
def mfa_setup(request: Request):
    """Generate a new TOTP secret for the user."""
    user = current_user(request)
    secret = generate_totp_secret()
    import json as _json
    backup = [f"{secrets.randbelow(1000000):06d}" for _ in range(10)]
    with db() as con:
        con.execute("INSERT OR REPLACE INTO user_mfa VALUES(?,?,?,?,?)",
                    (user["id"], secret, 0, _json.dumps(backup), now()))
    # Generate OTP auth URL
    issuer = "YFG-Accounting-Desk"
    label = f"{issuer}:{user['username']}"
    otpauth_url = f"otpauth://totp/{label}?secret={secret}&issuer={issuer}&digits=6&period=30"
    return {
        "secret": secret,
        "otpauth_url": otpauth_url,
        "backup_codes": backup,
        "message": "کد را در یک اپ TOTP (مثل Google Authenticator) وارد کنید، سپس کد ۶ رقمی را تأیید کنید."
    }

@app.post("/api/mfa/verify")
def mfa_verify(request: Request, token: str = ""):
    """Verify TOTP token and enable MFA."""
    user = current_user(request)
    if not token:
        raise HTTPException(400, "کد ۶ رقمی الزامی است")
    with db() as con:
        mfa = con.execute("SELECT * FROM user_mfa WHERE user_id=?", (user["id"],)).fetchone()
        if not mfa:
            raise HTTPException(400, "ابتدا MFA را تنظیم کنید")
        if not verify_totp(token, mfa["secret"]):
            raise HTTPException(400, "کد نامعتبر")
        con.execute("UPDATE user_mfa SET enabled=1 WHERE user_id=?", (user["id"],))
    return {"ok": True, "message": "احراز هویت دو عاملی فعال شد"}

@app.delete("/api/mfa")
def mfa_disable(request: Request):
    """Disable MFA for the current user."""
    user = current_user(request)
    with db() as con:
        con.execute("DELETE FROM user_mfa WHERE user_id=?", (user["id"],))
    return {"ok": True, "message": "MFA غیرفعال شد"}

# Audit trail with hash chain (tamper-proof)
AUDIT_HASH_SCHEMA = """CREATE TABLE IF NOT EXISTS audit_hash_chain(
 id TEXT PRIMARY KEY,
 audit_event_id TEXT NOT NULL,
 previous_hash TEXT NOT NULL DEFAULT '',
 current_hash TEXT NOT NULL,
 created_at TEXT NOT NULL
);"""

with db() as con:
    con.executescript(AUDIT_HASH_SCHEMA)

def _add_audit_hash(con, audit_event_id: str):
    """Add a hash-chained entry to the audit trail."""
    last = con.execute("SELECT current_hash FROM audit_hash_chain ORDER BY created_at DESC LIMIT 1").fetchone()
    prev_hash = last["current_hash"] if last else ""
    event = con.execute("SELECT * FROM audit_events WHERE id=?", (audit_event_id,)).fetchone()
    if not event:
        return
    data = f"{event['id']}:{event['actor']}:{event['action']}:{event['entity']}:{event['entity_id']}:{event['details']}:{event['created_at']}:{prev_hash}"
    current_hash = hashlib.sha256(data.encode()).hexdigest()
    con.execute("INSERT INTO audit_hash_chain VALUES(?,?,?,?,?)",
                (uid(), audit_event_id, prev_hash, current_hash, now()))

@app.get("/api/audit/verify-chain")
def verify_audit_chain(request: Request):
    """Verify the integrity of the audit hash chain."""
    user = current_user(request)
    require_perm(user, "audit.view")
    with db() as con:
        rows = con.execute("SELECT * FROM audit_hash_chain ORDER BY created_at ASC").fetchall()
        if not rows:
            return {"valid": True, "count": 0, "message": "زنجیره ممیزی خالی است"}
        prev_hash = ""
        broken_at = None
        for i, r in enumerate(rows):
            event = con.execute("SELECT * FROM audit_events WHERE id=?", (r["audit_event_id"],)).fetchone()
            if not event:
                broken_at = i
                break
            data = f"{event['id']}:{event['actor']}:{event['action']}:{event['entity']}:{event['entity_id']}:{event['details']}:{event['created_at']}:{prev_hash}"
            expected_hash = hashlib.sha256(data.encode()).hexdigest()
            if r["previous_hash"] != prev_hash or r["current_hash"] != expected_hash:
                broken_at = i
                break
            prev_hash = r["current_hash"]
        return {
            "valid": broken_at is None,
            "count": len(rows),
            "broken_at": broken_at,
            "message": "زنجیره ممیزی معتبر است" if broken_at is None else f"زنجیره در موقعیت {broken_at} شکسته شده"
        }

# Data retention policy (7-year retention per Iranian tax law)
@app.get("/api/system/retention-policy")
def get_retention_policy(request: Request):
    """Returns data retention policy."""
    user = current_user(request)
    require_perm(user, "settings.view")
    return {
        "retention_years": 7,
        "retention_start": "2019-01-01",  # 1403 - 7 = 1396 ≈ 2017 but we keep from 2019
        "description": "طبق قانون مالیاتی ایران، اسناد مالی باید حداقل ۷ سال نگهداری شوند",
        "tables_covered": ["tasks", "submissions", "invoices", "fees", "payroll_entries", "tax_cases", "audit_events"],
        "auto_delete_after": False,
        "warning_days": 90,
    }

# Disaster recovery — automated backup schedule
@app.post("/api/system/dr/backup")
def dr_backup(request: Request, label: str = "auto"):
    """Create a disaster recovery backup (DB + config + attachments list)."""
    user = current_user(request)
    require_perm(user, "settings.view")
    ts = now().replace(":", "-").replace(".", "_")
    backup_name = f"dr_{ts}_{label}.bak"
    backup_path = DATA / "backups" / backup_name
    backup_path.parent.mkdir(parents=True, exist_ok=True)
    # Copy database
    shutil.copy2(str(DB_PATH), str(backup_path))
    # Create manifest (list of all files)
    manifest = {"database": backup_name, "timestamp": now(), "files": [], "attachments": [], "documents": []}
    for d in [FILES, ATTACHMENTS_DIR, DATA / "documents"]:
        if d.exists():
            for f in d.iterdir():
                if f.is_file():
                    manifest["attachments" if d == ATTACHMENTS_DIR else "documents" if d == DATA / "documents" else "files"].append({
                        "name": f.name, "size": f.stat().st_size, "sha256": hashlib.sha256(f.read_bytes()).hexdigest()
                    })
    manifest_path = backup_path.with_suffix(".manifest.json")
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
    return {"ok": True, "backup_file": backup_name, "manifest_file": manifest_path.name, "size": backup_path.stat().st_size}

# Password policy enforcement
class PasswordPolicyModel(BaseModel):
    min_length: int = 4
    require_uppercase: bool = False
    require_lowercase: bool = True
    require_digit: bool = False
    require_special: bool = False
    prevent_reuse: int = 0  # number of previous passwords to prevent

@app.get("/api/system/password-policy")
def get_password_policy(request: Request):
    """Returns current password policy."""
    user = current_user(request)
    return {
        "min_length": 4,
        "require_uppercase": False,
        "require_lowercase": True,
        "require_digit": False,
        "require_special": False,
        "prevent_reuse": 0,
        "description": "حداقل ۴ نویسه (قابل تنظیم در تنظیمات سامانه)"
    }

def validate_password(password: str) -> tuple[bool, str]:
    """Validate password against policy."""
    if len(password) < 4:
        return False, "رمز عبور حداقل باید ۴ نویسه باشد"
    return True, ""


# ========================================================================
# PHASE 7: IRAN ECOSYSTEM (اکوسیستم ایران)
# ========================================================================

# 7.1: Sheba / IR-IBAN Support (پشتیبانی شماره شبا)
SHEBA_SCHEMA = """CREATE TABLE IF NOT EXISTS company_bank_accounts(
 id TEXT PRIMARY KEY,
 company_id TEXT NOT NULL REFERENCES companies(id),
 sheba TEXT NOT NULL, -- IR + 24 digits (without spaces)
 bank_name TEXT NOT NULL DEFAULT '',
 account_number TEXT NOT NULL DEFAULT '',
 is_default INTEGER NOT NULL DEFAULT 0,
 active INTEGER NOT NULL DEFAULT 1,
 created_by TEXT NOT NULL REFERENCES users(id),
 created_at TEXT NOT NULL,
 UNIQUE(company_id, sheba)
);"""

with db() as con:
    con.executescript(SHEBA_SCHEMA)

IRANIAN_BANKS = {
    "010": "ملت", "011": "سامان", "012": "سپه", "013": "کشاورزی", "014": "مسکن",
    "015": "پاسارگاد", "016": "پارسیان", "017": "کارآفرین", "018": "صادرات",
    "019": "تجارت", "020": "ملی ایران", "021": "آینده", "022": "شهرداری تهران",
    "023": "دی", "024": "پست بانک", "025": "توسعه تعاون", "026": "توسعه صادرات",
    "027": "صنعت و معدن", "028": "رفاه کارگران", "029": "رسالت", "030": "انسجام",
    "031": "سرمایه", "032": "تات", "033": "قوامین", "034": "مهر اقتصاد",
    "035": "شهر", "036": "آیین", "037": "نور", "038": "مهر ایران",
    "039": "خاورمیانه", "040": "ارمغان", "041": "گردشگری", "042": "کلان",
    "043": "اقتصاد نوین", "044": "پاسارگاد", "045": "موسسه اعتباری توسعه",
    "046": "موسسه اعتباری فرشته", "047": "موسسه اعتباری بانک کارآفرین",
}

def validate_sheba(sheba: str) -> tuple[bool, str, str]:
    """Validate Iranian Sheba (IR-IBAN) format."""
    sheba = sheba.replace(" ", "").upper()
    if not sheba.startswith("IR") or len(sheba) != 26:
        return False, "", "شماره شبا باید با IR شروع و ۲۶ نویسه باشد"
    if not sheba[2:].isdigit():
        return False, "", "بخش عددی شبا نامعتبر است"
    # Extract bank code (digits 4-6)
    bank_code = sheba[5:8]
    bank_name = IRANIAN_BANKS.get(bank_code, "نامشخص")
    # IBAN checksum validation
    rearranged = sheba[4:] + sheba[:4]
    converted = ""
    for c in rearranged:
        if c.isdigit():
            converted += c
        else:
            converted += str(ord(c) - 55)
    try:
        if int(converted) % 97 != 1:
            return False, bank_name, "چک‌سام شبا نامعتبر است"
    except Exception:
        return False, bank_name, "فرمت شبا نامعتبر"
    return True, bank_name, ""

class BankAccountModel(BaseModel):
    company_id: str
    sheba: str
    bank_name: str = ""
    account_number: str = ""
    is_default: int = 0

@app.get("/api/companies/{company_id}/bank-accounts")
def list_bank_accounts(company_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        rows = con.execute("SELECT * FROM company_bank_accounts WHERE company_id=? AND active=1 ORDER BY is_default DESC", (company_id,)).fetchall()
        return [dict(r) for r in rows]

@app.post("/api/companies/{company_id}/bank-accounts")
def add_bank_account(company_id: str, payload: BankAccountModel, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    valid, bank_name, error = validate_sheba(payload.sheba)
    if not valid:
        raise HTTPException(400, error)
    bid = uid()
    with db() as con:
        try:
            con.execute("INSERT INTO company_bank_accounts VALUES(?,?,?,?,?,?,?,?)",
                        (bid, company_id, payload.sheba.upper(), bank_name or payload.bank_name,
                         payload.account_number, payload.is_default, 1, user["id"], now()))
        except Exception as e:
            if "UNIQUE" in str(e): raise HTTPException(400, "این شبا قبلاً ثبت شده")
            raise
    return {"id": bid, "bank_name": bank_name}

@app.delete("/api/companies/{company_id}/bank-accounts/{account_id}")
def delete_bank_account(company_id: str, account_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    with db() as con:
        con.execute("DELETE FROM company_bank_accounts WHERE id=? AND company_id=?", (account_id, company_id))
    return {"ok": True}

@app.get("/api/banks/list")
def list_iranian_banks(request: Request):
    user = current_user(request)
    return {"banks": IRANIAN_BANKS}

# 7.2: Paya Batch Transfer (پرداخت گروهی پایا)
PAYA_SCHEMA = """CREATE TABLE IF NOT EXISTS paya_batches(
 id TEXT PRIMARY KEY,
 title TEXT NOT NULL,
 description TEXT NOT NULL DEFAULT '',
 batch_date TEXT NOT NULL,
 total_amount REAL NOT NULL DEFAULT 0,
 status TEXT NOT NULL DEFAULT 'DRAFT', -- DRAFT, READY, SENT, COMPLETED, FAILED
 source_company_id TEXT REFERENCES companies(id),
 source_sheba TEXT,
 items_json TEXT NOT NULL DEFAULT '[]',
 created_by TEXT NOT NULL REFERENCES users(id),
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL
);"""

with db() as con:
    con.executescript(PAYA_SCHEMA)

class PayaBatchModel(BaseModel):
    title: str
    description: str = ""
    batch_date: str
    source_company_id: str | None = None
    source_sheba: str | None = None
    items: list[dict] = []  # [{sheba, amount, name, description, fee_type}]

@app.get("/api/paya-batches")
def list_paya_batches(request: Request, status: str = ""):
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        sql = "SELECT * FROM paya_batches WHERE 1=1"
        params = []
        if status:
            sql += " AND status=?"
            params.append(status)
        sql += " ORDER BY created_at DESC"
        rows = con.execute(sql, params).fetchall()
        result = []
        for r in rows:
            d = dict(r)
            try: d["items"] = json.loads(r["items_json"])
            except: d["items"] = []
            del d["items_json"]
            result.append(d)
        return result

@app.post("/api/paya-batches")
def create_paya_batch(payload: PayaBatchModel, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    bid = uid()
    total = sum(float(i.get("amount", 0)) for i in payload.items)
    items_json = json.dumps(payload.items, ensure_ascii=False)
    with db() as con:
        con.execute("""INSERT INTO paya_batches
            (id, title, description, batch_date, total_amount, status, source_company_id, source_sheba, items_json, created_by, created_at, updated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
            (bid, payload.title, payload.description, payload.batch_date, total, 'DRAFT',
             payload.source_company_id, payload.source_sheba, items_json, user["id"], now(), now()))
    return {"id": bid, "total_amount": total, "item_count": len(payload.items)}

@app.delete("/api/paya-batches/{batch_id}")
def delete_paya_batch(batch_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    with db() as con:
        con.execute("DELETE FROM paya_batches WHERE id=?", (batch_id,))
    return {"ok": True}

# 7.3: Digital Signature (PKI / امضای دیجیتال)
PKI_SCHEMA = """CREATE TABLE IF NOT EXISTS digital_certificates(
 id TEXT PRIMARY KEY,
 company_id TEXT NOT NULL REFERENCES companies(id),
 certificate_name TEXT NOT NULL,
 issuer TEXT NOT NULL DEFAULT '',
 serial_number TEXT NOT NULL DEFAULT '',
 valid_from TEXT,
 valid_until TEXT,
 certificate_data TEXT NOT NULL DEFAULT '',
 status TEXT NOT NULL DEFAULT 'ACTIVE',
 created_by TEXT NOT NULL REFERENCES users(id),
 created_at TEXT NOT NULL
);"""

with db() as con:
    con.executescript(PKI_SCHEMA)

class CertificateModel(BaseModel):
    company_id: str
    certificate_name: str
    issuer: str = ""
    serial_number: str = ""
    valid_from: str | None = None
    valid_until: str | None = None
    certificate_data: str = ""

@app.get("/api/digital-certificates")
def list_certificates(request: Request, company_id: str = ""):
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        sql = "SELECT * FROM digital_certificates WHERE 1=1"
        params = []
        if company_id:
            sql += " AND company_id=?"
            params.append(company_id)
        sql += " ORDER BY created_at DESC"
        rows = con.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

@app.post("/api/digital-certificates")
def add_certificate(payload: CertificateModel, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    cid = uid()
    with db() as con:
        con.execute("INSERT INTO digital_certificates VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                    (cid, payload.company_id, payload.certificate_name, payload.issuer, payload.serial_number,
                     payload.valid_from, payload.valid_until, payload.certificate_data, 'ACTIVE', user["id"], now()))
    return {"id": cid}

@app.delete("/api/digital-certificates/{cert_id}")
def delete_certificate(cert_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    with db() as con:
        con.execute("DELETE FROM digital_certificates WHERE id=?", (cert_id,))
    return {"ok": True}

# 7.4: Social Security (سازمان تامین اجتماعی)
SSO_SCHEMA = """CREATE TABLE IF NOT EXISTS sso_submissions(
 id TEXT PRIMARY KEY,
 company_id TEXT NOT NULL REFERENCES companies(id),
 period TEXT NOT NULL,
 employee_count INTEGER NOT NULL DEFAULT 0,
 total_salary REAL NOT NULL DEFAULT 0,
 employer_share REAL NOT NULL DEFAULT 0,
 employee_share REAL NOT NULL DEFAULT 0,
 total_premium REAL NOT NULL DEFAULT 0,
 status TEXT NOT NULL DEFAULT 'DRAFT',
 submitted_at TEXT,
 reference_code TEXT,
 notes TEXT NOT NULL DEFAULT '',
 created_by TEXT NOT NULL REFERENCES users(id),
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL
);"""

with db() as con:
    con.executescript(SSO_SCHEMA)

class SSOSubmissionModel(BaseModel):
    company_id: str
    period: str
    employee_count: int = 0
    total_salary: float = 0
    employer_share: float = 0
    employee_share: float = 0
    total_premium: float = 0
    notes: str = ""

@app.get("/api/sso/submissions")
def list_sso_submissions(request: Request, company_id: str = "", period: str = ""):
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        sql = "SELECT s.*, c.name AS company_name FROM sso_submissions s LEFT JOIN companies c ON c.id=s.company_id WHERE 1=1"
        params = []
        if company_id:
            sql += " AND s.company_id=?"; params.append(company_id)
        if period:
            sql += " AND s.period=?"; params.append(period)
        sql += " ORDER BY s.period DESC"
        rows = con.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

@app.post("/api/sso/submissions")
def create_sso_submission(payload: SSOSubmissionModel, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    sid = uid()
    with db() as con:
        con.execute("""INSERT INTO sso_submissions
            (id, company_id, period, employee_count, total_salary, employer_share, employee_share, total_premium, status, submitted_at, reference_code, notes, created_by, created_at, updated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (sid, payload.company_id, payload.period, payload.employee_count, payload.total_salary,
             payload.employer_share, payload.employee_share, payload.total_premium, 'DRAFT', None, None,
             payload.notes, user["id"], now(), now()))
    return {"id": sid}

@app.patch("/api/sso/submissions/{submission_id}")
def update_sso_submission(submission_id: str, request: Request, status: str = "", reference_code: str = ""):
    user = current_user(request)
    require_perm(user, "customers.manage")
    with db() as con:
        updates = []
        params = []
        if status:
            updates.append("status=?"); params.append(status)
            if status == 'SUBMITTED':
                updates.append("submitted_at=?"); params.append(now())
        if reference_code:
            updates.append("reference_code=?"); params.append(reference_code)
        if updates:
            updates.append("updated_at=?"); params.append(now())
            params.append(submission_id)
            con.execute(f"UPDATE sso_submissions SET {', '.join(updates)} WHERE id=?", params)
    return {"ok": True}

@app.delete("/api/sso/submissions/{submission_id}")
def delete_sso_submission(submission_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    with db() as con:
        con.execute("DELETE FROM sso_submissions WHERE id=?", (submission_id,))
    return {"ok": True}


# ========================================================================
# PHASE 8: AI ENGINE (موتور هوش مصنوعی)
# ========================================================================

# 8.1: Document Q&A (RAG — Retrieval Augmented Generation)
AI_SCHEMA = """CREATE TABLE IF NOT EXISTS ai_document_index(
 id TEXT PRIMARY KEY,
 document_id TEXT NOT NULL REFERENCES documents(id),
 company_id TEXT NOT NULL REFERENCES companies(id),
 content_text TEXT NOT NULL DEFAULT '',
 keywords TEXT NOT NULL DEFAULT '',
 indexed_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS ai_qa_history(
 id TEXT PRIMARY KEY,
 company_id TEXT NOT NULL REFERENCES companies(id),
 user_id TEXT NOT NULL REFERENCES users(id),
 question TEXT NOT NULL,
 answer TEXT NOT NULL,
 document_ids TEXT NOT NULL DEFAULT '[]',
 created_at TEXT NOT NULL
);"""

with db() as con:
    con.executescript(AI_SCHEMA)

class AIQuestionModel(BaseModel):
    company_id: str
    question: str
    document_ids: list[str] = []  # specific docs, or empty for all

@app.post("/api/ai/ask")
def ai_ask(payload: AIQuestionModel, request: Request):
    """Ask a question about company documents (RAG-style search)."""
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        # Search indexed documents for relevant content
        sql = "SELECT d.id, d.title, d.description, ai.content_text, ai.keywords FROM ai_document_index ai JOIN documents d ON d.id=ai.document_id WHERE ai.company_id=?"
        params = [payload.company_id]
        if payload.document_ids:
            placeholders = ",".join("?" * len(payload.document_ids))
            sql += f" AND d.id IN ({placeholders})"
            params.extend(payload.document_ids)
        rows = con.execute(sql, params).fetchall()
        
        # Simple keyword matching (in production, use embeddings + vector search)
        question_words = set(payload.question.lower().split())
        scored = []
        for r in rows:
            content = (r["title"] + " " + r["description"] + " " + r["content_text"] + " " + r["keywords"]).lower()
            score = sum(1 for w in question_words if w in content)
            if score > 0:
                scored.append((score, dict(r)))
        scored.sort(key=lambda x: -x[0])
        top = scored[:5]
        
        if not top:
            answer = "هیچ سند مرتبطی برای پاسخ به این سوال یافت نشد. لطفاً کلمات کلیدی دیگری را امتحان کنید."
        else:
            answer_parts = []
            for score, doc in top:
                snippet = doc["content_text"][:500] if doc["content_text"] else doc["description"][:200]
                answer_parts.append(f"📄 {doc['title']}:\n{snippet}...\n")
            answer = f"بر اساس {len(top)} سند مرتبط:\n\n" + "\n---\n".join(answer_parts)
        
        # Save Q&A history
        qa_id = uid()
        doc_ids = json.dumps([d["id"] for _, d in top])
        con.execute("INSERT INTO ai_qa_history VALUES(?,?,?,?,?,?,?)",
                    (qa_id, payload.company_id, user["id"], payload.question, answer, doc_ids, now()))
    return {"answer": answer, "matched_documents": len(top), "question": payload.question}

@app.post("/api/ai/index-document")
def ai_index_document(request: Request, document_id: str = ""):
    """Index a document for AI search (extract text for RAG)."""
    user = current_user(request)
    require_perm(user, "customers.view")
    if not document_id:
        raise HTTPException(400, "شناسه سند الزامی است")
    with db() as con:
        doc = con.execute("SELECT * FROM documents WHERE id=?", (document_id,)).fetchone()
        if not doc: raise HTTPException(404, "سند پیدا نشد")
        # Try to extract text from the file
        path = DATA / "documents" / doc["stored_name"]
        content_text = ""
        if path.exists():
            try:
                if doc["mime_type"] == "text/plain":
                    content_text = path.read_text(errors="replace")[:5000]
                elif doc["file_name"].endswith(".csv"):
                    content_text = path.read_text(errors="replace")[:5000]
                elif doc["file_name"].endswith(".json"):
                    content_text = path.read_text(errors="replace")[:5000]
                else:
                    content_text = doc["description"] or doc["title"]
            except Exception:
                content_text = doc["description"] or doc["title"]
        else:
            content_text = doc["description"] or doc["title"]
        
        # Extract keywords
        import re as _re
        words = _re.findall(r'[\u0600-\u06FF\u0080-\u0FFF]{3,}', content_text)
        keywords = " ".join(list(set(words))[:20])
        
        # Check if already indexed
        existing = con.execute("SELECT id FROM ai_document_index WHERE document_id=?", (document_id,)).fetchone()
        if existing:
            con.execute("UPDATE ai_document_index SET content_text=?, keywords=?, indexed_at=? WHERE document_id=?",
                        (content_text, keywords, now(), document_id))
        else:
            con.execute("INSERT INTO ai_document_index VALUES(?,?,?,?,?)",
                        (uid(), document_id, doc["company_id"], content_text, keywords, now()))
    return {"ok": True, "indexed_chars": len(content_text), "keywords": keywords}

@app.get("/api/ai/qa-history")
def ai_qa_history(request: Request, company_id: str = "", limit: int = 20):
    """Get AI Q&A history."""
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        sql = "SELECT * FROM ai_qa_history WHERE user_id=?"
        params = [user["id"]]
        if company_id:
            sql += " AND company_id=?"
            params.append(company_id)
        sql += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)
        rows = con.execute(sql, params).fetchall()
        result = []
        for r in rows:
            d = dict(r)
            try: d["document_ids"] = json.loads(r["document_ids"])
            except: d["document_ids"] = []
            result.append(d)
        return result

# 8.2: Auto-Categorization (دسته‌بندی خودکار اسناد)
@app.post("/api/ai/categorize-document")
def ai_categorize_document(request: Request, document_id: str = ""):
    """Auto-categorize a document using keyword matching."""
    user = current_user(request)
    require_perm(user, "customers.view")
    if not document_id:
        raise HTTPException(400, "شناسه سند الزامی است")
    with db() as con:
        doc = con.execute("SELECT * FROM documents WHERE id=?", (document_id,)).fetchone()
        if not doc: raise HTTPException(404, "سند پیدا نشد")
        # Category keywords
        category_keywords = {
            'contract': ['قرارداد', 'توافق', 'تعهد', 'contract', 'agreement'],
            'invoice': ['فاکتور', 'صورتحساب', 'invoice', 'bill'],
            'tax': ['مالیات', 'اظهارنامه', 'ارزش افزوده', 'tax', 'VAT'],
            'audit': ['حسابرسی', 'ممیزی', 'audit', 'review'],
            'bank': ['بانک', 'شبا', 'حساب', 'bank', 'statement', 'حواله'],
            'payroll': ['حقوق', 'دستمزد', 'payroll', 'salary'],
            'other': [],
        }
        text = (doc["title"] + " " + doc["description"] + " " + doc.get("tags", "")).lower()
        best_category = "other"
        best_score = 0
        for cat, keywords in category_keywords.items():
            score = sum(1 for kw in keywords if kw.lower() in text)
            if score > best_score:
                best_score = score
                best_category = cat
        if best_score > 0:
            con.execute("UPDATE documents SET category=? WHERE id=?", (best_category, document_id))
        return {"category": best_category, "confidence": best_score, "keywords_matched": best_score}

# 8.3: Predictive Cash Flow (پیش‌بینی جریان نقدی)
@app.get("/api/ai/cash-flow-forecast")
def cash_flow_forecast(request: Request, company_id: str = "", months: int = 3):
    """Predict cash flow based on historical fee/payment data."""
    user = current_user(request)
    require_perm(user, "dashboard.view")
    with db() as con:
        # Get historical data (last 6 months)
        sql = """SELECT strftime('%Y-%m', issue_date) AS month,
                 SUM(amount) AS billed, SUM(paid_amount) AS paid
                 FROM fees WHERE issue_date >= date('now', '-6 months')"""
        params = []
        if company_id:
            sql += " AND company_id=?"
            params.append(company_id)
        sql += " GROUP BY month ORDER BY month DESC LIMIT 6"
        rows = con.execute(sql, params).fetchall()
        history = [dict(r) for r in rows]
        
        # Simple moving average forecast
        if len(history) >= 2:
            avg_billed = sum(float(r["billed"] or 0) for r in history) / len(history)
            avg_paid = sum(float(r["paid"] or 0) for r in history) / len(history)
            collection_rate = avg_paid / avg_billed if avg_billed > 0 else 0.8
        else:
            avg_billed = 0
            avg_paid = 0
            collection_rate = 0.8
        
        # Generate forecast
        forecast = []
        from datetime import datetime as _dt, timedelta as _td
        for i in range(1, months + 1):
            future_date = (_dt.now() + _td(days=30 * i)).strftime("%Y-%m")
            # Trend factor (slight growth)
            trend = 1 + (0.02 * i)
            forecast.append({
                "month": future_date,
                "projected_billing": round(avg_billed * trend),
                "projected_collection": round(avg_billed * trend * collection_rate),
                "confidence": max(0.5, 0.9 - (0.1 * i)),
            })
        
        # Risk assessment
        risk_level = "low"
        if collection_rate < 0.5:
            risk_level = "high"
        elif collection_rate < 0.7:
            risk_level = "medium"
        
        return {
            "history": history,
            "forecast": forecast,
            "collection_rate": round(collection_rate * 100, 1),
            "avg_monthly_billing": round(avg_billed),
            "risk_level": risk_level,
            "recommendations": [
                f"نرخ وصول شما {round(collection_rate*100)}٪ است. {'هدف: افزایش به ۸۰٪+' if collection_rate < 0.8 else 'عالی!'}",
                f"میانگین صورتحساب ماهانه: {num(round(avg_billed))} ریال",
                f"پیش‌بینی {months} ماه آینده: رشد تدریجی",
            ] if history else ["داده‌های تاریخی کافی نیست. حداقل ۲ ماه داده نیاز است."],
        }


# ========================================================================
# PHASE 9: REAL-TIME COLLABORATION (همکاری بلادرنگ)
# ========================================================================

# 9.1: Shared Notes (یادداشت مشترک روی اسناد/تسک‌ها)
NOTES_SCHEMA = """CREATE TABLE IF NOT EXISTS shared_notes(
 id TEXT PRIMARY KEY,
 entity_type TEXT NOT NULL, -- task, document, company, contract, invoice
 entity_id TEXT NOT NULL,
 user_id TEXT NOT NULL REFERENCES users(id),
 body TEXT NOT NULL,
 is_pinned INTEGER NOT NULL DEFAULT 0,
 is_internal INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL
);"""

with db() as con:
    con.executescript(NOTES_SCHEMA)

class NoteCreateModel(BaseModel):
    entity_type: str
    entity_id: str
    body: str
    is_pinned: int = 0
    is_internal: int = 1

@app.get("/api/notes/{entity_type}/{entity_id}")
def list_notes(entity_type: str, entity_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "dashboard.view")
    with db() as con:
        rows = con.execute("""SELECT n.*, u.name AS user_name FROM shared_notes n
            JOIN users u ON u.id=n.user_id
            WHERE n.entity_type=? AND n.entity_id=?
            ORDER BY n.is_pinned DESC, n.created_at DESC""",
            (entity_type, entity_id)).fetchall()
        return [dict(r) for r in rows]

@app.post("/api/notes")
def create_note(payload: NoteCreateModel, request: Request):
    user = current_user(request)
    nid = uid()
    with db() as con:
        con.execute("INSERT INTO shared_notes VALUES(?,?,?,?,?,?,?,?,?)",
                    (nid, payload.entity_type, payload.entity_id, user["id"],
                     payload.body, payload.is_pinned, payload.is_internal, now(), now()))
    return {"id": nid}

@app.patch("/api/notes/{note_id}")
def update_note(note_id: str, request: Request, body: str = "", is_pinned: int | None = None):
    user = current_user(request)
    with db() as con:
        existing = con.execute("SELECT * FROM shared_notes WHERE id=? AND user_id=?", (note_id, user["id"])).fetchone()
        if not existing: raise HTTPException(404, "یادداشت پیدا نشد")
        updates = []
        params = []
        if body:
            updates.append("body=?"); params.append(body)
        if is_pinned is not None:
            updates.append("is_pinned=?"); params.append(is_pinned)
        if updates:
            updates.append("updated_at=?"); params.append(now())
            params.append(note_id)
            con.execute(f"UPDATE shared_notes SET {', '.join(updates)} WHERE id=?", params)
    return {"ok": True}

@app.delete("/api/notes/{note_id}")
def delete_note(note_id: str, request: Request):
    user = current_user(request)
    with db() as con:
        con.execute("DELETE FROM shared_notes WHERE id=? AND user_id=?", (note_id, user["id"]))
    return {"ok": True}

# 9.2: Activity Feed (خط زمانی فعالیت)
@app.get("/api/activity-feed")
def activity_feed(request: Request, limit: int = 30):
    """Unified activity feed from audit events, chat, tasks, and notes."""
    user = current_user(request)
    require_perm(user, "dashboard.view")
    with db() as con:
        # Audit events
        audit = con.execute("""SELECT ae.id, ae.actor, ae.action, ae.entity_type, ae.entity_id,
            ae.created_at, u.name AS user_name FROM audit_events ae
            LEFT JOIN users u ON u.id=ae.actor
            ORDER BY ae.created_at DESC LIMIT ?""", (limit,)).fetchall()
        events = []
        for a in audit:
            events.append({
                "id": a["id"],
                "type": "audit",
                "user": a["user_name"] or "سیستم",
                "action": a["action"],
                "entity": a["entity_type"],
                "timestamp": a["created_at"],
                "description": f"{a['action']} روی {a['entity_type']}",
            })
        events.sort(key=lambda e: e["timestamp"], reverse=True)
        return events[:limit]

# 9.3: Client Communication Log (ثبت ارتباط با مشتری)
COMM_SCHEMA = """CREATE TABLE IF NOT EXISTS client_communications(
 id TEXT PRIMARY KEY,
 company_id TEXT NOT NULL REFERENCES companies(id),
 comm_type TEXT NOT NULL, -- call, email, meeting, message, visit
 subject TEXT NOT NULL,
 description TEXT NOT NULL DEFAULT '',
 outcome TEXT NOT NULL DEFAULT '',
 follow_up_date TEXT,
 follow_up_done INTEGER NOT NULL DEFAULT 0,
 user_id TEXT NOT NULL REFERENCES users(id),
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL
);"""

with db() as con:
    con.executescript(COMM_SCHEMA)

class CommunicationModel(BaseModel):
    company_id: str
    comm_type: str = "call"
    subject: str
    description: str = ""
    outcome: str = ""
    follow_up_date: str | None = None

@app.get("/api/communications")
def list_communications(request: Request, company_id: str = ""):
    user = current_user(request)
    require_perm(user, "customers.view")
    with db() as con:
        sql = """SELECT c.*, comp.name AS company_name, u.name AS user_name
                 FROM client_communications c
                 LEFT JOIN companies comp ON comp.id=c.company_id
                 LEFT JOIN users u ON u.id=c.user_id WHERE 1=1"""
        params = []
        if company_id:
            sql += " AND c.company_id=?"; params.append(company_id)
        sql += " ORDER BY c.created_at DESC LIMIT 200"
        rows = con.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

@app.post("/api/communications")
def create_communication(payload: CommunicationModel, request: Request):
    user = current_user(request)
    require_perm(user, "customers.view")
    cid = uid()
    with db() as con:
        con.execute("""INSERT INTO client_communications
            (id, company_id, comm_type, subject, description, outcome, follow_up_date, follow_up_done, user_id, created_at, updated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
            (cid, payload.company_id, payload.comm_type, payload.subject, payload.description,
             payload.outcome, payload.follow_up_date, 0, user["id"], now(), now()))
    return {"id": cid}

@app.patch("/api/communications/{comm_id}")
def update_communication(comm_id: str, request: Request, follow_up_done: int = 1):
    user = current_user(request)
    with db() as con:
        con.execute("UPDATE client_communications SET follow_up_done=?, updated_at=? WHERE id=?",
                    (follow_up_done, now(), comm_id))
    return {"ok": True}

@app.delete("/api/communications/{comm_id}")
def delete_communication(comm_id: str, request: Request):
    user = current_user(request)
    require_perm(user, "customers.manage")
    with db() as con:
        con.execute("DELETE FROM client_communications WHERE id=?", (comm_id,))
    return {"ok": True}


# ========================================================================
# PHASE 10: PREDICTIVE ANALYTICS (تحلیلی پیش‌بینانه)
# ========================================================================

# 10.1: Client Risk Scoring (امتیازدهی ریسک مشتری)
@app.get("/api/analytics/client-risk")
def client_risk_scoring(request: Request, company_id: str = ""):
    """Score each client's risk based on payment history, overdue, and activity."""
    user = current_user(request)
    require_perm(user, "dashboard.view")
    with db() as con:
        sql = """SELECT c.id, c.name,
            (SELECT COUNT(*) FROM fees f WHERE f.company_id=c.id AND f.status='OVERDUE') AS overdue_count,
            (SELECT COUNT(*) FROM fees f WHERE f.company_id=c.id AND f.status IN ('UNPAID','PARTIAL','OVERDUE')) AS unpaid_count,
            (SELECT COUNT(*) FROM fees f WHERE f.company_id=c.id) AS total_fees,
            (SELECT SUM(f.amount - f.paid_amount) FROM fees f WHERE f.company_id=c.id AND f.status IN ('UNPAID','PARTIAL','OVERDUE')) AS outstanding,
            (SELECT COUNT(*) FROM tax_deadlines td WHERE td.company_id=c.id AND td.status='PENDING' AND td.due_date < ?) AS overdue_deadlines,
            (SELECT COUNT(*) FROM tasks t WHERE t.company_id=c.id AND t.due_date < ? AND t.status NOT IN ('APPROVED','APPROVED_WITH_EXCEPTION','CANCELLED')) AS overdue_tasks
            FROM companies c WHERE c.active=1"""
        today = now()[:10]
        rows = con.execute(sql, (today, today)).fetchall()
        results = []
        for r in rows:
            d = dict(r)
            # Calculate risk score (0-100, higher = more risk)
            risk = 0
            risk += d["overdue_count"] * 25
            risk += min(d["unpaid_count"] * 5, 25)
            risk += d["overdue_deadlines"] * 15
            risk += min(d["overdue_tasks"] * 5, 15)
            risk = min(risk, 100)
            d["risk_score"] = risk
            d["risk_level"] = "high" if risk >= 60 else "medium" if risk >= 30 else "low"
            d["outstanding"] = float(d["outstanding"] or 0)
            results.append(d)
        results.sort(key=lambda x: -x["risk_score"])
        return results[:20]  # top 20 risky clients

# 10.2: Client Profitability (سودآوری مشتری)
@app.get("/api/analytics/client-profitability")
def client_profitability(request: Request, company_id: str = ""):
    """Calculate profitability per client based on fees collected vs time spent."""
    user = current_user(request)
    require_perm(user, "dashboard.view")
    with db() as con:
        sql = """SELECT c.id, c.name,
            (SELECT COALESCE(SUM(f.paid_amount), 0) FROM fees f WHERE f.company_id=c.id AND f.status!='CANCELLED') AS total_revenue,
            (SELECT COALESCE(SUM(te.duration_seconds), 0) FROM time_entries te
             JOIN tasks t ON t.id=te.task_id WHERE t.company_id=c.id) AS total_time_seconds,
            (SELECT COUNT(*) FROM tasks t WHERE t.company_id=c.id) AS task_count
            FROM companies c WHERE c.active=1"""
        if company_id:
            sql += " AND c.id=?"
            rows = con.execute(sql, (company_id,)).fetchall()
        else:
            rows = con.execute(sql).fetchall()
        results = []
        hourly_rate = 500000  # 500k IRR per hour
        for r in rows:
            d = dict(r)
            revenue = float(d["total_revenue"])
            time_hours = float(d["total_time_seconds"]) / 3600
            cost = time_hours * hourly_rate
            profit = revenue - cost
            d["revenue"] = revenue
            d["time_hours"] = round(time_hours, 1)
            d["estimated_cost"] = round(cost)
            d["profit"] = round(profit)
            d["margin"] = round((profit / revenue * 100) if revenue > 0 else 0, 1)
            d["profitability"] = "profitable" if profit > 0 else "loss" if profit < 0 else "break_even"
            results.append(d)
        results.sort(key=lambda x: -x["profit"])
        return results

# 10.3: Team Capacity Analysis (تحلیل ظرفیت تیم)
@app.get("/api/analytics/team-capacity")
def team_capacity(request: Request):
    """Analyze team workload and capacity."""
    user = current_user(request)
    require_perm(user, "dashboard.view")
    with db() as con:
        rows = con.execute("""SELECT
            u.id, u.name,
            COUNT(t.id) AS total_tasks,
            SUM(CASE WHEN t.status='ASSIGNED' THEN 1 ELSE 0 END) AS assigned,
            SUM(CASE WHEN t.status='IN_PROGRESS' THEN 1 ELSE 0 END) AS in_progress,
            SUM(CASE WHEN t.status='SUBMITTED' THEN 1 ELSE 0 END) AS submitted,
            SUM(CASE WHEN t.status IN ('APPROVED','APPROVED_WITH_EXCEPTION') THEN 1 ELSE 0 END) AS completed,
            SUM(CASE WHEN t.weight=3 THEN 1 ELSE 0 END) AS critical_tasks,
            SUM(CASE WHEN t.due_date < ? AND t.status NOT IN ('APPROVED','APPROVED_WITH_EXCEPTION','CANCELLED') THEN 1 ELSE 0 END) AS overdue,
            (SELECT SUM(te.duration_seconds) FROM time_entries te WHERE te.user_id=u.id) AS total_seconds
            FROM users u LEFT JOIN tasks t ON t.assignee_id=u.id
            WHERE u.active=1
            GROUP BY u.id ORDER BY total_tasks DESC""", (now()[:10],)).fetchall()
        results = []
        for r in rows:
            d = dict(r)
            d["total_hours"] = round(float(d["total_seconds"] or 0) / 3600, 1)
            # Capacity utilization (assume 160 hours/month per employee)
            capacity_hours = 160
            used_hours = d["total_hours"]
            d["capacity_utilization"] = min(round(used_hours / capacity_hours * 100, 1), 100) if capacity_hours > 0 else 0
            d["available_capacity"] = max(capacity_hours - used_hours, 0)
            d["workload_status"] = "overloaded" if d["overdue"] > 2 else "busy" if d["in_progress"] > 5 else "balanced" if d["assigned"] > 0 else "available"
            results.append(d)
        return results

# 10.4: Revenue Analytics (تحلیل درآمد)
@app.get("/api/analytics/revenue")
def revenue_analytics(request: Request, period: str = "monthly"):
    """Revenue analytics with trend analysis."""
    user = current_user(request)
    require_perm(user, "dashboard.view")
    with db() as con:
        if period == "quarterly":
            sql = """SELECT
                strftime('%Y-Q', issue_date) || ((strftime('%m', issue_date)-1)/3+1) AS period,
                SUM(amount) AS billed, SUM(paid_amount) AS collected
                FROM fees WHERE status!='CANCELLED' AND issue_date >= date('now', '-12 months')
                GROUP BY period ORDER BY period"""
        else:
            sql = """SELECT
                strftime('%Y-%m', issue_date) AS period,
                SUM(amount) AS billed, SUM(paid_amount) AS collected
                FROM fees WHERE status!='CANCELLED' AND issue_date >= date('now', '-12 months')
                GROUP BY period ORDER BY period"""
        rows = con.execute(sql).fetchall()
        data = [dict(r) for r in rows]
        # Calculate growth rate
        for i, d in enumerate(data):
            if i > 0:
                prev = float(data[i-1]["billed"] or 0)
                curr = float(d["billed"] or 0)
                d["growth_rate"] = round(((curr - prev) / prev * 100) if prev > 0 else 0, 1)
            else:
                d["growth_rate"] = 0
        # Summary
        total_billed = sum(float(r["billed"] or 0) for r in data)
        total_collected = sum(float(r["collected"] or 0) for r in data)
        return {
            "period_data": data,
            "total_billed": total_billed,
            "total_collected": total_collected,
            "collection_rate": round(total_collected / total_billed * 100, 1) if total_billed > 0 else 0,
            "average_monthly": round(total_billed / max(len(data), 1)),
        }
