═══════════════════════════════════════════════════════════
  YFG Accounting Desk v0.3.0.06
  راهنمای نصب و راه‌اندازی
═══════════════════════════════════════════════════════════

📥 محتویات بسته:
  yfg-accounting/          بک‌اند (FastAPI + Python)
  src/                     فرانت‌اند (Next.js 16)
  public/static/           فایل‌های استاتیک (HTML/JS/CSS)
  next.config.ts           تنظیمات Next.js (پروکسی API)
  package.json             وابستگی‌های Next.js
  tsconfig.json            تنظیمات TypeScript

🚀 نصب و راه‌اندازی:

  1. استخراج فایل ZIP:
     unzip YFG_Accounting_Desk_Complete_0306.zip -d yfg-desk
     cd yfg-desk

  2. نصب وابستگی‌های بک‌اند (Python):
     cd yfg-accounting
     pip install -r requirements.txt

  3. راه‌اندازی بک‌اند (پورت 8000):
     cd app
     python -m uvicorn main:app --host 0.0.0.0 --port 8000

  4. نصب وابستگی‌های فرانت‌اند (Node.js):
     cd ../../  (بازگشت به ریشه)
     npm install

  5. راه‌اندازی فرانت‌اند (پورت 3000):
     npm run dev

  6. باز کردن مرورگر:
     http://localhost:3000

  7. ورود:
     نام کاربری: admin
     رمز عبور:   admin123

═══════════════════════════════════════════════════════════

⚠️ نکات مهم:
  • دیتابیس (SQLite) به‌طور خودکار در yfg-accounting/data/ ساخته می‌شود
  • فایل‌های آپلودی در yfg-accounting/data/files/ ذخیره می‌شوند
  • برای آپدیت آنلاین: تنظیمات → به‌روزرسانی سامانه
  • برای پشتیبان‌گیری: تنظیمات → به‌روزرسانی سامانه → پشتیبان‌گیری

═══════════════════════════════════════════════════════════

🔗 مخزن: https://github.com/glcco9819-lang/yafgtax.git

═══════════════════════════════════════════════════════════
