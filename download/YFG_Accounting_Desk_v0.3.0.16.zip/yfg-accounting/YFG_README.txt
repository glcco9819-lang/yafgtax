═══════════════════════════════════════════════════════════
  YFG Accounting Desk v0.3.0.16 — بسته کامل + راهنما
═══════════════════════════════════════════════════════════

📦 محتویات این بسته:

  yfg-accounting/          بک‌اند کامل (FastAPI + Python)
    app/main.py            تمام API endpoints (8800+ خط، 300+ مسیر)
    app/static/            فایل‌های استاتیک (HTML, JS, CSS, آیکون)
    scripts/               اسکریپت ورود داده‌های واقعی
    requirements.txt       وابستگی‌های Python
    Dockerfile            فایل Docker
    compose.yaml           Docker Compose
  
  src/                     فرانت‌اند (Next.js 16)
    app/page.tsx           صفحه اصلی (redirect به /static)
    app/layout.tsx         Layout
    globals.css            استایل‌های سراسری
  
  public/static/           فایل‌های استاتیک Next.js
  
  fonts/                   فونت‌های فارسی (Vazirmatn)
  
  next.config.ts           تنظیمات Next.js + proxy rewrites
  package.json             وابستگی‌های Node.js
  tsconfig.json            تنظیمات TypeScript
  .env.example             نمونه متغیرهای محیطی
  .gitignore               فایل‌های نادیده‌گرفته‌شده

🚀 نصب سریع (فقط بک‌اند — برای استفاده فوری):

  1. unzip YFG_Accounting_Desk_v0.3.0.16.zip
  2. cd yfg-accounting
  3. pip install -r requirements.txt
  4. cd app
  5. python -m uvicorn main:app --host 0.0.0.0 --port 8000
  6. مرورگر را باز کنید: http://localhost:8000/static/index.html
  7. ورود: admin / admin123

🚀 نصب کامل (بک‌اند + فرانت‌اند Next.js):

  1. unzip YFG_Accounting_Desk_v0.3.0.16.zip
  2. cd yfg-accounting && pip install -r requirements.txt
  3. ترمینال ۱: cd yfg-accounting/app && python -m uvicorn main:app --host 127.0.0.1 --port 8000
  4. ترمینال ۲: npm install && npm run dev
  5. مرورگر: http://localhost:3000

🐳 نصب با Docker:

  1. unzip YFG_Accounting_Desk_v0.3.0.16.zip
  2. cd yfg-accounting
  3. docker-compose up -d
  4. مرورگر: http://localhost:8000

🔄 آپدیت آنلاین (از داخل برنامه):

  پس از نصب، برای آپدیت:
  1. وارد برنامه شوید (admin / admin123)
  2. به تنظیمات → 🔄 به‌روزرسانی سامانه بروید
  3. دکمه «⬇ دانلود و نصب از GitHub» را بزنید
  4. برنامه خودکار دانلود، نصب و ریاستارت می‌شود
  
  یا با API:
  POST http://localhost:8000/api/system/update-and-restart?source=github&branch=main

📋 تمام امکانات (10 فاز، 25+ قابلیت):

  فاز ۱: تقویم مالیاتی ایرانی، سامانه مودیان، پرتال مشتری، قالب کار تکرارشونده، 
          تخصیص کارمند، ماژول مطالبات (Fee)، زمان‌سنجی
  فاز ۲: مدیریت اسناد، امضای الکترونیکی، اتوماسیون گردش‌کار
  فاز ۳: داشبورد KPI پیشرفته، تقویم iCal، نوتیفیکیشن چندکاناله، PWA
  فاز ۴: API عمومی، Webhooks، OCR placeholder
  فاز ۵: درخواست سند، کیوسک، پیشنهاد+دریافت‌وجه، اتصال هلو/سپیدار، 
          حقوق و دستمزد، تسویه مالیاتی، چندزبانه
  فاز ۶: AES-256، MFA/TOTP، زنجیره ممیزی، DR backup، سیاست نگهداری
  فاز ۷: شبا/IR-IBAN، پرداخت گروهی پایا، PKI، تامین اجتماعی
  فاز ۸: AI RAG (پرسش از اسناد)، دسته‌بندی خودکار، پیش‌بینی جریان نقدی
  فاز ۹: یادداشت مشترک، خط زمانی فعالیت، ثبت ارتباط با مشتری
  فاز ۱۰: امتیازدهی ریسک مشتری، سودآوری، ظرفیت تیم، تحلیل درآمد

📊 آمار:
  8800+ خطوط کد
  300+ API endpoints
  35+ جداول دیتابیس
  10 فاز کامل
  25+ قابلیت پیاده‌سازی‌شده

🔐 امنیت:
  PBKDF2 رمزنگاری رمز عبور (قابل تنظیم)
  MFA با TOTP (Google Authenticator)
  AES-256 رمزنگاری داده‌ها
  زنجیره هش ممیزی (tamper-proof)
  پشتیبان خودکار قبل از هر آپدیت

═══════════════════════════════════════════════════════════
🔗 مخزن: https://github.com/glcco9819-lang/yafgtax.git
🔗 ریلیز: https://github.com/glcco9819-lang/yafgtax/releases/tag/v0.3.0.16
═══════════════════════════════════════════════════════════
