═══════════════════════════════════════════════════════════
  YFG Accounting Desk v0.3.0.16 — بسته کامل + وابستگی‌ها
═══════════════════════════════════════════════════════════

🚀 نصب روی ویندوز:

  ۱. فایل ZIP را استخراج کنید
  ۲. وارد پوشه yfg-accounting شوید
  ۳. فایل install.bat را اجرا کنید (دابل کلیک)
     → وابستگی‌ها نصب می‌شوند (از پوشه محلی یا آنلاین)
  ۴. فایل start.bat را اجرا کنید (دابل کلیک)
  ۵. مرورگر: http://localhost:8000/static/index.html
  ۶. ورود: admin / admin123

🚀 نصب روی لینوکس:

  ۱. unzip YFG_Accounting_Desk_v0.3.0.16.zip
  ۲. cd yfg-accounting
  ۳. chmod +x install.sh && ./install.sh
  ۴. chmod +x start.sh && ./start.sh
  ۵. مرورگر: http://localhost:8000/static/index.html

🚀 نصب دستی (اگر اسکریپت کار نکرد):

  ۱. pip install --no-index --find-links=../yfg-packages -r requirements.txt
  ۲. یا: pip install fastapi uvicorn python-multipart openpyxl cryptography
  ۳. cd app
  ۴. python -m uvicorn main:app --host 0.0.0.0 --port 8000

💡 نکته برای کاربران ایران:
  اگر خطای timeout داد، از VPN استفاده کنید یا:
  pip install --timeout 300 -r requirements.txt

═══════════════════════════════════════════════════════════
