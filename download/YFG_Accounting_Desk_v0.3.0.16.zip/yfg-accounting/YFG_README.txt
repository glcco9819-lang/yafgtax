═══════════════════════════════════════════════════════════
  YFG Accounting Desk v0.3.0.16 — بسته کامل
  راهنمای نصب و راه‌اندازی
═══════════════════════════════════════════════════════════

🚀 نصب سریع:

  لینوکس / macOS:
    1. unzip YFG_Accounting_Desk_v0.3.0.16.zip
    2. cd yfg-accounting
    3. ./start.sh
    4. مرورگر: http://localhost:8000/static/index.html
    5. ورود: admin / admin123

  ویندوز:
    1. استخراج فایل ZIP
    2. وارد پوشه yfg-accounting شوید
    3. فایل start.bat را اجرا کنید (دابل کلیک)
    4. مرورگر: http://localhost:8000/static/index.html
    5. ورود: admin / admin123

  نصب دستی (اگر اسکریپت کار نکرد):
    1. unzip YFG_Accounting_Desk_v0.3.0.16.zip
    2. cd yfg-accounting
    3. pip install -r requirements.txt
    4. cd app
    5. python -m uvicorn main:app --host 0.0.0.0 --port 8000
    6. مرورگر: http://localhost:8000/static/index.html
    7. ورود: admin / admin123

🐳 نصب با Docker:
    1. unzip YFG_Accounting_Desk_v0.3.0.16.zip
    2. cd yfg-accounting
    3. docker-compose up -d
    4. مرورگر: http://localhost:8000

📋 پیش‌نیازها:
    - Python 3.9 یا بالاتر
    - pip (همراه Python نصب می‌شود)
    - اتصال اینترنت (برای نصب وابستگی‌ها)

📦 وابستگی‌ها (به‌طور خودکار نصب می‌شوند):
    - fastapi
    - uvicorn[standard]
    - python-multipart
    - openpyxl
    - cryptography

🔄 آپدیت آنلاین:
    تنظیمات → 🔄 به‌روزرسانی سامانه → ⬇ دانلود و نصب از GitHub
    یا API: POST /api/system/update-and-restart?source=github&branch=main

═══════════════════════════════════════════════════════════
🔗 مخزن: https://github.com/glcco9819-lang/yafgtax.git
═══════════════════════════════════════════════════════════
