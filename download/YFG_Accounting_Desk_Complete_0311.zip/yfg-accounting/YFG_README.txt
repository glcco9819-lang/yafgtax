═══════════════════════════════════════════════════════════
  YFG Accounting Desk v0.3.0.11 — بسته کامل
  راهنمای نصب و راه‌اندازی
═══════════════════════════════════════════════════════════

📦 محتویات بسته:
  yfg-accounting/          بک‌اند کامل (FastAPI + Python) — 6763 خط
    app/main.py            تمام API endpoints (254 مسیر)
    app/static/            فایل‌های استاتیک (HTML/JS/CSS)
    scripts/               اسکریپت ورود داده‌های واقعی
    requirements.txt       وابستگی‌های Python
    Dockerfile            فایل Docker
  src/                     فرانت‌اند (Next.js 16)
  public/static/          فایل‌های استاتیک
  next.config.ts          تنظیمات Next.js (rewrites proxy)
  package.json            وابستگی‌های Node.js

🚀 نصب سریع (فقط بک‌اند):

  1. unzip YFG_Accounting_Desk_Complete_0311.zip
  2. cd yfg-accounting
  3. pip install -r requirements.txt
  4. cd app && python -m uvicorn main:app --host 0.0.0.0 --port 8000
  5. باز کنید: http://localhost:8000/static/index.html
  6. ورود: admin / admin123

🚀 نصب کامل (بک‌اند + فرانت‌اند):

  1. unzip YFG_Accounting_Desk_Complete_0311.zip
  2. cd yfg-accounting && pip install -r requirements.txt
  3. cd app && python -m uvicorn main:app --host 127.0.0.1 --port 8000 &
  4. cd ../../ && npm install
  5. npm run dev
  6. باز کنید: http://localhost:3000

📋 امکانات (25 قابلیت — 5 فاز):

  فاز ۱: تقویم مالیاتی، سامانه مودیان، پرتال مشتری، قالب کار تکرارشونده،
          تخصیص کارمند، ماژول مطالبات (Fee)، زمان‌سنجی
  فاز ۲: پرتال مشتری، مدیریت اسناد، امضای الکترونیکی، اتوماسیون
  فاز ۳: داشبورد پیشرفته، تقویم (iCal)، نوتیفیکیشن چندکاناله، PWA
  فاز ۴: API عمومی، Webhooks، OCR (placeholder)
  فاز ۵: درخواست سند، کیوسک، پیشنهاد+دریافت‌وجه، اتصال واقعی مودیان،
          اتصال هلو/سپیدار، حقوق و دستمزد، تسویه مالیاتی، چندزبانه

📊 آمار:
  254 API endpoints
  28+ جداول دیتابیس
  25/25 پیشنهاد پژوهش پیاده‌سازی شد (100%)

═══════════════════════════════════════════════════════════
🔗 مخزن: https://github.com/glcco9819-lang/yafgtax.git
═══════════════════════════════════════════════════════════
